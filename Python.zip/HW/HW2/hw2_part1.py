''' 
Author: Caila Marashaj

This program takes information about gumball size and sales, and 
generates information about gumball storage and sales
'''


import math

def find_volume_sphere(radius):
    volume = (4/3) * math.pi * radius**3
    return volume

def find_volume_cube(side):
    return side**3

#input assignment
gb_r = input("Enter the gum ball radius (in.) => ")
print(gb_r)
w_sales = input("Enter the weekly sales => ")
print(w_sales)
print()

#convert to usable types
gb_r = float(gb_r)
w_sales = int(w_sales)
#find the target number of gumballs to be sold
gb_needed = math.ceil(1.25*w_sales)

#number of gumballs per calculated cube edge
gb_per_side = math.ceil(gb_needed**(1/3))
#needed edge space = gumballs*gumball diameter
machine_edge = gb_per_side*gb_r*2
#volume of entire gumball machine
machine_volume = find_volume_cube(machine_edge)
#volume of 1 gumball
gb_volume = find_volume_sphere(gb_r)
#number of gumballs that could fit in machine
capacity = gb_per_side**3 
#how many more gumballs than the target the machine can hold
extra = capacity - gb_needed

#wasted space for target number of gumballs
wasted_space_target = machine_volume - (gb_needed*gb_volume)
#wasted space for calculated number of gumballs
wasted_space_capacity = machine_volume - (capacity*gb_volume)


#output
print("The machine needs to hold {} gum balls along each edge.".format(gb_per_side))
print("Total edge length is {:.2f} inches.".format(machine_edge))
print("Target sales were ",gb_needed,", but the machine will hold ",extra, \
      " extra gum balls.",sep='')
print("Wasted space is {0:.2f} cubic inches with the target number of gum balls, \nor {1:.2f} cubic inches if you fill up the machine.".format(wasted_space_target,wasted_space_capacity))
