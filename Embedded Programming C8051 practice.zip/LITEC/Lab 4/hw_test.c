/* Sample code for speed control using PWM. */
#include <stdio.h>
#include <c8051_SDCC.h>
#include <i2c.h>

//function prototypes
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void SMB_Init(void);
void ADC_Init(void);
void Steering_Servo();
void Change_Heading();
void Drive_Motor(void);
unsigned int Read_Compass();
unsigned int ReadRanger(void);
unsigned char read_AD(void);
void UI(void);

//global variables
__sbit __at 0xB7 SS;
__sbit __at 0xA5 BLED1;
__sbit __at 0xA7 BLED2;

unsigned char voltage;
unsigned char AD_value;
unsigned char value;
unsigned int h_count;
unsigned int r_count;
unsigned int new_heading = 1;
unsigned int new_range = 1;
char input;

/*
need to test:

	-potentiometer
	-BILED1
	-BILED2
	-Slide Switch

*/

void main(void)
{
	printf("\r\nLab 4 hardware test");
	printf("\r\npress any button");
	while (1)
	{
		input = getchar();
		//SS test
		if (SS) {printf("\r\nSlide switch NOT activated");}
		else {printf("\r\nSlide switch activated");}

		//BILED test
		if (input == '0') 
		{
			printf("\r\nTurning on BILED0");
			BILED0 = 0;
			BILED1 = 1;
		}
		else if (input == '1') 
		{
			printf("\r\nTurning on BILED1");
			BILED0 = 1;
			BILED1 = 0;
		}
		//potentiomter test
		voltage = read_AD();
		printf("\r\nPotentiometer voltage = %u", voltage);
	}
}




unsigned char read_AD(void)
{
	AD_value = read_AD();
	value = AD_value * 71.25;
	return value;
}

void XBR0_Init()
{
	XBR0 = 0x1F;		//configure crossbar with UART, SPI, SMBus, and CEX channels as
						// in worksheet
}

void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 - Pulse Width Modulation implemented using the PCA (Programmable Counter Array, p. 50 in Lab Manual.
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM0 = PCA0CPM2 = 0xC2; // CCM2. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}

void PCA_ISR ( void ) __interrupt 9
{
	//see lab instructions online to ocunt
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672;
		h_count++;
		r_count++;
		if(h_count>=3) //recommended to wait 3 overflows instead of 2
		{
			new_heading = 1; 
			h_count = 0;
			//printf("\r\nCounting\r\n");
		}
		if(r_count>=4)
		{
			new_range=1; // 4 overflows is about 80 ms
			r_count = 0;
		}
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}

void SMB_Init(void)
{
	SMB0CR = 0X93; //set SCL to 100kHz*/
	ENSMB = 1; //bit 6 of SMB0CN, enable the SMBus
}

void ADC_Init(void)
{
    REF0CN = 0x03; //Vref = 2.4V
    ADC1CN = 0x80; //enable A/D coversion
    ADC1CF &= ~0x02;
    ADC1CF |= 0x01;

}