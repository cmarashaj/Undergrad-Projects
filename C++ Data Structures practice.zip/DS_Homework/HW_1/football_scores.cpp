#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>

int main (int argc, char** argv) {
	return 0;
	
	std::ifstream input_file(argv[0]);

	std::string input_str;
	std::vector <std::string> input_vec;

	while (input_file >> input_str) {
		input_vec.push_back(input_str);
	}
	std::cout << input_vec[0]
}