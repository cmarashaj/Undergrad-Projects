// -----------------------------------------------------------------
// HOMEWORK 7 WORD FREQUENCY MAPS
//
// You may use all of, some of, or none of the provided code below.
// You may edit it as you like (provided you follow the homework
// instructions).
// -----------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <string>
#include <list>
#include <vector>
#include <map>
#include <cassert>
#include <cstdlib>
using namespace std;


typedef unsigned int uint;

// ASSIGNMENT: FILL IN YOUR OWN MAP STRUCTURE
typedef map<string, map<string, int> >  MY_MAP;
typedef map<string, map<string, map<string, int> > > MY_MAP2;



// Custom helper function that reads the input stream looking for
// double quotes (a special case delimiter needed below), and white
// space.  Contiguous blocks of alphabetic characters are lowercased &
// packed into the word.
bool ReadNextWord(std::istream &istr, std::string &word) {
  char c;
  word.clear();
  while (istr) {
    // just "peek" at the next character in the stream
    c = istr.peek();
    if (isspace(c)) {
      // skip whitespace before a word starts
      istr.get(c);
      if (word != "") {
  // break words at whitespace
  return true;
      }
    } else if (c == '"') {
      // double quotes are a delimiter and a special "word"
      if (word == "") {
  istr.get(c);
  word.push_back(c);
      }
      return true;
    } else if (isalpha(c)) {
      // this a an alphabetic word character
      istr.get(c);
      word.push_back(tolower(c));
    } else {
      // ignore this character (probably punctuation)
      istr.get(c);
    }
  }
  return false;
}


// Custom helper function that reads the input stream looking a
// sequence of words inside a pair of double quotes.  The words are
// separated by white space, but the double quotes might not have
// space between them and the neighboring word.  Punctuation is
// ignored and words are lowercased.
std::vector<std::string> ReadQuotedWords(std::istream &istr) {
  // returns a vector of strings of the different words
  std::vector<std::string> answer;
  std::string word;
  bool open_quote = false;
  while (ReadNextWord(istr,word)) {
    if (word == "\"") {
      if (open_quote == false) { open_quote=true; }
      else { break; }
    } else {
      // add each word to the vector
      answer.push_back(word);
    }
  }
  return answer;
}



// Loads the sample text from the file, storing it in the map data
// structure Window specifies the width of the context (>= 2) of the
// sequencing stored in the map.  parse_method is a placeholder for
// optional extra credit extensions that use punctuation.
void LoadSampleText(MY_MAP &data, MY_MAP2 &data2, map<string, int>& appearances, const std::string &filename, int window, const std::string &parse_method) {
  // open the file stream
  std::ifstream istr(filename.c_str());
  if (!istr) { 
    std::cerr << "ERROR cannot open file: " << filename << std::endl; 
    exit(1);
  } 
  // verify the window parameter is appropriate
  if (window < 2) {
    std::cerr << "ERROR window size must be >= 2:" << window << std::endl;
  }
  // verify that the parse method is appropriate
  bool ignore_punctuation = false;
  if (parse_method == "ignore_punctuation") {
    ignore_punctuation = true;
  } else {
    std::cerr << "ERROR unknown parse method: " << parse_method << std::endl;
    exit(1);
  }

  //
  string word;
  vector<string> words;
  //


  while (ReadNextWord(istr,word)) {
    // skip the quotation marks (not used for this part)
    if (word == "\"") continue;
    words.push_back(word);// Adds every word to a vector
  }
  for(uint i = 0; i < words.size()-1; ++i){ //goes through vector of words
    if(data.find(words[i]) == data.end()){//checks if it exists in map
      data[words[i]][words[i+1]] = 1; //adds to main map
      
    }
    else{
      if(data[words[i]].find(words[i+1]) == data[words[i]].end()){
        data[words[i]][words[i+1]] = 1; //adds map as value to first map
      }
      else{
        data[words[i]][words[i+1]]++;
      }
    }
  }
  for(uint i = 0; i < words.size(); ++i)
  {
    if(data.find(words[i]) == data.end())
    {
      appearances[words[i]] = 1;//adds to appearance map for math part
    }
    else
    {
      appearances[words[i]]++;//adds value  
    }
  }
  if(window == 3){ //3 deep
    for(uint i = 0; i < words.size()-2; ++i)
    {
      if(data2.find(words[i]) == data2.end())
      { // checks if it exists in map2
        data2[words[i]][words[i+1]][words[i+2]] = 1; //adds it to map of maps
      }
      else
      {
        if(data2[words[i]][words[i+1]].find(words[i+2]) == data2[words[i]][words[i+1]].end())
        {
          data2[words[i]][words[i+1]][words[i+2]] = 1;//adds map as value to first map & second map
        }
        else
        {
          data2[words[i]][words[i+1]][words[i+2]]++; //increments value of it in maps
        }
      }
    }
  }
}



int main () {

  // ASSIGNMENT: THE MAIN DATA STRUCTURE
  MY_MAP data;
  MY_MAP2 data2;
  map<string, int> appearances;
  srand(time(NULL));

  // Parse each command
  std::string command;    
  while (std::cin >> command) {
  int window;
    // load the sample text file
    if (command == "load") 
    {
      std::string filename;
      
      std::string parse_method;
      std::cin >> filename >> window >> parse_method;      

      LoadSampleText(data, data2, appearances, filename, window, parse_method);
      cout << "Loaded " << filename << " with window = " << window << 
      " and parse method = " << parse_method << endl;
    } 
    // print the portion of the map structure with the choices for the
    // next word given a particular sequence.
    else if (command == "print") 
    {
      std::vector<std::string> sentence = ReadQuotedWords(std::cin);
      cout << endl;
      if(window == 2){
        if(sentence.size() == 1) 
        {
          cout << sentence[0] << " (" << appearances[sentence[0]] << ")"<< endl;
          map<string, int>::iterator it; //iterates through map1
          for(it = data[sentence[0]].begin(); it != data[sentence[0]].end(); ++it) // goes until end of map of chosen word
          {
            cout << sentence[0] << " " << it->first << " (" << it->second << ")"<< endl; //prints when it matches w word
          }
        }
        if(sentence.size() == 2)//if its a bigger size list
        {
         cout << sentence[0] << " " << sentence[1] << " (" << data[sentence[0]][sentence[1]] << ")"<< endl; 
         //prints out the words, subsequent word after and the number stored after that
        }
      }
      if(window == 3){
        if(sentence.size() == 1)
        {
          cout << sentence[0] << " (" << appearances[sentence[0]] << ")"<< endl;
          map<string, int>::iterator it; //same as above
          for(it = data[sentence[0]].begin(); it != data[sentence[0]].end(); ++it)
          {
            cout << sentence[0] << " " << it->first << " (" << it->second << ")"<< endl;
          }
        }
        if(sentence.size() == 2) 
        {
          cout << sentence[0] << " " <<sentence [1] << " (" << data[sentence[0]][sentence[1]] << ")"<< endl;
          map<string, int>::iterator it; //same as above
          for(it = data2[sentence[0]][sentence[1]].begin(); it != data2[sentence[0]][sentence[1]].end(); ++it)
          {
            cout << sentence[0] << " " << sentence[1] << " " << it->first << " (" << it->second << ")" << endl;
          }
        }
        if(sentence.size() == 3){
          int size = data2[sentence[0]][sentence[1]][sentence[2]]; //stores value that this is equal to
          cout << sentence[0] << " " << sentence[1] << sentence[2] << " (" << size << ")"<< endl;
        }
      }
      cout << endl;

    }

    // generate the specified number of words 
    else if (command == "generate") {
      std::vector<std::string> sentence = ReadQuotedWords(std::cin);
      // how many additional words to generate
      int length;
      std::cin >> length;
      std::string selection_method;
      std::cin >> selection_method;
      bool random_flag;
      if (selection_method == "random") {
         random_flag = true;
      } 
      else {
        assert (selection_method == "most_common");
        random_flag = false;
      }
      if(random_flag == true)
      {
        for(int i = 0; i < length; ++i)
        {
          int rand_num = rand()%data[sentence[sentence.size()-1]].size()+1;
          int number = 1;
          map<string, int>::iterator iter;
          for(iter = data[sentence[sentence.size()-1]].begin();
            iter != data[sentence[sentence.size()-1]].end(); iter++, number++)
          {
            if(number == rand_num)
            {
              sentence.push_back(iter->first);
              break;
            }
          } 
        }
        for(uint i = 0; i < sentence.size()-1; ++i)
        {
          cout << sentence[i] << " ";
        }
        cout << sentence[sentence.size()-1] << endl << endl;
      }
      else
      {
        if(window == 2)
        {
          for(int i = 0; i < length; ++i){//add that many words to sentence
            map<string, int>::iterator it; 
            int num = 0;
            for(it = data[sentence[sentence.size()-1]].begin(); 
              it != data[sentence[sentence.size()-1]].end(); it++)
              //iterates through last sentence words of data
            {
              if(it->second > num){
                num = it->second;
              }
            }
            map<string, int>::iterator it2;
            for(it2 = data[sentence[sentence.size()-1]].begin();
              it2 != data[sentence[sentence.size()-1]].end(); it2++)
            {
              if(it2->second == num)
              {
                sentence.push_back(it2->first);
                break;
              }
            }
          }
        }
        if(window == 3)
        {
          if(sentence.size() == 1)
          {
             map<string, int>::iterator it; 
            int num = 0;
            for(it = data[sentence[sentence.size()-1]].begin(); 
              it != data[sentence[sentence.size()-1]].end(); it++)
              //iterates through last sentence words of data
            {
              if(it->second > num){
                num = it->second;
              }
            }
            map<string, int>::iterator it2;
            for(it2 = data[sentence[sentence.size()-1]].begin();
              it2 != data[sentence[sentence.size()-1]].end(); it2++)
            {
              if(it2->second == num)
              {
                sentence.push_back(it2->first);
                length--;
                break;
              }
            }
          }
          for(int i = 0; i < length; ++i)
            {
              map<string, int>::iterator it3;
              int num = 0;
              for(it3 = data2[sentence[sentence.size()-2]][sentence[sentence.size()-1]].begin();
                it3 != data2[sentence[sentence.size()-2]][sentence[sentence.size()-1]].end(); ++it3)
              {
                if(it3->second > num)
                {
                  num = it3->second;
                }
              }
              map<string, int>::iterator it4;
              for(it4 = data2[sentence[sentence.size()-2]][sentence[sentence.size()-1]].begin();
                it4 != data2[sentence[sentence.size()-2]][sentence[sentence.size()-1]].end(); it4++)
              {
                if(it4->second == num)
                {
                  sentence.push_back(it4->first);
                  break;
                }
              }
            } 
          }
          for(uint i = 0; i < sentence.size()-1; ++i)
          {
            cout << sentence[i] << " ";
          }
          
        cout << sentence[sentence.size()-1] << endl << endl;
        }      
      } 
    else if (command == "quit")
    {
      break;
    } 
    else
    {
      std::cout << "WARNING: Unknown command: " << command << std::endl;
    }
  }
}