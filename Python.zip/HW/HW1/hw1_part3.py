#input
frame = input("Enter frame character ==> ")
print(frame)
height = input("Height of box ==> ")
print(height)
width = input("Width of box ==> ")
print(width)

#determine spacing
#center the text horizontally by subtracting the number of spaces that wont be whitespace from the width and dividing
left_space = (int(width)-3-(len(width)+len(height))) // 2
right_space = int(width)-3-(len(width)+len(height)) - left_space
#center the text vertically by subtracting 3 from the height: top and bottom rows and middle row
#integer divide to determine where the text goes 
top_space = (int(height)-3) // 2
bottom_space = int(height)-3-top_space

#print output
print("\nBox:")
print(frame*int(width)) #top row
#whitespace rows above text
print(((frame+(' '*(int(width)-2))+frame+'\n')*top_space), end='') 
#row with dimensions printed
print(frame+(' '*left_space)+width+'x'+height+(' '*right_space)+frame) 
#whitespace rows below text
print(((frame+(' '*(int(width)-2))+frame+'\n')*bottom_space), end='') 
print(frame*int(width)) #bottom row



#Thought Process:
#width is at least 4
     #if even width, put text farther left
#height is at least 7     
     #if even height, put text higher up
     
#text is not always 3 characters
# width and height placement are remaining spaces // 2