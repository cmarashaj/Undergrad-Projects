''' 
Author: Caila Marashaj

This program takes in a grid of elevation values and gives the user
desired feedback about the data

'''

import hw5_util as util

def print_grid(grid):
    #print each row
    for i in range(len(grid)):
        #print each col
        for j in range(len(grid[i])):
            print(' ' + ' '*(3-len(str(grid[i][j]))) + str(grid[i][j]),end='')
        print()

def get_nbrs(grid_,loc):
    neighbors = []
    row = loc[0]
    col = loc[1]
    #above neighbor
    if row > 0: neighbors.append((row-1,col))
    #left
    if col > 0: neighbors.append((row,col-1))  
    #right
    if col < len(grid[0])-1: neighbors.append((row,col+1))
    #below
    if row < len(grid)-1: neighbors.append((row+1,col))
    return neighbors    


def check_path(grid_,path):
    #make sure each location in path is a neighbor of each other
    last = path[0]
    downward = 0
    upward = 0
    for i in range(1,len(path)):
        loc = path[i]
        #diagonal move- no good
        if loc[0] != last[0] and loc[1] != last[1]: 
            print('Path: invalid step from {0} to {1}'.format(last,loc))
            return
        else:
            #moved rows
            #move has to be within 1 row or column of the last
            if abs(loc[0]-last[0]) > 1: 
                print('Path: invalid step from {0} to {1}'.format(last,loc))
                return
            if abs(loc[1]-last[1]) > 1: 
                print('Path: invalid step from {0} to {1}'.format(last,loc))
                return
        #downward change - last has higher elevation
        if grid[last[0]][last[1]] > grid[loc[0]][loc[1]]:
            downward += (grid[last[0]][last[1]] - grid[loc[0]][loc[1]])
        #upward
        elif grid[last[0]][last[1]] < grid[loc[0]][loc[1]]:
            upward += (grid[loc[0]][loc[1]] - grid[last[0]][last[1]])
        last = loc
    print('Valid path')
    print("Downward",downward)
    print("Upward",upward)
    
        

grid_found = False
while not grid_found:
    #input
    desired_grid = input("Enter a grid index less than or equal to 3 (0 to end): ")
    print(desired_grid)
    desired_grid = int(desired_grid)
    
    if desired_grid >= 1 and desired_grid <=util.num_grids(): grid_found = True
grid = util.get_grid(desired_grid)

print_req = input("Should the grid be printed (Y or N): ")
print(print_req)
print_req = print_req.upper()
#print grid
if print_req == 'Y':
    print("Grid",desired_grid)
    print_grid(grid)
#rows and columns
print("Grid has {0} rows and {1} columns".format(len(grid),len(grid[0])))
start_locations = util.get_start_locations(desired_grid)
#neighbors for each starting location
for loc in start_locations:
    print("Neighbors of ({0}, {1}):".format(loc[0],loc[1],get_nbrs(grid,loc)),end='')
    for i in get_nbrs(grid,loc): print(" {}".format(i),end='')
    print()
#check suggested path
sug_path = util.get_path(desired_grid)
check_path(grid,sug_path)