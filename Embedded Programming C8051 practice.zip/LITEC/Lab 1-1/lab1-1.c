/*  Name: Niyanthri Ramaswamy
    Section: 1
    Date: 05/23/2019
    File name: Lab 1-1
    Program description:
*/
/*
  This program is incomplete. Part of the code is provided as an example. You 
  need to modify the code, adding code to satisfy the stated requirements. Blank 
  lines have also been provided at some locations, indicating an incomplete line.
*/
#include <c8051_SDCC.h> // include files. This file is available online on LMS
#include <stdio.h>

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------
void Port_Init(void);  // Initialize ports for input and output
void Set_outputs(void);// function to set output bits

//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
__sbit __at 0xB6 LED0; // LED0, associated with Port 3 Pin 6
__sbit __at 0xB3 BILED0; // BILED0, associated with ?????
__sbit __at 0xB4 BILED1; // BILED1, associated with ?????
__sbit __at 0xB7 BUZZER; // Buzzer, associated with ?????
__sbit __at 0xA0 SS;   // Slide switch, associated with Port 2 Pin 0
__sbit __at 0xB0 PB1;  // Push button 1, associated with Port 3, Pin 0
__sbit __at 0xB1 PB2; // Push button 2, associated with ?????


//***************
// Main program

void main(void)
{
    Sys_Init();        // System Initialization
    putchar(' ');      // the quote fonts may not copy correctly into SiLabs IDE
    Port_Init();       // Initialize ports 2 and 3 

    while (1)          // infinite loop 
    {
        // main program manages the function calls

        Set_outputs();
    }
}


//***************
/* Port_Init - Initializes Ports 2 and 3 in the desired modes for input and output */

void Port_Init(void)
{
    // Port 3
	P3MDOUT &= 0xFC; // set Port 3 output pins to push-pull mode (fill in the blank)
    P3MDOUT |= 0xD8; // set Port 3 input pins to open drain mode (fill in the blank)
    P3 = ~0xFC; // set Port 3 input pins to high impedance state (fill in the blank)

    // Port 2
    // configure Port 2 as needed
	P2MDOUT &= 0xFE;
	P2 = ~0xFE;
//
//
}



//***************
// Set outputs:
//    The following code is incomplete, lighting an LED depending 
//    on the state of the slide switch.



void Set_outputs(void)
{
	//Group member 1
	if (!SS)        // if Slide Switch activated (On position)
    {
        LED0 = 1;   // turn off LED0 
        printf("\r Slide switch is on    \n");
		printf("\r LED0 is off    \n");
		if(PB1 && PB2)
		{
			BUZZER = 0;
			printf("\r Buzzer is on    \n");
		}
		else if(PB1 && !PB2)
		{
			BILED1 = 0;//BILED is green
			printf("\r BiLED is green	\n");
		}
		else if(PB2 && !PB1)
		{
			BILED0 = 0;//BILED is red
			printf("\r BiLED is red	\n");
		}
    }
    else            // if Slide Switch is not activated (Off position)
    {
        LED0 = 0;   // turn on LED0 
        printf("\r Slide switch is off   \n");	
    }
	//Group member 2
	if (!SS)        // if Slide Switch activated (On position)
    {
        LED0 = 0;   // turn on LED0 
        printf("\r Slide switch is on    \n");
		printf("\r LED0 is on    \n");
		if(!PB1 && !PB2)
		{
			BILED1 = 1;
			BILED0 = 1;
			printf("\r BiLED is off    \n");

		}
		else if(PB1 && !PB2)
		{
			BUZZER = 0;
			printf("\r Buzzer is on    \n");
		}
		else if(PB2 && !PB1)
		{
			LED0 = 0;
			printf("\r LED0 is on    \n");
		}
		else if(PB1 && PB2)
		{
			BILED0 = 0;
			printf("\r BiLED is red	\n");

		}
    }
    else            // if Slide Switch is not activated (Off position)
    {
        BILED1 = 0;//BILED is green   
		LED0 = 1; // turn off LED0 
        printf("\r Slide switch is off   \n");
		printf("\r BiLED is green	\n");
    }
	//Group member 3
    if (!SS)        // if Slide Switch activated (On position)
    {
        LED0 = 0;   // turn on LED0 
        printf("\r Slide switch is on    \n");
		printf("\r LED0 is on    \n");
		if(PB1 && PB2)
		{
			BUZZER = 0;
			printf("\r Buzzer is on    \n");
		}
		else if(PB1 && !PB2)
		{
			BILED0 = 0;
		}
		else if(PB2 && !PB1)
		{
			BILED1 = 0;
		}
    }
    else            // if Slide Switch is not activated (Off position)
    {
        LED0 = 1;   // turn off LED0 
        printf("\r Slide switch is off   \n");	
    }
}

