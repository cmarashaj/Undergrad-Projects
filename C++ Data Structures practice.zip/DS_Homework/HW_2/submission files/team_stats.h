#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>

//keeps track of team statistics needed for win_percent and creative outputs
// tracks wins, losses, win percentage, average points per game, and 
// total games played for each team
class Team_Stats {
public:
	Team_Stats();
	Team_Stats(std::string team_name_, double wins_, double losses_, double win_p_, int all_points_) : 
	team_name(team_name_), wins(wins_), losses(losses_), win_p(win_p_), all_points(all_points_) {}

	std::string getTeamName() const {return team_name;}
	int getWins() const {return wins;}
	int getLosses() const {return losses;}
	double getWinP() const {return win_p;}
	double AvgPPG() const {return all_points/(wins+losses);}
	int TotalGames() const {return wins+losses;}

private:
	std::string team_name;
	double wins;
	double losses;
	double win_p;
	double all_points;
};