#include <iostream>
#include <cassert>
#include <cstdlib>
#include <string>
#include <algorithm>
#include <array>
#include <cstring>
#include <cmath>
#include "tetris.h"

	//tetris consructor
	//defines width, data, heights and assigns all heights to 0 to begin
	Tetris::Tetris(int width_) {
		width = width_;
		heights = new int[width];
		data = new char*[width];
		for (unsigned int i = 0; i < width; i++) {
			heights[i] = 0;
		}
	}

	
	int Tetris::get_width() {
		return width;
	}

	//returns the height of the tallest column on the board
	int Tetris::get_max_height() const {
		int max_h = 0;
		for (int i = 0; i < width; i++) {
			if (heights[i] > max_h) {
				max_h = heights[i];
			}
		}
		return max_h;
	}
	//returns the total number of non-space characters on the board
	int Tetris::count_squares()  {
		int squares = 0;
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < heights[i]; j++) {
				if (data[i][j] != ' ') {
					squares += 1;
				}
			}
		}

		return squares;
	}
	//returns the number of rows removed
	int Tetris::remove_full_rows() {
		int max_height = get_max_height();
		int score = 0;	

		for (int i = 0; i < max_height; i++) {
			//check that every column in given row has height at least i
			bool h_check = true;
			for (int j = 0; j < width; j++) {
				if (heights[j] < i) {
					h_check = false;
				}
			}
			if (h_check == true) {
					for (int j = 0; j < width; j++) {
							//if it comes across a space character in a given column
							//break the loop
							bool exit = false;
							if (data[j][i] == ' ') {
								exit = true;
								break;
							}
							if (exit) {
								break;
							}
					}
				if (full_row == true) {
					score++;
					for (int j = 0; j < width; j++) {
						//create temp array to copy half of the board above 
						//full row and the bottom half onto
						char * drop;
						drop = new char[heights[j]-1];
						for (int k = 0; k < heights[j]; k++) {
							drop[k] = data[j][k];
						}	
						for (int k = i + 1; k < heights[j]; k++) {
							drop[k - 1] = data[j][k];
						}
						delete [] data[j];
						data[j] = drop;
						
						//if there is nothing in the column besides the slot that was d
						//deleted, set the adjusted height to 0
						bool empty = true;
						for (int k = 0; k < heights[j]-1; k++) {
							if (data[j][k] != ' ') {
								empty = false;
							}
						}

						if (empty) {
							heights[j] = 0;
						}

						//otherwise, reassign the height to be one slot lower
						else {
							heights[j]--;
						
						}
					}
				}
			}
		}
		return score;
	}
	void Tetris::remove_left_column() {
		//create temp array to copy board onto to implement shift
		char ** temp = new char*[width-1];
		for (int i = 1; i < width; i++) {
			temp[i-1] = new char[heights[i]];
			for (int j = 0; j < heights[i]; j++) {
				//copy each row into temp array
				temp[i-1][j] = data[i][j];
			}
		}
		
		for (int i = 0; i < width; i++) {
			delete [] data[i];
		}

		//create temp to adjust heights array
		int * h_temp = new int[width-1];
		for (int i = 1; i < width; i++) {
			h_temp[i-1] = heights[i];
		}
		
		delete[] data;
		delete [] heights;
		width--;
		
		//reassign heights array to equal temp
		heights = new int[width];
		for (int i = 0; i < width; i++) {
			heights[i] = h_temp[i];
		} 

		//reassign each array in data array, shifted one index to the right
		data = new char*[width];
		for (int i = 0; i < width; i++) {
			data[i] = new char[heights[i]];
			for (int j = 0; j < heights[i]; j++) {
				data[i][j] = temp[i][j];
			}
		}
		for (int i = 0; i < width; i++) {
			delete [] temp[i];
		} 
		delete [] temp;

		

		
		delete [] h_temp;
	}
	
	void Tetris::remove_right_column() {
		//create temp vector for resiszing data array
		char ** temp = new char*[width-1];
		for (int i = 0; i < width-1; i++) {
			temp[i] = new char[heights[i]];
			for (int j = 0; j < heights[i]; j++) {
				temp[i][j] = data[i][j];
			}
		}
		
		for (int i = 0; i < width; i++) {
			delete [] data[i];
		}

		//create temp for resizing heights
		int * h_temp = new int[width-1];
		for (int i = 0; i < width-1; i++) {
			h_temp[i] = heights[i];
		}
		
		//adjust width for board reassignment
		delete[] data;
		delete [] heights;
		width--;
		
		heights = new int[width];
		for (int i = 0; i < width; i++) {
			heights[i] = h_temp[i];
		} 

		//reassign each slot on each array for data array
		data = new char*[width];
		for (int i = 0; i < width; i++) {
			data[i] = new char[heights[i]];
			for (int j = 0; j < heights[i]; j++) {
				data[i][j] = temp[i][j];
			}
		}
		for (int i = 0; i < width; i++) {
			delete [] temp[i];
		} 
		delete [] temp;

		

		
		delete [] h_temp;
	}
	void Tetris::add_left_column () {
		char ** temp = new char*[width];
		for (int i = 0; i < width; i++) {
			temp[i] = new char[heights[i]];
			for (int j = 0; j < heights[i]; j++) {
				temp[i][j] = data[i][j];
			}
		}
		
		for (int i = 0; i < width; i++) {
			delete [] data[i];
		}

		int * h_temp = new int[width];
		for (int i = 0; i < width; i++) {
			h_temp[i] = heights[i];
		}
		
		delete[] data;
		delete [] heights;
		
		
		heights = new int[width+1];
		heights[0] = 0;
		for (int i = 0; i < width; i++) {
			heights[i+1] = h_temp[i];
		} 

		data = new char*[width+1];
		for (int i = 0; i < width; i++) {
			data[i+1] = new char[heights[i+1]];
			for (int j = 0; j < heights[i+1]; j++) {
				data[i+1][j] = temp[i][j];
			}
		}
		data[0] = new char[0];
		
		for (int i = 0; i < width; i++) {
			delete [] temp[i];
		} 
		delete [] temp;
		delete [] h_temp;
		width++;
	}
	void Tetris::add_right_column () {
		char ** temp = new char*[width];
		for (int i = 0; i < width; i++) {
			temp[i] = new char[heights[i]];
			for (int j = 0; j < heights[i]; j++) {
				temp[i][j] = data[i][j];
			}
		}
		
		for (int i = 0; i < width; i++) {
			delete [] data[i];
		}

		int * h_temp = new int[width];
		for (int i = 0; i < width; i++) {
			h_temp[i] = heights[i];
		}
		
		delete[] data;
		delete [] heights;
		
		
		heights = new int[width+1];
		heights[width] = 0;
		for (int i = 0; i < width; i++) {
			heights[i] = h_temp[i];
		} 

		data = new char*[width+1];
		for (int i = 0; i < width; i++) {
			data[i] = new char[heights[i]];
			for (int j = 0; j < heights[i]; j++) {
				data[i][j] = temp[i][j];
			}
		}
		data[width] = new char[0];
		
		for (int i = 0; i < width; i++) {
			delete [] temp[i];
		} 
		delete [] temp;
		delete [] h_temp;
		width++;
	}

	//DESTRUCTOR
	void Tetris::destroy() {
		delete [] heights;
		for (int i = 0; i < width; i++) {
			delete [] data[i];
		}
		delete [] data;
	}

	//MEMBER FUNCTIONS
	
	void Tetris::add_piece(char piece, int rotation, int position) {
		if (piece == 'I') {
			if (rotation == 90 || rotation == 270) {
				//old height is where the left corner (position)
				//of the piece will be placed
				//the old height is the tallest height of each column the piece
				//will be on
				int old_height;
				int max1 = std::max(heights[position], heights[position+1]);
				int max2 = std::max(heights[position+2], heights[position+3]);
				old_height = std::max(max1, max2);
				int new_height = old_height+1;
				
				//if there is already an array present for each column, 
				//copy the contents of said array onto an appropriately resized temp
				//then copy the temp array back into the data array
				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char[new_height];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					//if there is no array to resize, initalize array 
					//with appropriate height
					data[position] = new char[new_height];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[new_height];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[new_height];
				}

				if (heights[position+2] != 0) {
					char * temp_2;
					temp_2 = new char[new_height];
					for (int i = 0; i < heights[position+2]; i++) {
						temp_2[i] = data[position+2][i];
					}
					delete [] data[position+2];
					data[position+2] = temp_2;
				}
				else {
					data[position+2] = new char[new_height];
				}

				if (heights[position+3] != 0) {
					char * temp_3;
					temp_3 = new char[new_height];
					for (int i = 0; i < heights[position+3]; i++) {
						temp_3[i] = data[position+3][i];
					}
					delete [] data[position+3];
					data[position+3] = temp_3;
				}
				else {
					data[position+3] = new char[new_height];
				}

				//for each column, space characters belong in every slot
				//between the lowest character slot and either the bottom of the board
				//or the first occurrence of the next character in the column
				if ((new_height-heights[position]) > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if ((new_height-heights[position+1]) > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				if ((new_height-heights[position+2]) > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position+2]); i++) {
						data[position+2][(i+heights[position+2])] = ' ';
					}
				}

				if ((new_height-heights[position+3]) > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position+3]); i++) {
						data[position+3][(i+heights[position+3])] = ' ';
					}
				}

				//assign appropriate slots to label the piece
				for (int i = 0; i < 4; i++) {
					data[position+i][old_height] = 'I';
					heights[position+i] = new_height;

				}

			}	


			else if (rotation == 0 || rotation == 180) {
				int old_height = heights[position];
				int new_height = old_height+4;

				//same operation, except there is only one column
				if (heights[position] != 0) {
					char * temp;
					temp = new char[new_height];
					for (int i = 0; i < heights[position]; i++) {
						temp[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp;
				}
				else {
					data[position] = new char[new_height];
				}

				if ((new_height-heights[position]) > 4) {
					for (int i = 0; i < ((new_height-4)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				for (int i = 0; i < 4; i++) {
					data[position][old_height+i] = 'I';
				}
				heights[position] = new_height;

			}
		}
		
		else if (piece == 'O') {
			//orientation does not matter
			int old_height = std::max(heights[position], heights[position+1]);
			int new_height = (old_height+2);
			//resize present arrays
			if (heights[position] != 0) {
				char *temp = new char[new_height];
				for (unsigned int i = 0; i < heights[position]; i++) {
					temp[i] = data[position][i];
				}
				delete [] data[position];
				data[position] = temp;
			}
			else {
				data[position] = new char[new_height];
			}

			if (heights[position+1] != 0) {
				char * temp_1;
				temp_1 = new char[new_height];
				for (int i = 0; i < heights[position+1]; i++) {
					temp_1[i] = data[position+1][i];
				}
				delete [] data[position+1];
				data[position+1] = temp_1;
				
			}
			else {
				data[position+1] = new char[heights[position]+2];
			}
 			//assign space characters
 			if ((new_height-heights[position]) > 2) {
				for (unsigned int i = 0 ; i < ((new_height-2)-heights[position]); i++) {
					data[position][(i+heights[position])] = ' ';
				}
			}
			if ((new_height-heights[position+1]) > 2)
			 { for (unsigned int i = 0; i < ((new_height-2)-heights[position+1]); i++) {
			 		data[position+1][(i+heights[position+1])] = ' ';
			 }
			} 
			//assign character slots to appropriate places
			data[position][new_height-2] = 'O';
			data[position][new_height-1] = 'O';
			data[position+1][new_height-2] = 'O';
			data[position+1][new_height-1] = 'O';

			//update heights vector for both columns
			heights[position] = new_height;
			heights[position+1] = new_height;	
		}
		
		else if (piece == 'T') {
			if (rotation == 0) {
				//old height is still heighest to-be-occupied column
				int old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int new_height;
				//if middle is lower than outside columns
				if ((heights[position+1] < heights[position]) ||
					(heights[position+1] < heights[position+2])) {
					new_height = old_height+1;
				}
				else {
					new_height = old_height+2;
				}
				//resize present arrays
					if (heights[position] != 0) {
						char * temp_0;
						temp_0 = new char [new_height];
						for (int i = 0; i < heights[position]; i++) {
							temp_0[i] = data[position][i];
						}
						delete [] data[position];
						data[position] = temp_0;
					}
					else {
						data[position] = new char[new_height];
					}
					if (heights[position+1] != 0) {
						char * temp_1;
						temp_1 = new char [new_height];
						for (int i = 0; i < heights[position+1]; i++) {
							temp_1[i] = data[position+1][i];
						}
						delete [] data[position+1];
						data[position+1] = temp_1;
					}
					else {
						data[position+1] = new char[new_height];
					}	
					if (heights[position+2] != 0) {
						char * temp_2;
						temp_2 = new char [new_height];
						for (int i = 0; i < heights[position+2]; i++) {
							temp_2[i] = data[position+2][i];
						}
						delete [] data[position+2];
						data[position+2] = temp_2;
					}
					else {
						data[position+2] = new char[new_height];
					}
					
					//assign space characters
					if ((new_height-heights[position]) > 1) {
						for (int i = 0; i < ((new_height-1)-heights[position]); i++) {
							data[position][(i+heights[position])] = ' ';
						}
					}
					if ((new_height-heights[position+1]) > 2) {
						for (int i = 0; i < ((new_height-2)-heights[position+1]); i++) {
							data[position+1][(i+heights[position+1])] = ' ';
						}
					}
					if ((new_height-heights[position+2]) > 1) {
						for (int i = 0; i < ((new_height-1)-heights[position+2]); i++) {
							data[position+2][(i+heights[position+2])] = ' ';
						}
					}
					//asign letter characters
					data[position][new_height-1] = 'T';
					data[position+1][new_height-1] = 'T';
					data[position+1][new_height-2] = 'T';
					data[position+2][new_height-1] = 'T';

					std::cout << "position = " << position << std::endl;
					std::cout << "new height = " << new_height << std::endl;
					heights[position] = new_height;
					heights[position+1] = new_height;
					heights[position+2] = new_height;
			}
			else if (rotation == 90) {
				int old_height;
				if (heights[position+1] > heights[position]) {
					old_height = heights[position+1] - 1;
				}
				else {
					old_height = heights[position];
				}
				int l_newh = old_height + 3;
				int r_newh = old_height + 2;
				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char [l_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[l_newh];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char [r_newh];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[r_newh];
				}
				
				if ((l_newh-heights[position]) > 3) {
					for (int i = 0; i < ((l_newh-3)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				//maybe (i+heights[position]) should be (i+heights[position+1])
				if ((r_newh-heights[position+1]) > 1) {
					for (int i = 0; i < ((r_newh-1)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				data[position][old_height] = 'T';
				data[position][old_height+1] = 'T';
				data[position][old_height+2] = 'T';
				data[position+1][old_height+1] = 'T';

				heights[position] = l_newh;
				heights[position+1] = r_newh;
			}
			else if (rotation == 180) {
				int old_height;
				old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int out_newh = old_height+1;
				int m_newh = old_height+2;

				if (heights[position] != 0) {
					char * temp_0; 
					temp_0 = new char[out_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[out_newh];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[m_newh];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[m_newh];
				}

				if (heights[position+2] != 0) {
					char * temp_2;
					temp_2 = new char[out_newh];
					for (int i = 0; i < heights[position+2]; i++) {
						temp_2[i] = data[position+2][i];
					}
					delete [] data[position+2];
					data[position+2] = temp_2;
				}
				else {
					data[position+2] = new char[out_newh];
				}
				
				if ((out_newh-heights[position]) > 1) {
					for (int i = 0; i < ((out_newh-1)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if ((m_newh-heights[position+1]) > 2) {
					for (int i = 0; i < ((m_newh-2)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				if ((out_newh-heights[position+2]) > 1) {
					for (int i = 0; i < ((out_newh-1)-heights[position+2]); i++) {
						data[position+2][(i+heights[position+2])] = ' ';
					}
				}

				data[position][old_height] = 'T';
				data[position+1][old_height] = 'T';
				data[position+1][old_height+1] = 'T';
				data[position+2][old_height] = 'T';

				heights[position] = out_newh;
				heights[position+1] = m_newh;
				heights[position+2] = out_newh;
			}
			else if (rotation == 270) {
				int old_height;
				if (heights[position] > heights[position+1]) {
					old_height = heights[position] - 1;
				}
				else {
					old_height = heights[position+1];
				}
				int l_newh = old_height + 2;
				int r_newh = old_height + 3;

				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char [l_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[l_newh];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char [r_newh];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[r_newh];
				}
				if ((l_newh-heights[position]) > 2) {
					for (int i = 0; i < ((l_newh-2)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}
				if ((r_newh-heights[position+1] > 1)) {
					for (int i = 0; i < ((r_newh-1)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}


				data[position][old_height+1] = 'T';
				data[position+1][old_height] = 'T';
				data[position+1][old_height+1] = 'T';
				data[position+1][old_height+2] = 'T';
				
				heights[position] = l_newh;
				heights[position+1] = r_newh;
			}
		}
		
		else if (piece == 'Z') {
			//determine old height, use this to determine new height
			if (rotation == 0 || rotation == 180) {
				int old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int new_height;
				if (heights[position] > heights[position+1] &&
					heights[position] > heights[position+2]) {
					new_height = old_height + 1;
				}
				else {
					new_height = old_height + 2;
				}

				//resize present arrays
				if (heights[position] != 0) {
					char * temp_0; 
					temp_0 = new char[new_height];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[new_height];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[new_height];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[new_height];
				}

				if (heights[position+2] != 0) {
					char * temp_2;
					temp_2 = new char[new_height-1];
					for (int i = 0; i < heights[position+2]; i++) {
						temp_2[i] = data[position+2][i];
					}
					delete [] data[position+2];
					data[position+2] = temp_2;
				}
				else {
					data[position+2] = new char[new_height-1];
				}


				//assign space characters
				if ((new_height-heights[position]) > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if ((new_height-heights[position+1]) > 2) {
					for (int i = 0; i < ((new_height-2)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				if ((new_height-1-heights[position+2]) > 1) {
					for (int i = 0; i < ((new_height-2)-heights[position+2]); i++) {
						data[position+2][(i+heights[position+2])] = ' ';
					}
				}

				//assign character spaces
				data[position][new_height-1] = 'Z';
				data[position+1][new_height-1] = 'Z';
				data[position+1][new_height-2] = 'Z';
				data[position+2][new_height-2] = 'Z';

				heights[position] = new_height;
				heights[position+1] = new_height;
				heights[position+2] = new_height-1;

			}
			else if (rotation == 90 || rotation == 270) {
				//piece is the same if rotated to 90 or 270
				int old_height = std::max(heights[position], heights[position+1]);
				int l_newh;
				int r_newh;
				if (heights[position+1] > heights[position]) {
					l_newh = old_height + 1;
					r_newh = old_height + 2;
				}
				else {
					l_newh = old_height + 2;
					r_newh = old_height + 3;
				}

				if (heights[position] != 0) {
					char * temp_0; 
					temp_0 = new char[l_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[l_newh];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[r_newh];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[r_newh];
				}

				if ((l_newh-heights[position]) > 2) {
					for (int i = 0; i < ((l_newh-2)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if ((r_newh-heights[position+1]) > 2) {
					for (int i = 0; i < ((r_newh-2)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				data[position][l_newh-2] = 'Z';
				data[position][l_newh-1] = 'Z';
				data[position+1][r_newh-1] = 'Z';
				data[position+1][r_newh-2] = 'Z';

				heights[position] = l_newh;
				heights[position+1] = r_newh;
			}
		}
		
		else if (piece == 'S') {
			if (rotation == 0 || rotation == 180) {
				int old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int new_height;
				if (heights[position+2] > heights[position] &&
				heights[position+2] > heights[position+1]) {
					new_height = old_height + 1;
				}
				else {
					new_height = old_height + 2;
				}

				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char[new_height-1];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[new_height-1];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[new_height];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[new_height];
				}

				if (heights[position+2] != 0) {
					char * temp_2;
					temp_2 = new char[new_height];
					for (int i = 0; i < heights[position+2]; i++) {
						temp_2[i] = data[position+2][i];
					}
					delete [] data[position+2];
					data[position+2] = temp_2;
				}
				else {
					data[position+2] = new char[new_height];
				}

				if ((new_height-1)-heights[position] > 1) {
					for (int i = 0; i < ((new_height-2)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if (new_height-heights[position+1] > 2) {
					for (int i = 0; i < ((new_height-2)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				if (new_height-heights[position+2] > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position+2]); i++) {
						data[position+2][(i+heights[position+2])] = ' ';
					}
				}

				data[position][new_height-2] = 'S';
				data[position+1][new_height-2] = 'S';
				data[position+1][new_height-1] = 'S';
				data[position+2][new_height-1] = 'S';

				heights[position] = new_height - 1;
				heights[position+1] = new_height;
				heights[position+2] = new_height;
			}
			else if (rotation == 90 || rotation == 270) {
				int old_height = std::max(heights[position], heights[position+1]);
				int r_newh;
				int l_newh;
				if (heights[position] > heights[position+1]) {
					r_newh = old_height + 1;
					l_newh = old_height + 2;
				}
				else {
					r_newh = old_height + 2;
					l_newh = old_height + 3;
				}

				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char[l_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[l_newh];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[r_newh];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[r_newh];
				}

				if ((l_newh-heights[position]) > 2) {
					for (int i = 0; i < ((l_newh-2)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if ((r_newh-heights[position+1]) > 2) {
					for (int i = 0; i < ((r_newh-2)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				data[position][r_newh] = 'S';
				data[position][r_newh-1] = 'S';
				data[position+1][r_newh-1] = 'S';
				data[position+1][r_newh-2] = 'S';

				heights[position] = l_newh;
				heights[position+1] = r_newh;
			}
		}
		else if (piece == 'L') {
			if (rotation == 0) {
				int old_height = std::max(heights[position], heights[position+1]);
				int l_newh = old_height + 3;
				int r_newh = old_height + 1;

				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char[l_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[l_newh];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[r_newh];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[r_newh];
				}

				if ((l_newh-heights[position]) > 3) {
					for (int i = 0; i < ((l_newh-3)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if ((r_newh-heights[position+1]) > 1) {
					for (int i = 0; i < ((r_newh-1)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				data[position][l_newh-1] = 'L';
				data[position][l_newh-2] = 'L';
				data[position][l_newh-3] = 'L';
				data[position+1][r_newh-1] = 'L';

				heights[position] = l_newh;
				heights[position+1] = r_newh;

			}
			else if (rotation == 90) {
				int old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int new_height;
				if (heights[position+1] > heights[position] ||
				heights[position+2] > heights[position]) {
					new_height = old_height + 1;
				}
				else {
					new_height = old_height + 2;
				}

				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char[new_height];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[new_height];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[new_height];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[new_height];
				}

				if (heights[position+2] != 0) {
					char * temp_2;
					temp_2 = new char[new_height];
					for (int i = 0; i < heights[position+2]; i++) {
						temp_2[i] = data[position+2][i];
					}
					delete [] data[position+2];
					data[position+2] = temp_2;
				}
				else {
					data[position+2] = new char[new_height];
				}

				if ((new_height-heights[position]) > 2) {
					for (int i = 0; i < ((new_height-2)-heights[position]); i++) {
						data[position][(i+heights[position])] = ' ';
					}
				}

				if ((new_height-heights[position+1]) > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				if ((new_height-heights[position+2]) > 1) {
					for (int i = 0; i < ((new_height-1)-heights[position+2]); i++) {
						data[position+2][(i+heights[position+2])] = ' ';
					}
				}

				data[position][new_height-2] = 'L';
				data[position][new_height-1] = 'L';
				data[position+1][new_height-1] = 'L';
				data[position+2][new_height-1] = 'L';

				heights[position] = new_height;
				heights[position+1] = new_height;
				heights[position+2] = new_height;
			}
			else if (rotation == 180) {
				int old_height;
				int new_height;
				if ((heights[position]-2) > heights[position+1]) {
					old_height = heights[position];
					new_height = old_height+1;
				}
				else {
					old_height = heights[position+1];
					new_height = old_height + 3;
				}

				if (heights[position] != 0) {
					char * temp_0;
					temp_0 = new char[new_height];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[new_height];
				}

				if (heights[position+1] != 0) {
					char * temp_1;
					temp_1 = new char[new_height];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;	
				}
				else {
					data[position+1] = new char[new_height];
				}

				if ((new_height-heights[position]) > 1) {
					for (int i = 0; i < ((new_height-heights[position])-1); i++) {
						data[position][i+heights[position]] = ' ';
					}
				}

				if ((new_height-heights[position+1]) > 3) {
					for (int i = 0; i < ((new_height-3)-heights[position+1]); i++) {
						data[position+1][(i+heights[position+1])] = ' ';
					}
				}

				data[position][new_height-1] = 'L';
				data[position+1][new_height-1] = 'L';
				data[position+1][new_height-2] = 'L';
				data[position+1][new_height-3] = 'L';

				heights[position] = new_height;
				heights[position+1] = new_height;

			}
			else if (rotation == 270) {
				int old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int lm_newh = old_height+1;
				int r_newh = old_height+2;

				
				for (int i = 0; i < 2; i++) {
					if (heights[position+i] != 0) {
						char * temp = new char[lm_newh];
						for (int j = 0; j < heights[position+i]; j++) {
							temp[j] = data[position+i][j];
						}
						delete [] data[position+i];
						data[position+i] = temp;
					}
					else {
						data[position+i] = new char[lm_newh];
					}
				}

				if (heights[position+2] != 0) {
					char * temp_1 = new char[r_newh];
					for (int i = 0; i < heights[position+2]; i++) {
						temp_1[i] = data[position+2][i];
					}
					delete [] data[position+2];
					data[position+2] = temp_1;
				}
				else {
					data[position+2] = new char[r_newh];
				}

				for (int i = 0; i < 2; i++) {
					if ((lm_newh-heights[position+i]) < 1) {
						for (int j = 0; j < ((lm_newh-heights[position+i])-1); j++) {
							data[position+i][j+heights[position+i]] = ' ';
						}
					}
				}

				if ((r_newh-heights[position+2]) > 2) {
					for (int i = 0; i < ((r_newh-heights[position+2])-1); i++) {
						data[position+2][i+heights[position+2]] = ' ';
					}
				}

				data[position][lm_newh-1] = 'L';
				data[position+1][lm_newh-1] = 'L';
				data[position+2][lm_newh-1] = 'L';
				data[position+2][r_newh-1] = 'L';


				heights[position] = lm_newh;
				heights[position+1] = lm_newh;
				heights[position+2] = r_newh;
			}
		}
		
		else if (piece == 'J') {
			if (rotation == 0) {
				int old_height = std::max(heights[position], heights[position+1]);
				int l_newh = old_height + 1;
				int r_newh = old_height + 3;

				if (heights[position] != 0) {
					char * temp_0 = new char[l_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[l_newh];
				}

				if (heights[position+1] != 0) {
					char * temp_1 = new char[r_newh];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1];
					data[position+1] = temp_1;
				}
				else {
					data[position+1] = new char[r_newh];
				}

				if ((l_newh-heights[position]) > 1) {
					for (int i = 0; i < ((l_newh-heights[position])-1); i++) {
						data[position][i+heights[position]] = ' ';
					}
				}

				if ((r_newh-heights[position+1]) > 3) {
					for (int i = 0; i < ((r_newh-heights[position+1])-3); i++) {
						data[position+1][i+heights[position+1]] = ' ';
					}
				}

				data[position][l_newh-1] = 'J';
				data[position+1][l_newh-1] = 'J';
				data[position+1][r_newh-2] = 'J';
				data[position+1][r_newh-1] = 'J';

				heights[position] = l_newh;
				heights[position+1] = r_newh;
			}
			else if (rotation == 90) {
				int old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int l_newh = old_height + 2;
				int mr_newh = old_height + 1;

				if (heights[position] != 0) {
					char * temp_0 = new char[l_newh];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[l_newh];
				}

				for (int i = 0; i < 2; i++) {
					if (heights[position+i] != 0) {
						char * temp = new char[mr_newh];
						for (int j = 0; j < heights[position+i]; j++) {
							temp[j] = data[position+i][j];
						}
						delete [] data[position+i];
						data[position+i] = temp;
					}
					else {
						data[position+1] = new char[mr_newh];
					}
				} 

				if ((l_newh-heights[position]) > 2) {
					for (int i = 0; i < ((l_newh-heights[position])-2); i++) {
						data[position][i+heights[position]] = ' ';
					}
				}

				for (int i = 0; i < 2; i++) {
					if ((mr_newh-heights[position+i]) > 1) {
						for (int j = 0; j < ((mr_newh-heights[position+i])-1); j++) {
							data[position+i][j+heights[position+i]] = ' ';
						}
					}
				}

				data[position][l_newh-1] = 'J';
				data[position][l_newh-2] = 'J';
				data[position+1][mr_newh-1] = 'J';
				data[position+2][mr_newh-1] = 'J';

				heights[position] = l_newh;
				heights[position+1] = mr_newh;
				heights[position+2] = mr_newh;
			}
			else if (rotation == 180) {
				int old_height;
				int new_height;
				if ((heights[position+1]-2) > heights[position]) {
					old_height = heights[position+1];
					new_height = old_height + 1;
				}
				else {
					old_height = heights[position];
					new_height = old_height + 3;
				}

				if (heights[position] != 0) {
					char * temp_0 = new char[new_height];
					for (int i = 0; i < heights[position]; i++) {
						temp_0[i] = data[position][i];
					}
					delete [] data[position];
					data[position] = temp_0;
				}
				else {
					data[position] = new char[new_height];
				}

				if (heights[position+1] != 0) {
					char * temp_1 = new char[new_height];
					for (int i = 0; i < heights[position+1]; i++) {
						temp_1[i] = data[position+1][i];
					}
					delete [] data[position+1]; 
					data[position+1] = temp_1;
				}
				else{
					data[position+1] = new char[new_height];
				}

				if ((new_height-heights[position]) > 3) {
					for (int i = 0; i < ((new_height-heights[position])-3); i++) {
						data[position][i+heights[position]] = ' ';
					}
				}

				if ((new_height-heights[position+1]) > 1) {
					for (int i = 0; i < ((new_height-heights[position+1])-1); i++) {
						data[position+1][i+heights[position+1]] = ' ';
					}
				}

				data[position][new_height-3] = 'J';
				data[position][new_height-2] = 'J';
				data[position][new_height-1] = 'J';
				data[position+1][new_height-1] = 'J';

				heights[position] = new_height;
				heights[position+1] = new_height;
			}
			else if (rotation == 270) {
				int old_height = std::max(heights[position], heights[position+1]);
				old_height = std::max(old_height, heights[position+2]);
				int new_height;
				if (heights[position+1] > heights[position+2] ||
					heights[position] > heights[position+2]) {
					new_height = old_height + 1;
				}
				else {
					new_height = old_height + 2;
				}

				for (int i = 0; i < 3; i++) {
					if (heights[position+i] != 0) {
						char * temp = new char[new_height];
						for (int j = 0; j < heights[position+i]; j++) {
							temp[j] = data[position+i][j];
						}
						delete [] data[position+i];
						data[position+i] = temp;
					}
					else {
						data[position+1] = new char[new_height];
					}
				}

				for (int i = 0; i < 2; i++) {
					if ((new_height-heights[position+i]) > 1) {
						for (int j = 0; j < ((new_height-heights[position+i])-1); j++) {
							data[position+i][j+heights[position+i]] = ' ';
						}
					}
				}

				if ((new_height-heights[position+2]) > 2) {
					for (int i = 0; i < ((new_height-heights[position+2])-2); i++) {
						data[position+2][i+heights[position+2]] = ' ';
					}
				}

				data[position][new_height-1] = 'J';
				data[position+1][new_height-1] = 'J';
				data[position+2][new_height-1] = 'J';
				data[position+2][new_height-2] = 'J';

				heights[position] = new_height;
				heights[position+1] = new_height;
				heights[position+2] = new_height;
			}
		}
	}