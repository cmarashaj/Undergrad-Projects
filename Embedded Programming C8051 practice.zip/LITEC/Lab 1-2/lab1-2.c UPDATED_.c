/*  Names: Niyanthri Ramaswamy
    Section: 1
    Date: 05/28/2019
    File name: Lab 1-2
    Description:
*/
/*
  This program demonstrates the use of T0 interrupts. The code will count the
  number of T0 timer overflows that occur while a slide switch is in the ON position.
*/

#include <c8051_SDCC.h>// include files. This file is available online
#include <stdio.h>
#include <stdlib.h>

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------
void Port_Init(void);      // Initialize ports for input and output
void Timer_Init(void);     // Initialize Timer 0 
void Interrupt_Init(void); //Initialize interrupts
void Timer0_ISR(void) __interrupt 1;
unsigned char random(void);

//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
__sbit __at 0xB3 BILED1;
__sbit __at 0xB4 BILED2;
__sbit __at 0xB0 PB1;
__sbit __at 0xB1 PB2;
__sbit __at 0xB6 LED0;
__sbit __at 0xB5 LED1;
__sbit __at 0xB7 BUZZER;


__sbit __at 0xA0 SS;    // Slide Switch associated with Port 2 Pin 0
// sbit settings are incomplete, include those developed 
// in Lab 1-1 and add the sbit setting for LED1
unsigned int Counts = 0;
unsigned int score = 0;
unsigned int prev = 7;
unsigned int num = 0;
unsigned int i = 0;


//***************
void main(void)
{
    Sys_Init();      // System Initialization
    Port_Init();     // Initialize ports 2 and 3 
    Interrupt_Init();
    Timer_Init();    // Initialize Timer 0 

    putchar(' ');    // the quote fonts may not copy correctly into SiLabs IDE
    //printf("Start\r\n");
    

    while (1) /* the following loop prints the number of overflows that occur
                while the pushbutton is pressed, the BILED is lit while the
                button is pressed */
    {
        printf("Starting\r\n");
        BILED1 = 1;  // Turn OFF the BILED
        BILED2 = 1;
        BUZZER = 1; //Turn OFF the BUZZER
        LED0 = 1;
        LED1 = 1;
        if(!SS)
        {
        
            score = 0;
            TL0 = 0x00;
            TH0 = 0x00;
            TR0 = 1;     // Timer 0 enabled
            //int i;
            //for (i = 0; i < 10; ++i)
            i = 0;
            while (i < 10) 
            {
                i++;
                printf("here\r\n");
                do
                {
                    num = random();
                }
                while(num == prev);
                prev = num;

                //Lights up LEDs depending on the random number
                printf("num = %d\r\n", num);
                if (num == 0){
                    printf("LED0 is on\r\n");
                    LED0 = 0;
                }
                else if (num == 1){
                    printf("LED1 is on\r\n");
                    LED1 = 0;
                }
                else if (num == 2){
                    printf("Both LEDs are on on\r\n");
                    LED0 = 0;
                    LED1 = 0;
                }

                //Wait for 1 sec
                while(Counts < 338) {}

                //Check if the user answered right
                if(!PB1 && PB2 && num== 0)
                {
                    printf("Correct answer\r\n");
                    score += 1;
                    BILED1 = 0;
                }
                else if(!PB2 && PB1 && num == 1)
                {
                    printf("Correct answer\r\n");
                    score += 1;
                    BILED1 = 0;
                }
                else if(!PB1 && !PB2 && num== 2)
                {
                    printf("Correct answer\r\n");
                    score += 1;
                    BILED1 = 0;
                }
                else
                {
                    printf("Wrong answer\r\n");
                    BILED2 = 0;
                }
                LED0 = 1;
                LED1 = 1;
                BILED1 = 1;
                BILED2 = 1;
                BUZZER = 1;
            }
            TR0 = 0; 
            printf("\r score: %d ",score);

        }
        while(!SS);
        while(SS);
        
    }
}

//***************
void Port_Init(void)
{
    // use Port configuration from Lab 1-1
    // adding the output bit for LED1
    P2MDOUT &= 0xFE;
    P2 = ~0xFE;
    P3MDOUT &= 0xFC;
    P3MDOUT |= 0xF8;
    P3 = ~0xFC;

}

void Interrupt_Init(void)
{
    IE |= 0x82;      // enable Timer0 Interrupt request (by masking)
    EA = 1;       // enable global interrupts (by sbit)
}
//***************
void Timer_Init(void)
{

    CKCON |= 0x00;  // Timer0 uses SYSCLK as source
    TMOD &= 0xF0;   // clear the 4 least significant bits
    TMOD |= 0x01;   // Timer0 in mode 1
    TR0 = 0;           // Stop Timer0
    TL0 = 0;
    TMR0 = 0;           // Clear high & low byte of T0

}


//***************
void Timer0_ISR(void) __interrupt 1
{
// add interrupt code here, in this lab, the code will increment the 
// global variable 'counts'
    TF0 = 0;
    Counts++;
}

/******************************************************************************/
/*
  This function demonstrates how to obtain a random integer between 0 and 1 in
  C. You may modify and use this code to get a random integer between 0 and N.
*/

/*return a random integer number between 0 and 1*/
unsigned char random(void)
{
    return (rand()%3);  // rand returns a random number between 0 and 32767.
                        // the mod operation (%) returns the remainder of 
                        // dividing this value by 2 and returns the result,
                        // a value of either 0 or 1.
}