#ifndef _STUDENT_
#define _STUDENT_
#include <iostream>
#include <fstream>
#include <list>
#include <cassert>
#include <cstdlib>

class Student {

public:
	 Student();

	 Student(std::string name_);

	 std::string GetName() const;
	 //preference list getter
	 std::list<std::string> Preferences();

	 void PrintStudentDecision(std::ofstream &ostr) const;
	 
	 //pushes back onto school preference list
	 void AddSchool(std::string school_name);
	 
	 void PrepareToReceiveOffers();
	 
	 void RemoveSchoolFromPreferenceList(std::string school_name);
	 //returns true if student has at least one offer
	 bool HasOffer();
	 
	 //return offer from the school that's highest on the student's preference list
	 std::string GetBestOffer() const;
	 
	 //return whether or not student accepted an offer
	 bool IsOfferTentativelyAccepted(std::string name);

private:
	std::string name;
	std::list<std::string> preference_list;
	std::list<std::string> offers;
	std::string accepted;
	std::string bestoffer;

};
//nonmember alphabetical sort functions
bool alpha_by_student_name(const Student& a, const Student& b);
bool alpha_school(const std::string& a, const std::string& b);
#endif