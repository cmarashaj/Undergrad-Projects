HOMEWORK 7: WORD FREQUENCY MAPS


NAME:  < Caila Marashaj >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Lauren McAlarney, Kevin Cruz, ALAC drop-in tutoring >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 30 >



ANALYSIS OF PERFORMANCE OF YOUR ALGORITHM:
(order notation & concise paragraph, < 200 words)

n = total number of words in the sample text file
m = number of unique words in the file
w = width of the sequencing window
p = average number of words observed to follow a particular word
l = length of given phrase

How much memory will the map data structure require, in terms of n, m,
w, and p (order notation for memory use)?

O(m*(p^(w-1)))
memory requirement won't go above O(n)

The map data structures used for this asignment, in order to be created, require the number of unique words in the text file for each level of the map, hence why this is multiplied by the number of words that follow a given word which is multiplied by itself dependent on the window size. If window size is 2, there are two layers of maps, so p must be squared. If window size is 4, p must be cubed, and so on.


What is the order notation for performance (running time) of each of
the commands?

load:

O(n + log(m))

Load simply calls LoadSampleText(), which calls ReadNextWord() in a loop, which has
O(n). Every time a unique word is encountered, it is inserted into the map structures, which has O(log(m)). These two events happen independent of each other, hence why they are added


print:

O(l(log(p)) + p)

print calls .find() in a map the same number of times that there are words in the user-given phrase, which creeates l(log(p)). Independent of this, print loops through every word that follows the user-given word or phrase



generate random:


O(w*log(p) + p^w)

generate, both most_common and random, calls .find() the same number of times as there are windows. Independent of this, it loops through inside maps dependent of how many layers exist, hence p^w. These happen independently of each other, so they are added


quit:

O(1)

Quit only breaks the function, independent of any variables



EXTRA CREDIT
Parsing & using punctuation data, implementation supports *any*
window size, new test cases (describe & summarize performance, but
don't include large datasets with submission).



MISC. COMMENTS TO GRADER:  
(optional, please be concise!)


