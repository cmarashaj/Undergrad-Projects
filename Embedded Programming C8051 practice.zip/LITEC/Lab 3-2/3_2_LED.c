//update for PCA Start


/* Sample code for speed control using PWM. */
#include <stdio.h>
#include <c8051_SDCC.h>
#include <i2c.h>
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void SMB_Init(void);
unsigned int ReadRanger(void);
//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
unsigned int l_count = 0;
unsigned int new_light = 1;
unsigned int light;
unsigned char Data[0];
unsigned char Data[1];
unsigned char addr;
unsigned int PCA_start;

//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init();
	SMB_Init();
	//print beginning message
	printf("Embedded Control Light Sensor\r\n");
	//add code to set the servo motor in neutral for one second
	while(1)
	{
		if(new_light)
		{
			light = ReadRanger();
			new_light = 0;
			printf("Light: %d\r\n",light);
		}
	}
}
//-----------------------------------------------------------------------------
// Function to Read Ranger
//-----------------------------------------------------------------------------
unsigned int ReadRanger(void)
{
	light = 0;
	addr=0xE0; // the address of the ranger is 0xE0
	//printf("Hello");
	i2c_read_data(addr,0x01, Data, 1); // read one byte, starting at reg 1
	light = Data[0];
	//ping
	Data[0] = 0x51; // write 0x51 to reg 0 of the ranger:
	i2c_write_data(addr, 0x00, Data, 1); // write one byte of data to reg 0 at addr
	return light; 
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P1MDOUT |= 0X27 ;//set output pin for CEX2 in push-pull mode
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
	
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init()
{
	XBR0 = 0x27;		//configure crossbar with UART, SPI, SMBus, and CEX channels as
						// in worksheet
}
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 - Pulse Width Modulation implemented using the PCA (Programmable Counter Array, p. 50 in Lab Manual.
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM2 = 0xC2; // CCM2. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR ( void ) __interrupt 9
{
	if (CF)
	{
		l_count++;
		if(l_count>4)
		{
			new_light = 1; // at least 4 overflows is about 80 ms
			l_count = 0;
		}
	}
	CF = 0;
}
//-----------------------------------------------------------------------------
// SMBus Initialization
//-----------------------------------------------------------------------------
void SMB_Init(void)
{
	SMB0CR = 0x93; //set SCL to 100kHz*/
	ENSMB = 1; //bit 6 of SMB0CN, enable the SMBus
}