from Bear import Bear
from BerryField import BerryField
from Tourist import Tourist
import json

#input, formatting
f = input('Enter the json file name for the simulation => ').strip()
print(f)
print() 
f = open(f)
data = json.loads(f.read())

#loading in data
raw_berry_field = data["berry_field"]
size = len(raw_berry_field)-1
raw_active_bears = data["active_bears"]
raw_reserve_bears = data["reserve_bears"]
raw_active_tourists = data["active_tourists"]
raw_reserve_tourists = data["reserve_tourists"]
#convert to respective objects
active_bears = []
for bear in raw_active_bears:
    #create a bear object
    bear_ob = Bear(bear,'active')
    active_bears.append(bear_ob)
reserve_bears = []
for bear in raw_reserve_bears:
    bear_ob = Bear(bear,'reserve')
    reserve_bears.append(bear_ob)
active_tourists = []
for tourist in raw_active_tourists:
    t_ob = Tourist(tourist,'active')
    active_tourists.append(t_ob)
reserve_tourists = []
for tourist in raw_reserve_tourists:
    t_ob = Tourist(tourist,'reserve')
    reserve_tourists.append(t_ob)
#create berryfield object
field = BerryField(raw_berry_field,active_bears,active_tourists)
#initial status report
print("Starting Configuration")
print("Field has {} berries.".format(field.berries))
print(field)
print("Active Bears:")
for bear in active_bears: print(bear)
print('\nActive Tourists:')
for t in active_tourists: print(t)
#start counting turns
for i in range(1,6):
    print("\nTurn:",i)
    ''' 
    Tourists leave if:
         - 3 turns pass without them seeing a bear
         - they see 3 bears at once
         - they are on the same location as a bear
    '''      
    #keep track of which entities leave
    t_leaving = []
    b_leaving = []           
            
    #berries need to grow before bears act
    field.grow()

    for bear in sorted(field.bears):
        #reset berries eaten every round
        bear.berries_eaten = 0
        #1.look how many berries there are
        #2.decide whether to eat the berries
        #3.assess how many berries they have
        #4.decide whether to move   
        
        #bear attack
        for t in field.tourists:
            if t.x == bear.x and t.y == bear.y: 
                print(t,'- Left the Field')
                t.leave()
                t_leaving.append(t)
                bear.maul()     
        #dont move bear if its asleep
        if bear.sleeping > 0:
            bear.sleeping -= 1
            continue
        else:
            move = True
            bear.eat(field.eat(bear.x,bear.y))   
            #move until leaves boundaries, eats someone, or eats 30 berries
            while(move):  
                #see how many berries are on current spot
                #if there's a person on the same spot
                #person is no longer gonna show up bc board actually gets evaluated after a change
                #eat berries at current location if any
    
                #bear attack can happen after initial move
                for t in field.tourists:
                    if t.x == bear.x and t.y == bear.y: 
                        print(t,'- Left the Field')
                        t.leave()
                        t_leaving.append(t)
                        bear.maul() 
                        #if it does, decrement sleeping turns and move on to next bear
                        bear.sleeping = 2
                        move = False
                        break
                #remove eaten tourists
                for t in t_leaving:
                    if t in field.tourists: field.tourists.remove(t)
                #if bear is on the move
                if bear.sleeping == 0:
                    #if bear leaves field boundaries
                    if bear.x < 0 or bear.x > size or bear.y < 0 or bear.y > size:
                        #take it out of active lists
                        b_leaving.append(bear)
                        field.remove_b(bear)                
                        print(bear,'- Left the Field')
                        break    
                    else:
                        #eat berries
                        bear.eat(field.eat(bear.x,bear.y))            
                        #if eats 30, dont move again, move on to next bear
                        if bear.berries_eaten >= 30:
                            move=False
                            continue
                        else: bear.move()
    #check tourists
    for t in active_tourists:
        #if any tourists turns_since == 2, they leave
        if t.turns_since == 2: 
            print(t,'- Left the Field')
            t_leaving.append(t)
            t.leave()
        sightings = 0
        for bear in active_bears:
            #check distance from every bear, count sightings
            distance = ((t.x-bear.x)**2 + (t.y-bear.y)**2)**(1/2)
            if distance <= 4: #bear sighting
                sightings += 1
        #disappearance
        if sightings >= 3:
            print(t,'- Left the Field')
            t.leave() 
            t_leaving.append(t)
        elif sightings == 0: t.increment()
        #remove people that leave from active list
        for t in t_leaving: 
            if t in active_tourists: active_tourists.remove(t)
            field.remove_t(t)    
    #status report
    print("Field has {} berries.".format(field.berries))
    print(field)     
    
    print('Active Bears:')
    for bear in active_bears: print(bear)
    print()
    print('Active Tourists:')
    for t in active_tourists: print(t)
    print()