''' 
Author: Caila Marashaj

This program asks the user for a number of weeks to count backwards. It then outputs
a desired statistic about covid-19 and its effect on the US.

'''

import hw4_util as util

def daily(state_data): #takes in a single list for the desired state
    #finds the average number of positive covid cases
    #   per day, per 100,000 people in a desired state
    
    #add together all positive test numbers for a week
    positive_sum = 0
    for i in range(2,9): 
        positive_sum += state_data[i]
    #find average per 100,000
    avg_day = positive_sum/7
    result = (avg_day / state_data[1])*100000
    return result

def pct(state_data):
    #divides the total number of positive tests by the
    #     total number test, both positive and negative
    tests_total = 0
    pos_total = 0
    #positive tests
    for i in range(2,9): pos_total += state_data[i]
    #negative tests
    for i in range(2,16): tests_total += state_data[i]
    #find avg
    avg_pct = pos_total / tests_total
    avg_pct *= 100
    
    return avg_pct
                            
            
def find_state(data, s_i): #finds appropriate state for daily, pct
    state_index = '**' #start as smth that couldn't be an index
    
    #if a state name in the list matches the desired state name, 
    #     assign appropriate index to state_index
    for i in range(len(data)):
        if data[i][0] == s_i: state_index = i
    if state_index == '**': return None
    return data[state_index] #returns relevant list for desired week and state

def quar(week_data):
    #daily > 10 or #pct > 10
    quar_states = []
    #go through each state, and add quarantine states to the output list
    for state in week_data:
        state_daily = daily(state)
        state_pct = pct(state)
        if state_daily > 10 or state_pct > 10:
            quar_states.append(state[0])
    return quar_states

def high(week_data):
    #finds highest daily avg
    highest_daily = -1 #highest number of infections
    state_name = '' #name of most infectious state
    
    #go through each state, and reassign highest_daily if the daily
    #     infections surpasses the current value
    for state in week_data:
        if daily(state) > highest_daily:
            highest_daily = daily(state)
            state_name = state[0]
    #give output as a tuple (name, rate)
    return (state_name,highest_daily)

while(1):
    print('...')
    i = input("Please enter the index for a week: ")
    print(i)
    i = int(i)
    #exit the program if user inputs a negative number
    if i < 0: break
    #data is the nested list for the desired week
    data = util.part2_get_week(i)
    if data == []: #if there is no data for this week
        print("No data for that week")
        continue
    #take request, format
    request = input("Request (daily, pct, quar, high): ")
    print(request)
    request = request.strip('\r')
    request = request.lower()
    if request == 'daily' or request == 'pct':
        #ask for desired state
        state = input("Enter the state: ")
        print(state)
        #save original string for printing, then format
        original_state = state
        state = state.strip('\r')
        state = state.upper()
        #find the list corresponding to the state abbreviation
        state_data = find_state(data,state)
        if state_data == None: # if invalid state abbreviation
            print("State {0} not found".format(original_state))
            continue
    #output, depending on request
    if request == 'daily':
        result = daily(state_data)
        print("Average daily positives per 100K population: {0:.1f}".format(result))
    elif request == 'pct':
        result = pct(state_data)
        print("Average daily positive percent: {0:.1f}".format(result))
    elif request == 'quar':
        quarantine_states = quar(data)
        print("Quarantine states:")
        util.print_abbreviations(quarantine_states)
    elif request == 'high':
        highest = high(data)
        print("State with highest infection rate is",highest[0])
        print("Rate is {0:.1f} per 100,000 people".format(highest[1]))
    #if request doesn't match any of these:
    else: print("Unrecognized request")