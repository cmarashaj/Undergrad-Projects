"""
Author: Caila Marashaj

This program runs a pokemon simulation where they player's pikachu moves around
a map and battles other pokemon of the user's choosing
"""


def move_pokemon(row, column, direction, steps):
    #N subtracts row
    #S adds row
    #W subtracts column
    #E adds column
    if direction == 'N': row -= steps
    elif direction == 'S': row += steps
    elif direction == 'E': column += steps
    elif direction == 'W': column -= steps
    #prevent pikachu from going off map
    if row < 0: row = 0
    elif row > 150: row = 150
    if column < 0: column = 0
    elif column > 150: column = 150
    
    return (row,column)
    
#input
turns = input("How many turns? => ")
print(turns)
turns = int(turns)
name = input("What is the name of your pikachu? => ")
print(name)
often = input("How often do we see a Pokemon (turns)? => ")
print(often)
often = int(often)

turn = 0
location = (75,75)
record = []
#begin simulation
print("\nStarting simulation, turn {0} {1} at {2}".format(turn,name,location))
while turn < turns:
    #regular move
    direction = input("What direction does {0} walk? => ".format(name))
    print(direction)        
    direction = direction.upper()
    location = move_pokemon(location[0],location[1],direction,5)
    turn += 1    
    if turn % often == 0 and turn != 0: #pokemon encounter
        print("Turn {0}, {1} at {2}".format(turn,name,location))
        p_type = input("What type of pokemon do you meet (W)ater, (G)round? => ")
        print(p_type)
        p_type = p_type.upper()
        if p_type == 'W': #Win
            record.append('Win')
            #move pikachu in direction he was going previously, 1 space
            location = move_pokemon(location[0],location[1],direction,1)
            print("{0} wins and moves to {1}".format(name,location))
        elif p_type == 'G': #Lose
            record.append('Lose')
            #negate current direction
            if direction == 'N': direction = 'S'
            elif direction == 'S': direction = 'N'
            elif direction == 'E': direction = 'W'
            elif direction == 'W': direction = 'E'
            #move pikachu 10
            location = move_pokemon(location[0],location[1],direction,10)
            print("{0} runs away to {1}".format(name,location))
        else: #No Pokemon
            record.append('No Pokemon')

    
print("{0} ends up at {1}, Record: {2}".format(name,location,record))