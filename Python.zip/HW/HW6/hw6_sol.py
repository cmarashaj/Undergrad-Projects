''' 
Author: Caila Marashaj

This program reads data from a stop_words file, and 2 document files. It parses the distinct words in each file, and 
eliminates the stop words from processing. It then calculates outputs data about each document, and compares the two documents 

'''

def parse(filename): #return a set of parsed words from a given file
    file = open(filename)
    file = file.read() #convert file to string
    words = file.split()
    for i in range(len(words)):
        #remove whitespace
        #remove numbers
        #remove special characters
        for letter in words[i]:
            if letter.isalpha() == False:
                words[i] = words[i].replace(letter,'')
        #make lowercase
        words[i] = words[i].lower()
        #remove empty strings from the list        
    while '' in words: words.remove('')
    return words

def evaluate(words,filename,sep):
    #calculate and output average word length
    #using list and not set of words
    word_set = set(words)
    total_length = 0
    for i in range(len(words)):
        total_length += len(words[i])
    avg_length = total_length / len(words)
    print("1. Average word length: {0:.2f}".format(avg_length))  
    
    #ratio of distinct to total words
    word_ratio = len(word_set) / len(words)
    print("2. Ratio of distinct words to total words: {0:.3f}".format(word_ratio)) 
    
    #print word length sets
    print("3. Word sets for document {}:".format(filename))
    #remove words from word set until it's empty
    #increment from 1 to cover each word length
    word_len = 1
    while len(word_set) > 0: #keep going until all words are accounted for
        temp_set = set()
        #create set from words w given length
        for word in word_set:
            if len(word) == word_len:
                temp_set.add(word)
        #remove them from original set
        word_set -= temp_set
        temp_set = sorted(temp_set)
        #format
        newlist = []
        if len(temp_set) > 6:
            temp_list = list(temp_set)
            newlist = [temp_list[0],temp_list[1],temp_list[2] \
                       ,temp_list[-3],temp_list[-2],temp_list[-1]]
        #print beginning of line
        print((' '*(4-len(str(word_len)))) + '{0}:'.format(word_len) + \
              (' '*(4-len(str(len(temp_set))))) + '{0}:'.format(len(temp_set)),end='')
        if newlist == []: # if length <= 6 and doesnt need more formatting
            for word in temp_set:
                print(' '+word,end='')
        else: #set length > 6
            for i in range(len(newlist)):
                #print 3 words, then '...', then the other 3
                if i == 2: spacing = ' ...'
                else: spacing = ''
                print(' '+newlist[i],end=spacing)
        print()
        word_len+=1
        
    #word pairs
    print("4. Word pairs for document {}".format(filename))
    word_pairs = []
    #go through words list unsorted
    for i in range(len(words)): 
        for j in range(1,sep+1):
            tup = []
            #avoid leaving list bounds
            if (i+j) >= len(words): break
            #sort tuple and add to list of tuples
            tup = tuple(sorted([words[i],words[i+j]]))
            word_pairs.append(tup)
    #convert to set and back to list 
    #so we have only distinct elements, and can still index
    distinct_pairs = list(sorted(set(word_pairs)))
    #print number of pairs
    print("  {} distinct pairs".format(len(distinct_pairs)))
    #print first 5 pairs
    for i in range(5): print('  '+distinct_pairs[i][0],distinct_pairs[i][1])
    #only print rest if there are more than 5
    if len(distinct_pairs) > 5:
        print('  ...')
        for i in range(5,0,-1): print('  '+distinct_pairs[-i][0],distinct_pairs[-i][1])
    #distinct to total pairs ratio
    print("5. Ratio of distinct word pairs to total: {0:.3f}".format(len(distinct_pairs) / \
                                                                         len(word_pairs)))
        
    #need to store:
    #avg word length
    #word set
    #distinct pairs
    return (avg_length,set(distinct_pairs))
        
        
#take input
file1 = input("Enter the first file to analyze and compare ==> ")
print(file1)
file2 = input("Enter the second file to analyze and compare ==> ")
print(file2)
max_sep = input("Enter the maximum separation between words in a pair ==> ")
print(max_sep)
print()
max_sep = int(max_sep)

#get set of stop words
stop_words = set(parse("stop.txt"))
#get words from each file
words1 = parse(file1)
words2 = parse(file2)

#remove stop words from each set of words
for word in stop_words:
    while word in words1: words1.remove(word)
    while word in words2: words2.remove(word)
#output
print("Evaluating document",file1)
data1 = evaluate(words1,file1,max_sep)
print()
print("Evaluating document",file2)
data2 = evaluate(words2,file2,max_sep)
print() 
#get data for summary
length1 = data1[0]
pairs1 = data1[1]
set1 = set(words1)

length2 = data2[0]
pairs2 = data2[1]
set2 = set(words2)

#comparison
print("Summary comparison")
#determine avg word length comparison
if length1 > length2:
    more_complex = file1
    less_complex = file2
else:
    more_complex = file2
    less_complex = file1
print("1. {0} on average uses longer words than {1}".format(more_complex,less_complex))

#jaccard = len(a & b) / len(a | b)
#overall word use
overall_similarity = len(set1 & set2) / len(set1 | set2)
print("2. Overall word use similarity: {0:.3f}".format(overall_similarity))
#similarity by length
print("3. Word use similarity by length:")
word_len = 1
#go through all words in both sets
while len(set1 | set2) > 0:
    #create temp sets for each word length
    temp1 = set()
    temp2 = set()
    for word in set1:
        if len(word) == word_len:
            temp1.add(word)
    #remove the words added from original sets
    set1 -= temp1
    for word in set2:
        if len(word) == word_len:
            temp2.add(word)
    set2 -= temp2
    #jaccard similarity
    if len(temp1) == 0 or len(temp2) == 0: similarity = 0
    else: similarity = len(temp1&temp2) / len(temp1|temp2)
    print((" "*(4-len(str(word_len))))+ '{0}: {1:.4f}'.format(word_len,similarity))
    #increment word length
    word_len += 1

#similarity btwn word pair sets
pair_similarity = len(pairs1&pairs2) / len(pairs1|pairs2)
print("4. Word pair similarity: {0:.4f}".format(pair_similarity))