HOMEWORK 2: FOOTBALL CLASSES


NAME:  < Caila Marashaj >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< 
stackoverflow.com
cplusplus.com
en.cppreference.com
TA Tim
Mentor Vikram
Lauren McAlarney
Daniel Tabin
>

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 45 >



DESCRIPTION OF YOUR CREATIVE STATISTIC:
Please be concise!

For my creative statistic, I decided to sort each team by their average
points per game in descending order. If two ppg are equal, I sort by total
games played. If there is still a tie, I sort alphabetically.  




SAMPLE COMMAND LINE & OUTPUT OF YOUR CREATIVE STATISTIC:
Paste a small portion or your output here, and include the full output
file in your submission.  Also include your input dataset in the .zip
file if it is not one of the provided ones.

./time_test.exe example.txt test.txt --creative

ALL TEAMS, SORTED BY AVERAGE POINTS PER GAME
The    Chargers      averaged    33.00    points over    1    games.
The    Titans        averaged    25.00    points over    1    games.
The    Saints        averaged    20.50    points over    2    games.
The    Falcons       averaged    16.67    points over    3    games.
The    Steelers      averaged    15.00    points over    1    games.


MISC. COMMENTS TO GRADER:  
Optional, please be concise!
