''' 
Author: Caila Marashaj

This program finds and outputs the steepest paths for a given starting location on the grid

'''


import hw5_util as util

def get_nbrs(grid_,loc):
    neighbors = []
    row = loc[0]
    col = loc[1]
    #above neighbor
    if row > 0: neighbors.append((row-1,col))
    #left
    if col > 0: neighbors.append((row,col-1))  
    #right
    if col < len(grid[0])-1: neighbors.append((row,col+1))
    #below
    if row < len(grid)-1: neighbors.append((row+1,col))
    return neighbors    


def find_path(grid_,start,speed,step_height):
    #speed will be either gradual or steep
    #start is a location tuple
    last = (start,grid[start[0]][start[1]])
    path = [start]
    possible_change = []
    
    move_valid = True
    while move_valid:        
        possible_change = []
        #compare neighbors and find either steepest or gradual change
        #can't be greater than step height
        #can't be lower or equal to current height
        current_nbrs = get_nbrs(grid_,last[0])
        row = last[0][0]
        col = last[0][1]
        height = last[1]
        for nbr in current_nbrs:
            if grid_[nbr[0]][nbr[1]] > height:
                if grid_[nbr[0]][nbr[1]] - height <= step_height:
                    diff = grid_[nbr[0]][nbr[1]] - height
                    #valid possible step
                    possible_change.append((nbr, diff))
        if possible_change == []:
            #no more moves
            move_valid = False
            continue
        #compare valid moves to find the steepest or most gradual
        current = (0,0)
        if speed == 'steep':
            change = 0
            #find maximum change in height
            for i in possible_change:
                if i[1] > change:
                    change = i[1]
                    current = (i[0][0],i[0][1])
            path.append(current)
            path_count[current[0]][current[1]] += 1
            last = (current,grid[current[0]][current[1]])
        elif speed == 'gradual':
            change = 1000
            for i in possible_change:
                if i[1] < change:
                    change = i[1]
                    current = (i[0][0],i[0][1])
            path.append(current)
            path_count[current[0]][current[1]] += 1
            last = (current,grid[current[0]][current[1]])            
    return path
                    
        

    
def find_global_max(grid): #return tuple (loc, height)
    max_height = 0
    max_loc = (0,0)
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            #if current height > max, reset max and associated location
            if grid[i][j] > max_height:
                max_height = grid[i][j]
                max_loc = (i,j)
    return (max_loc, max_height)
    
        

grid_found = False
while not grid_found:
    #input
    desired_grid = input("Enter a grid index less than or equal to 3 (0 to end): ")
    print(desired_grid)
    desired_grid = int(desired_grid)
    step_height = input("Enter the maximum step height: ")
    print(step_height)
    step_height = int(step_height)
    print_req = input("Should the path grid be printed (Y or N): ")
    print(print_req)
    print_req = print_req.upper()
    
    if desired_grid >= 1 and desired_grid <=util.num_grids(): grid_found = True

grid = util.get_grid(desired_grid)
#path grid initialization
path_count = []
for i in range(len(grid)):
    path_count.append([])
    for j in range(len(grid[0])):
        path_count[i].append(0)

print("Grid has {0} rows and {1} columns".format(len(grid),len(grid[0])))
start_locations = util.get_start_locations(desired_grid)
#find global max
max_location = find_global_max(grid)
print("global max: {0} {1}".format(max_location[0],max_location[1]))
print("===")
for loc in start_locations:
    #print steepest path
    steep_path = find_path(grid,loc,'steep',step_height)
    grad_path = find_path(grid,loc,'gradual',step_height)
    #print whether it reaches local or global max
    #steepest
    print("steepest path")
    for i in steep_path: print("{} ".format(i),end='')
    if steep_path[-1] == max_location[0]:
        print("global maximum")
    else: print("local maximum")
    print("...")
    #gradual
    print("most gradual path")
    for i in grad_path: print("{} ".format(i),end='')
    if grad_path[-1] == max_location[0]:
        print("global maximum")
    else: print("local maximum") 
    print("===")
#path grid
if print_req == 'Y':
    print("Path grid")
    for i in path_count:
        for j in i:
            if j == 0: print('. ',end='')
            else: print(str(j) + ' ',end='')
        print()