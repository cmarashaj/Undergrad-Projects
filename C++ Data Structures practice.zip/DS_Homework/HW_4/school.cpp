#include "school.h"

//default constructor
School::School() {
	num_accepted = 0;
	num_slots = 0;
	preference = preference_list.begin();
}
//constructor
School::School(std::string name_, int num_slots_) {
	name = name_;
	num_accepted = 0;
	num_slots = num_slots_;
	preference = preference_list.begin();
}
//print out every student who will attend the school, and the number of slots left open
void School::PrintSchoolEnrollment(std::ofstream &ostr) {
	std::list<std::string>::iterator it;
	enrolled.sort(alpha_student);
	ostr << "student(s) who will be attending " << name << ":" <<std::endl;
	for (it = enrolled.begin(); it != enrolled.end(); ++it) {
		ostr << "  " << *it << std::endl;
	}
	if ((num_slots-enrolled.size()) > 0) {
		ostr << "  [" << (num_slots-enrolled.size()) << " remaining slot(s) in enrollment]" << std::endl;
	}
}

int School::GetNumSlots() const {return num_slots;}
//push back onto the preference list
void School::AddStudent(std::string student_name) {
	//error check: make sure student isnt already on the list
	for (std::list<std::string>::iterator i = preference_list.begin(); i != preference_list.end(); ++i) {
		if (student_name == *i) {
			std::cerr << "WARNING: could not add " << student_name 
			<< " into school preference list, this student is already in the list" << std::endl;
			return;
		}
	}
	this->preference_list.push_back(student_name);
}

//preference list getter
std::list<std::string> School::Preferences() {
	return preference_list;
}
 
void School::InsertStudentIntoSchoolPreferenceList(std::string new_student, std::string before_student) {
	//return error if the before_stu isnt in the list or if new student is already in list
	bool found = false;
	for (std::list<std::string>::iterator x = preference_list.begin(); x != preference_list.end(); ++x) {
		if (*x == before_student) {
			found = true;
		}
	}
	if (!found) {
		std::cerr << "WARNING: could not insert new student into school preference list before "
		<< before_student << ", this student is not in the list" << std::endl;
		return;
	}

	for (std::list<std::string>::iterator j = preference_list.begin(); j != preference_list.end(); ++j) {
		if (new_student == *j) {
			std::cerr << "WARNING: could not insert " 
			<< new_student << " into school preference list, this student is already in the list" << std::endl;
			return;
		}
	}
	
	//insert desired student onto preference list, then break
	std::list<std::string>::iterator i;
	for (i = preference_list.begin(); i != preference_list.end(); ++i) {
		if (*i == before_student) {
			preference_list.insert(i, new_student);
			break;
		}
	}
}

void School::PrepareToMakeOffers() {}

//member variable getter
int School::NumAcceptedStudents() const {return num_accepted;}

int School::MaxAcceptedStudents() {return num_slots;}

std::string School::MakeNextOffer() {
	//if the school has a preference, make the offer
	if (preference_list.size () > 0 ) {
		std::list<std::string>::iterator temp = preference_list.begin();
		std::string str = *temp;
		preference_list.pop_front();
		return str;
	}
	//if not, return an empty string
	return "";
}
//increment number of accepted students and push back onto enrolled students list
void School::StudentTentativelyAcceptsOffer(std::string student_name) {
	num_accepted++;
	this->enrolled.push_back(student_name);
}

//remove student who withdraws from school enrollment list
void School::StudentDeclinesTentativeAcceptance(std::string studentname) {
	std::list<std::string>::iterator i;
	for (i = enrolled.begin(); i != enrolled.end(); ++i) {
		if (studentname == *i) {
			enrolled.erase(i);
			break;
		}
	}
}

//nonmember alphabetical sorting functions
bool alpha_by_school_name (const School& a, const School& b) {
	return a.GetName() < b.GetName();
}

bool alpha_student (const std::string& a, const std::string& b) {
	return (a < b);
}