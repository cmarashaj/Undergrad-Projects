#include "student.h"
//default constructor
Student::Student () {}
//constructor
Student::Student(std::string name_) {
	name = name_;
}

std::string Student::GetName() const { return name;}

std::list<std::string> Student::Preferences() {return preference_list;}
	 
void Student::AddSchool(std::string school_name) {
	//error check: make sure school isnt already in preferences
	for (std::list<std::string>::iterator i = preference_list.begin(); i != preference_list.end(); ++i) {
		if (school_name == *i) {
			std::cerr << "WARNING: could not add " << school_name 
			<< " into student preference list, this school is already on the list" << std::endl;
			return;
		}
	}
	//push back
	preference_list.push_back(school_name);
}

void Student::RemoveSchoolFromPreferenceList(std::string school_name) {
	//go through list via iteration, check if school name == iteration pointer
	std::list<std::string>::iterator i;
	for (i = preference_list.begin(); i != preference_list.end(); ++i) {
		if (*i == school_name) {
			preference_list.erase(i);
			//dont need to continue looping
			break;
		}
	}
}
	 
void Student::PrepareToReceiveOffers() {}

void Student::PrintStudentDecision(std::ofstream &ostr) const {
	//account for whether or not he student is enrolled in a school, print decision
	//based on best offer
	if (GetBestOffer() != "") {
		ostr << name << " will be attending " << GetBestOffer() << std::endl;
	}
	else {
		ostr << name << " has not received an acceptable offer" << std::endl;
	}
}
	 
//returns true if they hvae at least one offer
bool Student::HasOffer() {
	if (offers.size() > 0) {
		return true;
	}
	else {
		return false;
	}
}
	 
std::string Student::GetBestOffer() const {
	return bestoffer;	
}
	 
bool Student::IsOfferTentativelyAccepted(std::string schoolname) {
	
	
	//if the school is not in the student's preference list, return false
	std::list<std::string>::iterator check;
	bool isinlist = false;
	for (check = preference_list.begin(); check!= preference_list.end(); ++check) {
		if (*check == schoolname) {
			isinlist = true;
		}
	}

	if (!isinlist) {
		return false;
	}

	//if there are no other offers, return true and redefine best offer variable
	if (offers.size() == 0) {
		bestoffer = schoolname;
		this->offers.push_back(schoolname);
		return true;
	}

	//push back onto offers list
	this->offers.push_back(schoolname);
	 
	//go through preferences list
	//the loop will only find either bestoffer first, in which case the student is 
	//...interested in the school's offer
	//or the offering school's name first, in which case redefine best offers
	std::list<std::string>::iterator i;
	for (i = preference_list.begin(); i != preference_list.end(); ++i) {
		if (*i == bestoffer) {
			return false;
			break;
		}
		else if (*i == schoolname) {
			bestoffer = schoolname;
			return true;
			break;
		}
	}
	//if it's not found in preferences(just to be sure) return false
	return false;

}
//nonmember alphabetical sort functions
bool alpha_by_student_name (const Student& a, const Student& b) {
	return (a.GetName() < b.GetName());
}

bool alpha_school (const std::string& a, const std::string& b) {
	return a < b;
}