''' 
Author: Caila Marashaj

This program takes in a dictionary, keyboard file, and input file, and uses the keyboard and dictionary to correct 
the words given in the input file. It outputs the correctness of the original input word, and if it is not a valid word gives a 
list of candidate correction words instead.

'''

def drop(word,dictionary):
    output = dict()
    #go through every index and drop only the element there
    for i in range(len(word)+1):
        temp = word[:i] + word[i+1:]
        #if the word is found
        if temp in dictionary:
            output[temp] = dictionary[temp]
    return output
    
def insert(word,dictionary):
    output = dict()
    alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', \
                'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'}
    #go though every space and try to insert a word from alphabet
    for i in range(len(word)+1):
        for letter in alphabet:
            temp = word[:i] + letter + word[i:]
            #if found
            if temp in dictionary:
                output[temp] = dictionary[temp]
    return output

def swap(word,dictionary):
    output = dict()
    #go through every space between letters and try to swap the two adjacent letters
    for i in range(len(word)-1):
        temp = word[:i] + word[i+1] + word[i] + word[i+2:]
        #if found
        if temp in dictionary:
            output[temp] = dictionary[temp]
    return output

def replace(word,dictionary,keyboard):
    output = dict()
    #go through every index and try to replace the element there with
    # a letter from the correct keyboard list
    for i in range(len(word)):
        for j in range(len(keyboard[word[i]])):
            temp = word[:i] + keyboard[word[i]][j] + word[i+1:]
            #if found, save word and frequency
            if temp in dictionary:
                output[temp] = dictionary[temp]   
    return output
                
#get user input
dict_file = (input("Dictionary file => ")).strip()
print(dict_file)
dict_file = open(dict_file)
input_file = (input("Input file => ")).strip()
print(input_file)
input_file = open(input_file)
key_file = (input("Keyboard file => ")).strip()
print(key_file)
key_file = open(key_file)

#read input file data
dict_data = dict()
for line in dict_file:
    line = line.strip()
    line = line.strip('\n')
    line.strip('\r')
    line.strip('\t')
    line = line.split(',')
    #input_data[word] = frequency
    dict_data[line[0]] = line[1]
    
#read keyboard data
keyboard = dict()
for line in key_file:
    line = line.strip()
    line = line.strip('\n')
    line.strip('\r')
    line.strip('\t')
    line = line.split(' ')
    #first letter is index, the rest are the value list
    keyboard[line[0]] = line[1:]
    
#get list of input words
input_list = []
for line in input_file:
    line = line.strip()
    line = line.strip('\n')
    line.strip('\r')
    line.strip('\t')
    input_list.append(line)

#go through input list and correct words
for word in input_list:
    found_words = dict()
    dict_list = []
    #find - if found, don't try to fix
    if word in dict_data:
        print((word+' ->').rjust(18), 'FOUND')
    else:
        #drop
        dict_list.append(drop(word,dict_data))
        #insert
        dict_list.append(insert(word,dict_data))
        #swap
        dict_list.append(swap(word,dict_data))
        #replace
        dict_list.append(replace(word,dict_data,keyboard))
        #combine dict_list data into one dictionary
        for dictionary in dict_list:
            for entry in dictionary.keys():
                found_words[entry] = dictionary[entry]
                
        if len(found_words) > 0:
            sort = []
            #sort by frequency using tuples
            for entry in found_words.keys():
                sort.append((found_words[entry],entry))
            sort.sort(reverse=True)
            #output
            print((word+' ->').rjust(18),'FOUND '+(str(len(found_words))+':').rjust(3),end=' ')
            if len(found_words) > 3:
                #only print first 3 words
                found_keys = list(found_words.keys())
                for i in range(3):
                    print(' '+sort[i][1],end='')
            else: #print all w no formatting
                for entry in sort:
                    print(' '+entry[1],end='')
            print()
        #if not found
        else: print((word+' ->').rjust(18),'NOT FOUND')
