'''
Author: Caila Marashaj

This program rates an input password based on a variety of criteria, and outputs
the grade along with the relevant criteria
'''

import hw4_util as util

def rate_password(pw):
    score = 0
    #length
    if len(pw) == 6 or len(pw) == 7: score+=1 
    if len(pw) > 7 and len(pw) <= 10: score+=2
    if len(pw) > 10: score+=3
    if len(pw) >= 6: print("Length: +{}".format(score))
    #case
    cap = 0
    low = 0
    dig = 0
    #special characters
    sp1 = 0
    sp2 = 0
    for char in pw:
        #keep track of capital letters
        if char.isupper(): cap+=1
        #keep track of lowercase letters
        elif char.islower(): low+=1
        #keep track of numbers within the string
        elif char.isdigit(): dig+=1
        #keep track of special characters 1-4
        if char=='!' or char=='@' or char=='#' or char=='$':
            sp1 = 1
        #keep track of special characters 5-8 
        if char=='%' or char=='^' or char=='&' or char=='*':
            sp2 = 1
    #if 2 capital letters and 2 lowercase letters, add 2
    if cap>=2 and low>=2: 
        print("Cases: +2") 
        score+=2
    #if 1 capital and 1 lowercase, add 1
    elif cap>=1 and low>=1: 
        score+=1
        print("Cases: +1")
    #if more than 2 digits, add 2
    if dig>=2: 
        score+=2
        print("Digits: +2")
    #if digits > 1, add 1
    elif dig>=1: 
        score+=1
        print("Digits: +1")
    #special characters
    if sp1 == 1: print("!@#$: +1")
    if sp2 == 1: print("%^&*: +1")
    score += (sp1+sp2) #special char 
    #ny license
    if ny_license(pw): 
        score -= 2
        print("License: -2")
    #common
    common = util.part1_get_top()
    #make lowercase to compare w common passwords
    lowpw = pw.lower()
    for i in range(len(common)):
        if lowpw == common[i]: 
            print("Common: -3")
            score -= 3
    return score
    
def ny_license(pw): #returns true if you should subtract 2 from score
    #cant be less than 7 characters to match ny license
    if len(pw) < 7: return False 
    else:
        for i in range(len(pw)):
            if i+6 > len(pw)-1: #don't leave bounds
                break
            letters = 0 #counts letters in a row
            numbers = 0 #counts numbers in a row
            for j in range(3):
                #if numbers show up first, break
                if pw[i+j].isalpha() == False: break
                #must be a letter otherwise
                letters += 1
                #when program finds 3 letters in a row, look for 4 numbers
                if letters == 3:
                    for k in range(4):
                        if pw[i+k+3].isdigit() == False: break
                        numbers += 1
                    if numbers == 4: return True
    #if it gets here, there is no abc1234 pattern
    return False

password = input("Enter a password => ")
print(password)
#formatting
password = password.strip('\r')
rating = rate_password(password)
#decide what to do w password
quality = ''
if rating < 1: quality = 'rejected'
elif rating == 1 or rating == 2: quality = 'poor'
elif rating == 3 or rating == 4: quality = 'fair'
elif rating == 5 or rating == 6: quality = 'good'
elif rating >= 7: quality = 'excellent'
#output
print("Combined score:",rating)
print("Password is",quality)