#include <iostream>
#include <cassert>
#include <cstdlib>
#include <typeinfo>
#include <string>

//Node class creates Node information
//stores Node value and up,down,left,right pointers
template <class T>
class Node {
public:
	Node<T> *up;
	Node<T> *down;
	Node<T> *left;
	Node<T> *right;
	T value_;
	Node<T>* next_;
	Node<T>* prev_;
};

template <class T> 
class GridIterator {
public:
	//constructor
	GridIterator(Node<T>* p=NULL) : ptr(p) {}
	//move right,left,up,down would be used for creating iteration patterns and setting up 
	//operator functions for different iteration patterns
	GridIterator<T>& right() {ptr = ptr->right;}	
	GridIterator<T>& left() { ptr = ptr->left;}
	GridIterator<T>& up() {ptr = ptr->up;}
	GridIterator<T>& down() {ptr = ptr->down;}
	//dereference operator
	GridIterator<T>& operator*() {return ptr->value_;}
	//operator functions, used for incrementing through grid in desired pattern
	GridIterator<T>& operator++() {
		ptr = ptr->next_;
 		return *this;}
	GridIterator<T>& operator++(int) {
		GridIterator<T> temp(*this);
 		ptr = ptr->next_;
 		return temp;
	}
	GridIterator<T>& operator--() {
		ptr = ptr->prev_;
 		return *this;
	}
	GridIterator<T>& operator--(int) {
		GridIterator<T> temp(*this);
 		ptr = ptr->prev_;
 		return temp;
	}
private:
	Node<T>* ptr; 

};

template <class T>
class Grid {
public:
	//constructor
	Grid(int width_, int height_, const T& val_ = T());
	Grid& operator= (const Grid<T>& oldgrid);
	// ~Grid() { delete grid;}
	void print(); // {std::cout << "aaahhhh" << std::endl;}
	
	//set the value of a node at a specific index
	void set(int row, int column, const T& setval);
	
	//get the value at a specific index
	T get(int row_, int column_);
	
	//join two grids by stacking them on top of each other
	//add the second grid onto the first, then delete the second one
	void stack(Grid<T>& grid2);
	
	//join two grids horizontally
	void join();
	//getter for lower left node
	Node<T>* getLowerLeft() {return lower_left;}
	
	//separate a grid vertically into two new grids
	void lift();
	
	//chop should take in iterator and empty grid
	//separates grid vertically by detaching right and left
	//pointers at desired column and resetting them to NULL
	void chop();
	int getWidth() {return width;}
	//reset sets every value in a grid equal to one value,
	//similar to the constructor
	void reset(char c);
	int getHeight(){return height;}
	int getSize(){return (width*height);}
	
	//use griditerator operators to move through 
	//the grid in different patterns
	void begin_upper_left();
	void begin_upper_right();
	void begin_lower_left();
	void begin_lower_right();
	void begin_snake();
	void begin_spiral();

private:
	Node<T> *upper_left;
	Node<T> *lower_left;
	Node<T> *upper_right;
	Node<T> *lower_right;
	int width;
	int height;

};

//grid constructor
template <class T>
Grid<T>::Grid(int width_, int height_, const T& val_) {
	//private member variable definition
	width = width_;
	height = height_;

	//create pointer to later hold current node and variables to point the node to
	Node<T> *current = NULL;
	Node<T> *up_ = NULL;
	Node<T> *left_ = NULL;
	// Node<T> *down_ = NULL;
	
	// move column by column inside one row at a time
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			current = new Node<T>;
			
			//set default null value for pointers to avoid 
			//	uninitialized reads
			current->right = NULL;
			current->left = NULL;
			current->up = NULL;
			current->down = NULL;
			current->value_ = val_;
			
			//determine if current node is a corner and set member variables accordingly
			if (i == 0 && j == 0) {
				upper_left = current;
			}
			else if (i == 0 && j == (width_-1)) {
				upper_right = current;
			}
			else if (i == (height_-1) && j == 0) {
				lower_left = current;
			}
			else if (i == (height_-1) && j == (width-1)) {
				lower_right = current;
			}
			
			//set left and up pointers
			current->left = left_;
			current->up = up_;
			
			//set down pointer
			if (up_ != NULL) {
				up_->down = current;	
			}

			//nested if statements make sure that current->up->right is not a null pointer
			//	and therefore can be used to reassign up_ for next iteration
			if (current != NULL) {
				if (current->up != NULL) {
					if (up_->right != NULL) {
						up_ = current->up->right;
					}
				}
			}

			//set right pointer if appropriate
			if (left_ != NULL) {
				left_->right = current;	
			}
			
			//move left_ placeholder to the right for next iteration
			left_ = current;
		}
		
		//after a row is completed, move the current placeholder 
		//	back to the leftmost column
		while (current->left != NULL) {
			current = current->left;
		}

		//set up placeholder for next row iteration
		up_ = current;

		//because current is all the way to the left, its
		//	left pointer is null
		left_ = NULL;
	}		
}


template <class T>
T Grid<T>::get(int row_, int column_) {
	//create node pointer to move through grid
	Node<T> *cur = upper_left;
	//move down to the desired row
	for (int x = 0; x < column_; x++) {
		cur = cur->down;
	}
	//move right to the desired column
	for (int y = 0; y < row_; y++) {
		cur = cur->right;
	}	
	return cur->value_;
}

template <class T>
void Grid<T>::set(int row, int column, const T& setval) {
	//placeholder to move through grid
	Node<T> *cur = upper_left;	
	//move down to desired row
	for (int x = 0; x < column; x++) {
		cur = cur->down;
	}
	//move right to desired column
	for (int y = 0; y < row; y++) {
		cur = cur->right;
	}	
	//reassign value
	cur->value_ = setval;
}

template <class T>
void Grid<T>::print() {
	//loop through every node and print value
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			if (get(j,i) > 9 && get(j,i) < 100) {
				std::cout << "  " << get(j,i);
			}
			else if (get(j,i) > 99) {
				std::cout << ' ' <<get(j,i);
			}
			else {
				std::cout << "   " << get(j,i);
			}
		} std::cout << std::endl;
	}
}

//stack should loop through every column in the top row of
//the original grid and sets its up pointer to the corresponding
//column in the bottom row of the new grid, and sets the down pointers for the
//bottom row of the new grid to the top row of the original grid
template <class T>
void Grid<T>::stack(Grid<T>& grid2) {
}