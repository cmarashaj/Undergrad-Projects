HOMEWORK 6: INVERSE SLITHERLINK CONTEST


NAME:  < Caila Marashaj >



COLLABORATORS AND OTHER RESOURCES:
< Lauren McAlarney
  Kevin Cruz
 >



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
Works within a second for puzzle 1, doesn't find complete solutions for any other puzzles



OPTIONAL: NEW SLITHERLINK PUZZLE OR INVERSE SLITHERLINKPATH FILES
Be sure to name the files puzzle_smithj.txt and inverse_smithj.txt
Describe your goal in the design of this input files.



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
# of solutions & approximate wall clock running time for different
puzzles for a single solution or all solutions.
1 solutions, about 1 second