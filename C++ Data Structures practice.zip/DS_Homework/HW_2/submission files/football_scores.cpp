#include <iomanip>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>
#include "football_game.h"
#include "team_stats.h"


//this function sorts Team_Stats objects based on average points per game in each team
//I will be using this for my creative statistic
bool ppg_sort(const Team_Stats A, const Team_Stats B) {
	if (A.AvgPPG() == B.AvgPPG()) {
		if (A.TotalGames() == B.TotalGames()) {
			if (A.getTeamName() < B.getTeamName()) {
				return A.AvgPPG() < B.AvgPPG();
			}
			else {
				return A.AvgPPG() > B.AvgPPG();
			}
		}

		else {	
			return A.AvgPPG() < B.AvgPPG();
		}
		
	}
	else {
		return A.AvgPPG() > B.AvgPPG();
	}
}

//this function formats and prints the output for my creative statistic using setw and setfill
//need to pass output file by reference so I can write output onto the file
//   from functions other than main
void ppg_out(std::vector<Team_Stats>& ts_objects, std::ofstream &outputFile) {
	int name_len = 0;
	//for loop reassigns the variable name_len, which represents the longest
	//    team name for formatting, when any team name in my vector of 
	//    Team_Stats objects is longer than the previous assignment of the variable
	for (unsigned int i = 0; i < ts_objects.size(); i++) {
		if (ts_objects[i].getTeamName().length() > name_len) {
			name_len = ts_objects[i].getTeamName().length();
		}
	}
	//sorts vector of Team_Stats objects by their average points per game
	std::sort(ts_objects.begin(), ts_objects.end(), ppg_sort);
	//formatting and output
	outputFile << "ALL TEAMS, SORTED BY AVERAGE POINTS PER GAME" << std::endl;
	for (unsigned int i = 0; i < ts_objects.size(); i++) {
		outputFile
		<< "The   " << std::left << std::setw(name_len+2) << std::setfill(' ')
		<< ts_objects[i].getTeamName() 
		<< "   averaged    "
		<<std::fixed << std::setprecision(2) << ts_objects[i].AvgPPG()
		<< "   points over    "
		<< ts_objects[i].TotalGames()
		<< "   games." << std::endl;
	}
}

//this function sorts football games by their point differential, total
//   points, and team name respectively for --total_points output
bool diff_sort(const Football_Game A, const Football_Game B) {
	if (A.differential() == B.differential()) {
		if (A.TotalPoints() == B.TotalPoints()) {
			if (A.getTeam1() < B.getTeam1()) {
				return A.differential() < B.differential();
			}
			else {
				return A.differential() > B.differential();
			}
		}

		else {	
			return A.differential() < B.differential();
		}
		
	}
	else {
		return A.differential() < B.differential();
	}
}

//this function formats and write output for --total_points output
void diff_out(std::vector<Football_Game>& fg_objects, std::ofstream &outputFile) {
	//two variables to keep track of longest visitor team name and longest
	//   home team name
	int team1_len = 0;
	int team2_len = 0;

	//for loop reassigns each variable when it finds a team name from my vector
	//  of Football_Game objects that is longer than the current length value
	for (unsigned int i = 0; i < fg_objects.size(); i++) {
		std::string name1_temp = fg_objects[i].getTeam1();
		std::string name2_temp = fg_objects[i].getTeam2();
		
		if (name1_temp.length() > team1_len) {
			team1_len = name1_temp.length();
		}
		if (name2_temp.length() > team2_len) {
			team2_len =  name2_temp.length();
		}
	}

	//sort vector of Football_Game objects by point differential
	std::sort(fg_objects.begin(), fg_objects.end(), diff_sort);
	//formatting and output for --total_points argument
	outputFile << "ALL GAMES, SORTED BY POINT DIFFERENTIAL:" << std::endl;
	
	//for loop prints out every element in Football_Game objects vector
	//   with appropriate spacing
	for (unsigned int i = 0; i < fg_objects.size(); i++) {
		std::string outcome;
		if (fg_objects[i].Team1Final() > fg_objects[i].Team2Final()) {
			outcome = " defeated";
		}
		else {
			outcome = "lost to";
		}
		outputFile
		<< std::left << std::setw(team1_len+2) << std::setfill(' ')
		<< fg_objects[i].getTeam1() << std::left << std::setw(10) 
		<< outcome << std::left << std::setw(team2_len+2) << fg_objects[i].getTeam2()
		<< std::right << std::setw(2) << fg_objects[i].Team1Final()
		<< " - " << std::right << std::setw(2) << fg_objects[i].Team2Final()
		<< "  differential =" << std::right << std::setw(4) << fg_objects[i].differential()
		<< "  total points =" << std::right << std::setw(5) << fg_objects[i].TotalPoints()
		<<std::endl;
	}
}

//this function sorts Team_Stats objects based on each team's win percentage
// looks for difference in win percentage, then total games played, then team names
bool winp_sort(const Team_Stats A, const Team_Stats B) {
	if (A.getWinP() > B.getWinP()) {
		return A.getWinP() > B.getWinP();
	}
	else if (A.getWinP() == B.getWinP()) {
		if (A.TotalGames() > B.TotalGames()) {
			return A.getWinP() > B.getWinP();
		}
		else if (A.TotalGames() == B.TotalGames()) {
			if (A.getTeamName() > B.getTeamName()) {
				return A.getWinP() > B.getWinP();
			} 
			else {
				return A.getWinP() < B.getWinP();
			}
		}
		else {
			return A.getWinP() < B.getWinP();
		}
	}
	else {
		return B.getWinP() < A.getWinP();
	}
	}

//this function formats and writes output for --win_percentage output
void winp_out(std::vector<Team_Stats>& ts_objects, std::ofstream &outputFile) {
	//sort Team_Stats objects based on win percentage
	std::sort(ts_objects.begin(), ts_objects.end(), winp_sort);
	//keep track of longest team name for formatting
	int name_len = 0;
	for (unsigned int i = 0; i < ts_objects.size(); i++) {
		if (ts_objects[i].getTeamName().length() > name_len) {
			name_len = ts_objects[i].getTeamName().length();
		}
	}
	//for loop provides appropriate spacing and output for each Team_Stats element
	outputFile << "ALL TEAMS, SORTED BY WIN PERCENTAGE:" << std::endl;
	for (unsigned int i = 0; i < ts_objects.size(); i++) {
		outputFile 
		<< std::left << std::setw(name_len + 2) << std::setfill(' ') 
		<< ts_objects[i].getTeamName() 
		<< " " << ts_objects[i].getWins()
		<< " win(s)  -   " << ts_objects[i].getLosses() 
		<< " loss(es)    " 
		<< std::fixed << std::setprecision(2) 
		<< ts_objects[i].getWinP() << std::endl;
	}
	}

int main (int argc, char** argv) {
	
	//allows us to read in input file
	std::ifstream input_file(argv[1]);

	//allows us to write onto output file
	std::ofstream outputFile;
	//open the file for writing
	outputFile.open(argv[2]);

	//initialize vector to hold Football_Game objects
	std::vector <Football_Game> fg_objects; 
	//reads until end of the file, erases local variables before
	//  each iteration after the first
	while (!input_file.eof()) {

		//initialize Football_Game arguments
		std::string day, month, team1, team2;
		std::string date_num, year;
		std::vector <std::string> date;
		
		std::vector<int> team1scores, team2scores;

		//read text between whitespace into appropriate variables
		input_file >> day >> month >> date_num >> year;
		//controls for empty last line of input file
		if(day.empty()) {
			break;
		}

		// assigning date vector elements to use in Football_Game objects argument
		date.push_back(day);
		date.push_back(month);
		date.push_back(date_num);
		date.push_back(year);

		//read team names into "team1" and "team2"
		input_file >> team1;
		// for loops push back the score for each quarter, overtime, 
		// and final score onto vector
		for(int i = 0; i < 6; i++){
			int num = 0;
			input_file >> num;
			team1scores.push_back(num);
		}
		input_file >> team2;
		
		for(int i = 0; i < 6; i++){
			int num = 0;
			input_file >> num;
			team2scores.push_back(num);
		}
		//creates Football_Game object in loop
		Football_Game fg_temp(date, team1, team1scores, team2, team2scores);
		//pushes them onto vector for reference later
		fg_objects.push_back(fg_temp);
	}
	//end of while loop

	//create vector of team names to make Team_Stats objects with
	std::vector<std::string> team_names;
	for (unsigned int i = 0; i < fg_objects.size(); i++) {
		std::string name;
		name = fg_objects[i].getTeam1();
		// if name of team1 is in team names vector already, continue 
		//  loop without any further action
		if (std::find(team_names.begin(), team_names.end(), name) 
			!= team_names.end()) {
			continue;
		}

		//if team1's name isn't already in team names vector, add it on
		else {
		team_names.push_back(name);
		}
		
		//reassign name variable to look for the name of team 2
		name = fg_objects[i].getTeam2();
		//if team 2's name is already in the vector, continue 
		// loop without any further action
		if (std::find(team_names.begin(), team_names.end(), name) 
			!= team_names.end()) {
			continue;
		}

		// if team2's name is not already in team names vector, add it on
		else {
		team_names.push_back(name);
		}
	}
	
	//initialize variables to represent Team_Stats arguments
	double games_played;
	double wins;
	double losses;
	int all_game_points;
	//create vector to hold Team_Stats objects after each iteration 
	// of the for loop
	std::vector<Team_Stats> ts_objects;
	// go through the name of each team
	for (unsigned int i = 0; i < team_names.size(); i++) {
		//wipe every variable after each iteration
		games_played = 0;
		wins = 0;
		losses = 0;
		all_game_points = 0;
		//go through every game
		for (unsigned int j = 0; j < fg_objects.size(); j++) {
			//if the team name under question is either team 1
			// in any given football game, add to games_played
			if (team_names[i] == fg_objects[j].getTeam1()) {
				all_game_points += fg_objects[j].Team1Final();
				games_played += 1;
				//if they won said football game, add to wins
				if (team_names[i] == fg_objects[j].winning_team()) {
					wins += 1;
			}
				// if the team lost, add to loses
				else if (team_names[i] == fg_objects[j].losing_team()) {
					losses += 1;
				}
			}
			//if team name under question is team 2 in said football game
			else if (team_names[i] == fg_objects[j].getTeam2()) {
				all_game_points += fg_objects[j].Team2Final();
				// add to games played
				games_played += 1;
				//if they won, add to wins
				if (team_names[i] == fg_objects[j].winning_team()) {
					wins += 1;
				}
				//if they lost, add to losses
				else if (team_names[i] == fg_objects[j].losing_team()) {
					losses += 1;
				}
			}
		}
		
		//create remaining arguments needed for Team_Stats class
		double win_p = (wins / games_played);
		std::string name;
		name = team_names[i];
		//create Team_Stats object
		Team_Stats ts_temp(name, wins, losses, win_p, all_game_points);
		//push onto vector to save after the for loop evaluates the next i value
		ts_objects.push_back(ts_temp);
	}
	//end of for loop

//there should be no less than 3 and no more than 4 command arguments given
	// if there are, return an error message
if (argc < 3 || argc > 4 ) {
	outputFile << "Error: Incorrect number of arguments" << std::endl;
}

//if there is no optional argument present, write all 3 possible outputs
// to output file
else if (argc == 3) {
	//call each output function, create a line of whitespace between each 
	// output
	diff_out(fg_objects, outputFile);
	outputFile << "" << std::endl;
	winp_out(ts_objects, outputFile);
	outputFile << "" << std::endl;
	ppg_out(ts_objects, outputFile);
}

//if third argument is present and is --total points, output only
// differential-based sorting of football games
else if (argc == 4 && strcmp(argv[3], "--total_points") == 0 ) {
	diff_out(fg_objects, outputFile);
}

//if third argument is --win_percentage, output only win-percentage
// based sorting of football teams
else if (argc == 4 && strcmp(argv[3], "--win_percentage") == 0) {
	winp_out(ts_objects, outputFile);
}

//if third argument is --creative, output only creative statistic output
else if (argc == 4 && strcmp(argv[3], "--creative") == 0) {
	ppg_out(ts_objects, outputFile);
}

// if third argument is invalid, print error message
else {
	outputFile << "Invalid arument(s)" << std::endl;
}

//close the output file
outputFile.close();

return 0;
}
//end main