"""
Author: Caila Marashaj

This program calculates the number of bears, tourists, and berries given 
start values of the bear population and berry forest area for 10 years
"""
import math

def num_tourists(num_bears):
    if num_bears < 4 or num_bears > 15: return 0
    else:
        if num_bears <= 10: return 10000*num_bears
        elif num_bears > 10: return 20000*(num_bears-10) + 100000
        
def find_next(bears,berries,tourists):
    bears_next = berries/(50*(bears+1)) + bears*0.60 - (math.log(1+tourists,10)*0.1)
    berries_next = (berries*1.5) - (bears+1)*(berries/14) - \
        (math.log(1+tourists,10)*0.05)
    #cut off values at 0
    if bears_next < 0: bears_next = 0
    bears_next = math.floor(bears_next)
    if berries_next < 0: berries_next = 0
    return (bears_next, berries_next)

#input
bears = input("Number of bears => ")
print(bears)
bears = int(bears)

berries = input("Size of berry area => ")
print(berries)
berries = float(berries)

#first year tourists
tourists = num_tourists(bears)


tourists_sum = []
bears_sum = []
berries_sum = []
#output
print("Year      Bears     Berry     Tourists  ")
for i in range(1,11): #over 10 years
    #keep track of all values for min,max
    tourists_sum.append(tourists)
    bears_sum.append(bears)
    berries_sum.append(berries)
    
    str_b = '{0:.1f}'.format(berries)
    print(str(i)+' '*(10-len(str(i))) + str(bears)+' '*(10-len(str(bears))) \
          + str_b+' '*(10-len(str_b)) + str(tourists)+' '*(10-len(str(tourists))))    
    
    #find next year's values
    bb_next = find_next(bears,berries,tourists)
    bears = bb_next[0]
    berries = bb_next[1]
    tourists = num_tourists(bears)
    
#overall min,max for each category
min_t = min(tourists_sum)
max_t = max(tourists_sum)
min_berries = min(berries_sum)
max_berries = max(berries_sum)
min_bears = min(bears_sum)
max_bears = max(bears_sum)
print()

min_b = "{0:.1f}".format(min_berries)
max_b = "{0:.1f}".format(max_berries)
print("Min:      {0}".format(min_bears) + ' '*(10-len(str(min_bears))) + min_b + ' '*(10-len(min_b)) + str(min_t)+' '*(10-len(str(min_t))))
print("Max:      {0}".format(max_bears) + ' '*(10-len(str(max_bears))) + max_b + ' '*(10-len(max_b)) + str(max_t)+' '*(10-len(str(max_t))))
