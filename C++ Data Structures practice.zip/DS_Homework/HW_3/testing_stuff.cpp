/*#include <iostream>
using namespace std;
int main()
{
 int list[100],list2[100];
 int n;
 int i,j;
 
 cout<<" enter number till you wanna copy "<<endl;
 cin>>n;
 
 cout<<" enter list programology conetnt"<<endl;
 
 
 for(i=0;i<n;i++)
 {
 cin>>list[i];
 }
 for(i=0;i<n;i++)
 {
 list2[i]=list[i];
 }//programology content
 cout<<"copied array "<<endl;
 for(i=0;i<n;i++)
 
 cout<<list2[i]<<endl;

return 0;
 
}*/


/*Sample output
enter number ;
5
enter list:
11
22
33
44
55
copied list
11
22
33
44
55*/