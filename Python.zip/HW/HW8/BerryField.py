import Bear
import Tourist

class BerryField(object):
    #take in active bears, active tourists, berrry field data
    def __init__(self, grid_, bears_, tourists_):
        self.grid = grid_
        self.bears = bears_
        self.tourists = tourists_
        self.berries = 0   
        #print grid include B,X,T characters for printing
        self.print_grid = self.eval_grid()
        
    def eval_grid(self): #refreshes grid, gets called internally
        print_grid_ = []
        for i in range(len(self.grid)):
            print_grid_.append([])
            for j in range(len(self.grid[i])): print_grid_[i].append(self.grid[i][j])  
        #create berry field, then add bears and tourists after
        #going to assume all bear and tourist locations are valid
        #add bears        
        for bear in self.bears:
            print_grid_[bear.x][bear.y] = 'B'
        #add tourist after checking for bears
        for t in self.tourists:
            if print_grid_[t.x][t.y] == 'B':
                #print(t,'bear attack lol')
                print_grid_[t.x][t.y] = 'X'
            else: print_grid_[t.x][t.y] = 'T'
        #calculate number of berries
        self.berries = 0
        for i in range(len(self.grid)):
            for j in range(len(self.grid[i])):
                self.berries += self.grid[i][j]        
        
        return print_grid_
    #print formatting
    def __str__(self):
        output = ''
        for i in range(len(self.print_grid)):
            for j in range(len(self.print_grid[i])):
                output += "{:>4}".format(self.print_grid[i][j])
            output += '\n'
        return output
    #grows and spreads berries
    def grow(self):
        for i in range(len(self.grid)):
            for j in range(len(self.grid[i])):
                #grow existing patches
                if self.grid[i][j] >= 1: self.grid[i][j] += 1
                if self.grid[i][j] > 10: self.grid[i][j] = 10
                #spread
                if self.grid[i][j] == 0:
                    spread = False
                    #check every surrounding cell
                    for m in range(i-1,i+2):
                        for n in range(j-1,j+2):
                            #dont check current cell, or cells outside boundaries
                            if m==i and n==j: continue
                            if m > len(self.grid)-1 or m < 0: continue
                            if n > len(self.grid[i])-1 or n < 0: continue
                            #if next cell has 10, spread to given index
                            if self.grid[m][n] == 10: spread = True
                    #spread condition
                    if spread==True: self.grid[i][j] = 1
                            
    
    def eat(self,x_,y_): #return the number of berries at a given location
        output = self.grid[x_][y_]
        #resets the number of berries at a given cell - bear ate them all
        self.grid[x_][y_] = 0
        #refresh grid
        self.print_grid = self.eval_grid()
        return output
    def amt(self,x_,y_): #returns amt of berries without changing the value
        return self.grid[x_][y_]
    def remove_b(self,remove): #removes a bear
            if remove in self.bears: self.bears.remove(remove)
            self.print_grid = self.eval_grid()            
    def remove_t(self,remove): #removes a tourist
            if remove in self.tourists: self.tourists.remove(remove)
            self.print_grid = self.eval_grid()