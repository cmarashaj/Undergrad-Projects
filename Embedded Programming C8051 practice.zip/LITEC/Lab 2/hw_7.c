/*	Name: Caila Marashaj
	Section: 1
	Side: A
	Date: 5/31/2019

	Gain: 4
	Port pin: 1.5

	File name: hw7.c
	Description: 

*/

#include <c8051_SDCC.h>// include files. This file is available online
#include <stdio.h>


//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------
void ADC_Init(void);
void Port_Init(void);
unsigned char read_AD_input(unsigned char pin_number);



//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------

unsigned char AD_value;
unsigned char input;
unsigned char voltage;

//***************
void main(void)
{
	Sys_Init();      // System Initialization
	putchar(' ');    // the quote fonts may not copy correctly into SiLabs IDE
	Port_Init(); 
	ADC_Init();
	printf("Start \r\n");
    while (1) 
    {
		printf("enter key to read A/D input \r\n");
		input = getchar();

		// add code necessary to complete the homework
		AD_value = read_AD_input(5);	//read AD value on P1.5
		voltage = ((AD_value*2.4) / 255);

		





		printf("AD value = %d\r\n", AD_value);	// print statement as required by homework
		printf("voltage = %d\r\n", voltage);	// print statement as required by homework

    }
}


//
// add the initialization code needed for the ADC1
//
void ADC_Init(void)
{
	REF0CN = 0x03; //set vref to enable ref voltage
	ADC1CN = 0x80;
	ADC1CF |= 0x03; //set gain to 4

}
//
// function that completes an A/D conversion
//
unsigned char read_AD_input(unsigned char pin_number)
{
	AMX1SL = pin_number;
	ADC1CN = ADC1CN & ~0x20; /* Clear the �Conversion Completed� flag */
 	ADC1CN = ADC1CN | 0x10; /* Initiate A/D conversion */
 	while ((ADC1CN & 0x20) == 0x00); /* Wait for conversion to complete */
	return ADC1;
}

//
// add Port initialization code
//
void Port_Init(void)
{
	P1MDIN &= 0xDF;		//P1.5 for analog input
	P1MDOUT &= 0xDF;	// set P1.5 open drain
	P1 |= 0x20;			// set P1.5 HI-Z

}

