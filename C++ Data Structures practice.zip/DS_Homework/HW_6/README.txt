HOMEWORK 6: INVERSE SLITHERLINK RECURSION


NAME:  < Caila Marashaj >



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Lauren McAlarney, ALAC drop in tutoring, Kevin Cruz, stackoverflow.com, geeksforgeeks,com >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 55 >



ANALYSIS OF PERFORMANCE OF YOUR ALGORITHM:
(order notation & concise paragraph, < 200 words)
The dimensions of the board (w and h) 
The number of labeled cells in the puzzle (n)? 
The number of edges in the closed loop fence path (e)?
Etc. 

My algorithm runs more or less in a binary tree like fashion, but with some optimization. For each edge it encounters, my program calls itself on every existing edge out of the 6 that can possibly exist, depending on where the edge is on the board. The solver itself does not necessarily depend on the sheer number of cells, aka the width and height, but rather looks at the number of labeled cells and determines whether or not the value specified is satisfied. However, one of my optimizing checks does, as it loops through the horizontal and vertical member vectors. All this considered, the approximate run time of my program is (6^n)*n + w*h.




SUMMARY OF PERFORMANCE OF YOUR PROGRAM ON THE PROVIDED PUZZLES:
My program only fully works for puzzle 1 and almost works but does not successfully find a solution for puzzle 4. Understanding and being able to manipulate the recursion ennough to solve puzzle 1 unfortunately took me too long to be able to debug and program for the other puzzles. That being said, it takes my program about a second to find a solution for puzzle 1, and about 10 seconds to find an incommplete solution for puzzle 4.



MISC. COMMENTS TO GRADER:  
I put a lot of hours into just wrapping my brain around the concept of this assignment alone. As a relatively inexperienced programmer, this has helped me learn a lot about recursion in a very short time period, which I am happy about, even though it was at the cost of some sleep. I put a lot of time and effort into this, though I know it's not the best.


