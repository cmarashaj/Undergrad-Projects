/* Sample code for speed control using PWM. */
#include <stdio.h>
#include <c8051_SDCC.h>
#define PW_MIN 2027
#define PW_MAX 3502
#define PW_NEUT 2765
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void Drive_Motor(void);
unsigned int MOTOR_PW = 0;
//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	putchar(� �); //the quotes in this line may not format correctly
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init()
	//print beginning message
	printf("Embedded Control Drive Motor Control\r\n");
	//set initial value
	MOTOR_PW = PW_NEUT;
	//add code to set the servo motor in neutral for one second
	while(1)
	{
		Drive_Motor();
	}
}
//-----------------------------------------------------------------------------
// Drive_Motor
//-----------------------------------------------------------------------------
//
// Vary the pulsewidth based on the user input to change the speed
// of the drive motor.
//
void Drive_Motor()
{
	char input;
	//wait for a key to be pressed
	input = getchar();
	if(input == 'f') //if 'f' is pressed by the user
	{
		if(MOTOR_PW < PW_MAX)
			MOTOR_PW = MOTOR_PW + 10; //increase the steering pulsewidth by 10
	}
	else if(input == 's') //if 's' is pressed by the user
	{
		if(MOTOR_PW > PW_MIN)
			MOTOR_PW = MOTOR_PW - 10; //decrease the steering pulsewidth by 10
	}
	PCA0CPL2 = 0xFFFF - MOTOR_PW;
	PCA0CPH2 = (0xFFFF - MOTOR_PW) >> 8;
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P1MDOUT |= 0X27 ;//set output pin for CEX2 in push-pull mode
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
	
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init()
{
	XBR0 = 0X27; ; //configure crossbar with UART, SPI, SMBus, and CEX channels as
						// in worksheet
}
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 - Pulse Width Modulation implemented using the PCA (Programmable Counter Array, p. 50 in Lab Manual.
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM2 = 0xC2; // CCM2. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
	.
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR ( void ) interrupt 9
{
	// reference to the sample code in Example 4.5 -Pulse Width Modulation implemented using
	//the PCA (Programmable Counter Array), p. 50 in Lab Manual.
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672; 
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
