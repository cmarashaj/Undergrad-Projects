#include "hash.h"
#include <cmath>

Table::Table(int table_size) {
	table_vec.resize(table_size);
}

int Table::hash(std::vector<std::vector<int> > seed) {
    //  This implementation comes from 
    //  http://www.partow.net/programming/hashfunctions/
    //
    //  This is a general-purpose, very good hash function for strings.
    int hash = 1315423911;
    for(int i = 0; i < seed.size(); i++) {
    	for (int j = 0; j < seed[i].size(); j++) {
    		hash ^= ((hash << 5) + seed[i][j] + (hash >> 2));
    	}
    }      
    return hash;
}



/*void Table::insert(Point pos, std::vector<std::vector<int> > seed) {
	//call hash function and insert point position into hash table based on hash
	int hash_ = hash(seed);
	// std::cout << "size = " << size << std::endl;
	int index = hash_ % size;
	// std::cout << "index = " << index << std::endl;
	// std::cout << "TABLE VEC SIZE IS " << table_vec.size() << std::endl;
	// if (index > table_vec.size()) {std::cout << "NOT BIG ENOUGH AAAAHH" << std::endl;}
	table_vec[index].push_back(pos);
}*/


void Table::insert(Point position, std::vector<std::vector<int> > seed) {
	int hash_ = hash(seed);
	// std::cout << 1 << std::endl;
	// std::cout << "hash_ = " << hash_ << "\n"; 
	// std::cout << "table_vec.size() = " << table_vec.size(); 
	int index = hash_ % table_vec.size();
	// std::cout << 2 << std::endl;
	table_vec[index].push_back(position);
	// std::cout << 3 << std::endl;
}

std::pair<bool, Point> Table::operator[](int index) {
	std::pair<bool, Point> answer;
	if (table_vec[index].size()) {
		answer.first = true;
		answer.second = table_vec[index][0];
	}
	else {
		answer.first = false;
		answer.second = 0;
	}
	return answer;
}