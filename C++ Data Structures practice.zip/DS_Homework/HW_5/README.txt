HOMEWORK 5: LINKED GRID


NAME:  < Caila Marashaj >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

<Lauren McAlarney, Kevin Cruz, Mentor Matt, TA Tim, ALAC tutoring, stackoverflow.com, lecture notes>

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



COMPLEXITY ANALYSIS:
Give the big 'O' notation for each function (or function group) below
assuming the grid is w nodes wide and h nodes high.  Write one or two
sentences justifying each answer.


Grid constructor
O(w*h)
constructor uses a nested for loop with parameters w and h. It also calls from Node class but the constructor time in Node is constant(1), so it's still O(w*h).


Grid copy constructor

My copy constructor is not written, but it effectively creates a new grid using its argument as a guide to copy
It therefore should be O(w*h), as it is more or less the same as the regular constructor, but mine is O(1)


Grid assignment operator
This function is the same operation as the copy and grid constructors, and therefore has notation O(w*h), but again mine is not implemented and technically has notation O(1)


Grid destructor
The Grid destructor loops through every Node in the Grid and destroys it, and therefore has notation O(w*h), like the constructors


Grid getWidth
getWidth has notation O(1), as it simply returns a variable representing a construction parameter

Grid getHeight
getHeight also has notation O(1) because it too returns just a parameter variable

Grid getSize
getSize() multiplies the width by the height and returns the answer, so its notation is O(1)

Grid get
get() runs two separate for loops using the width and height respectively as parameters, and therefore runs linear time O(w+h)

Grid set
set() runs the same operation as get, two separate for loops with width and height, and also runs a linear time O(w+h)

Grid print
print() runs a nested for loop inside which the linear-time function get() is called, therefore having notation O(w*h*(w+h))

Grid reset
reset() should run a nested for loop, reassigning each Node->value to the parameter using the linear function set(), so it also should have the notation O(w*h*(w+h))

Grid clear
clear() uses a nested for loop to clear the value of each individual node, so its notation should be O(w*h)

Grid join
join() uses one for loop to go through every last index in each row of the first grid, and in the same loop sets the left pointers of the left column to the right column of the first grid, so its notaion is simply a linear O(h)

Grid stack
stack() uses one loop to go through each column in the first and last respective rows of the two grids involved in the operation to set the up and down pointers to connect them, so it has linear notation O(w)

Grid chop
chop() uses a single loop to go through every row index in one vertical column to detach the left and right pointers, so it has linear notation O(h)

Grid lift
lift() uses a single loop to go through every column index in a row to break the left and right pointer connections, so it has linear notation O(w)

Grid begin_upper_left
begin upper left is an iteration pattern, which uses the should-be already written operator to increment through each column in each row, so it should have notation 
O(w*h)

Grid begin_upper_right
begin_upper_right is also an iteration pattern, which uses the should-be already written operator to increment through each column in each row, so it should have notation O(w*h)

Grid begin_lower_left
begin_lower_left is also an iteration pattern, which uses the should-be already written operator to increment through each column in each row, so it should have notation O(w*h)

Grid begin_lower_right
begin_lower_right is also an iteration pattern, which uses the should-be already written operator to increment through each column in each row, so it should have notation O(w*h)

Grid end
end returns the last value of whatever iteration pattern is chosen, and therefore has constant notation O(1)

GridIterator operator*
the dereference operator returns the value of whatever pointer it is used on, and therefore has constant notation O(1)

GridIterator left
left() reassigns the current ptr to the node left of itself, so it has constant notation O(1)

GridIterator right
right() reassigns the current ptr to the node right of itself, so it has constant notation O(1)

GridIterator up
up() reassigns the current ptr to the node above itself, so it has constant notation O(1)

GridIterator down
down() reassigns the current ptr to the node below itself, so it has constant notation O(1)

Grid begin_snake
begin_snake() simply intializes the iterating node, so it has constant notation O(1)

Grid end_snake
end_snake() simply intializes the iterating node, so it has constant notation O(1)

Grid begin_spiral
begin_spiral() simply intializes the iterating node, so it has constant notation O(1)

Grid end_spiral
end_spiral() simply intializes the iterating node, so it has constant notation O(1)


GridIterator operator++ for snake
should use nested for loop and if statements to determine where to move down and left, so it should have notation O(w*h)

GridIterator operator-- for snake
should use nested for loop and if statements to determine where to move down and left, so it should have notation O(w*h)

GridIterator operator++ for spiral
should use nested for loop and if statements to determine where to move down, right, and left, so it should have notation O(w*h)

GridIterator operator-- for spiral
should use nested for loop and if statements to determine where to move down, right, and left, so it should have notation O(w*h)



OPTIONAL EXTRA CREDIT:
Describe your implementation choices here.  



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 50 >



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

I spent a majority of the time working on this assignment trying to build my constructor, which unfortunately took until wednesday night. I didn't have time to implement the better part of my iterator class, but I do understand the concept. My implementation is incomplete, but I hope to at least somewhat compensate for that with my pseudocoding. I had a really hard time with this one. Thank you for understanding.