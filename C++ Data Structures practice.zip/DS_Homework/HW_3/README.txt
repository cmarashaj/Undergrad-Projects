HOMEWORK 3: DYNAMIC TETRIS ARRAYS


NAME:  < Caila Marashaj >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< stackoverflow.com, cppreference.com, Lauren McAlarney, Daniel Tabin, TA Tim >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 50+ >



MISC. COMMENTS TO GRADER:  
My remove_full_rows function, for the main test case, is creating a board with two more characters than it should, and this causes the subsequent assert statement to fail, and the rest of the code to break down. If I were to comment the function and assert out, the rest of my code would work with the exception of the one function. I spent an entire day trying to fix it and the memory errors it causes, but I could not. Have a nice day


