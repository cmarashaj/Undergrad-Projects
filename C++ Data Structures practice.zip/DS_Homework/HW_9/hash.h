#include <vector>
#include <iomanip>
#include "visualization.h"

//constructor w/ hash function
//vector of vectors ?
//take in probably a vector of vectors and 2D array representing the image pixel by pixel, 
	// w indices being position
class Table {
public:
	Table(int table_size);

	int hash(std::vector<std::vector<int> > seed);


	void insert(Point pos, std::vector<std::vector<int> > seed);

	std::pair<bool, Point> operator[](int index);
private:
	std::vector<std::vector<Point> > table_vec;
	// int size = size_;
};