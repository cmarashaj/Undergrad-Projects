#ifndef _SCHOOL_
#define _SCHOOL_
#include <iostream>
#include <fstream>
#include <list>
#include <cassert>
#include <cstdlib>

class School {
public:
	School();

	School(std::string name_, int num_slots_);

	std::string GetName() const {return name;}
	
	int GetNumSlots() const;

	void PrintSchoolEnrollment(std::ofstream &ostr);
	
	//pushes back onto preference list
	void AddStudent(std::string student);

	//inserts first student into school's preference list after second student name
	void InsertStudentIntoSchoolPreferenceList(std::string new_student, std::string before_student);

	void PrepareToMakeOffers();
	
	//returns the current number of accepted students
	int NumAcceptedStudents() const;
	
	//returns the maximum capacity for accepting students
	int MaxAcceptedStudents();

	//makes an offer to the next student on the preference list
	std::string MakeNextOffer();

	//student accepts this-> school's offer	
	void StudentTentativelyAcceptsOffer(std::string name);

	//student declines offer, remove from list of enrollment
	void StudentDeclinesTentativeAcceptance(std::string name);

	std::list<std::string> Preferences();

private:
	std::string name;
	std::list<std::string> preference_list;
	std::list<std::string>::iterator preference;
	std::list<std::string> enrolled;
	std::list<std::string> accepted;
	int num_slots;
	int num_accepted;
};
//nonmember alphabetical sort functions
bool alpha_by_school_name(const School& a, const School& b);
bool alpha_student(const std::string& a, const std::string& b);
#endif