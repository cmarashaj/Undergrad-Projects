/* Sample code for Lab 3.1. This program can be used to test the steering servo */
#include <c8051_SDCC.h>
#include <stdio.h>
#include <stdlib.h>
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init();
void Steering_Servo(void);
void PCA_ISR ( void ) interrupt 9;
unsigned int PW_CENTER = 2764;
unsigned int PW_RIGHT = 3870;
unsigned int PW_LEFT = 1658;
unsigned int SERVO_PW = 0;
//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	char input;
	// initialize board
	Sys_Init();
	putchar(� �); //the quotes in this line may not format correctly
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init()
	//print beginning message
	printf("Embedded Control Steering Calibration\n");
	//set initial value for steering (set to center)
	SERVO_PW = PW_CENTER;
	while(1)
	{
		Steering_Servo();
	}
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P1MDOUT |= 0X27 ;//set output pin for CEX0 in push-pull mode
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init()
{
	XBR0 = 0X27; //configure crossbar with UART, SPI, SMBus, and CEX channels as	
						// in worksheet
}

//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 -Pulse Width Modulation implemented using
	//the PCA (Programmable Counter Array), p. 50 in Lab Manual.
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM0 = 0xC2; // CCM0. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR ( void ) interrupt 9
{
	// reference to the sample code in Example 4.5 -Pulse Width Modulation implemented using
	//the PCA (Programmable Counter Array), p. 50 in Lab Manual.
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672; 
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
void Steering_Servo()
{
	char input;
	//wait for a key to be pressed
	input = getchar();
	if(input == 'r') //if 'r' is pressed by the user
	{
		if(SERVO_PW < PW_RIGHT)
			SERVO_PW = SERVO_PW + 10; //increase the steering pulsewidth by 10
	}
	else if(input == 'l') //if 'l' is pressed by the user
	{
		if(SERVO_PW > PW_LEFT)
			SERVO_PW = SERVO_PW - 10; //decrease the steering pulsewidth by 10
	}
	printf("SERVO_PW: %u\n", SERVO_PW);
	PCA0CPL0 = 0xFFFF - SERVO_PW;
	PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;
}