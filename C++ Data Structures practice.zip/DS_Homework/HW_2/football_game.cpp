#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>
#include "football_game.h"

//this file implements the functions defined in the header file
// for the Football_Game class

//converts private public arguments to private variables for 
// function use
Football_Game::Football_Game(std::vector <std::string>& date_vec, std::string team1_str, std::vector <int>& team1scores_vec, std::string team2_str, std::vector <int>& team2scores_vec) {
	date = date_vec;
	team1 = team1_str;
	team1_scores = team1scores_vec;
	team2 = team2_str;
	team2_scores = team2scores_vec;
}

// returns day of the week given game was played on
std::string Football_Game::getWKDay() const {
	return date[0];
}

// returns month game was played in
std::string Football_Game::getMonth() const {
	return date[1];
}

//returns number of the date the game was played on
std::string Football_Game::getDateNum() const {
	return date[2];
}

//returns the year the game was played in
std::string Football_Game::getYear() const {
	return date[3];
}

//returns the name of the visiting team
std::string Football_Game::getTeam1() const {
	return team1;
}

//returns the name of the home team
std::string Football_Game::getTeam2() const {
	return team2;
}

//returns the total number of points scored by both teams in 
// a given game
int Football_Game::TotalPoints() const {
	int team1_final = 0;
	int team2_final = 0;
	for (int i=0;  i < 6; i++) {
		team1_final += team1_scores[i];
		team2_final += team2_scores[i];
	}
	team1_final = team1_final / 2;
	team2_final = team2_final / 2;
	return team1_final + team2_final;
}

//returns the name of the winning team
std::string Football_Game::winning_team() const {
	//keep track of total scores from each team
	int team1_final = 0;
	int team2_final = 0;
	for (int i=0;  i < 6; i++) {
		team1_final += team1_scores[i];
		team2_final += team2_scores[i];
	}
	if (team1_final > team2_final) {
		return team1;
	}
	else {
		return team2;
	}
}

//returns the name of the losing team
std::string Football_Game::losing_team() const {
	int team1_final = 0;
	int team2_final = 0;
	for (int i=0;  i < 6; i++) {
		team1_final += team1_scores[i];
		team2_final += team2_scores[i];
	}
	
	if (team1_final > team2_final) {
		return team2;
	}
	else {
		return team1;
	}
}

//returns the point differential for the given game
int Football_Game::differential() const {
	int team1_final = 0;
	int team2_final = 0;
	for (int i=0;  i < 6; i++) {
		team1_final += team1_scores[i];
		team2_final += team2_scores[i];
	}
	team1_final = team1_final / 2;
	team2_final = team2_final / 2;
	//differential = winning score - losing score
	if (team1_final > team2_final) {
		return (team1_final - team2_final);
	}
	else{
		return (team2_final - team1_final);
	}
}

//returns the final number of points scored by the visiting team
int Football_Game::Team1Final() const {
	int team1_final = 0;
	int team2_final = 0;
	for (int i=0;  i < 6; i++) {
		team1_final += team1_scores[i];
		team2_final += team2_scores[i];
	}
	team1_final = team1_final / 2;
	return team1_final;
}

//returns final number of points scored by the home team
int Football_Game::Team2Final() const {
	int team1_final = 0;
	int team2_final = 0;
	for (int i=0;  i < 6; i++) {
		team1_final += team1_scores[i];
		team2_final += team2_scores[i];
	}
	team2_final = team2_final / 2;
	return team2_final;
}