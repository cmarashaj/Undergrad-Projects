#ifndef Tetris_h
#define Tetris_h

#include <iostream>
#include <cassert>
#include <cstdlib>
#include <string>

class Tetris {
public:
	Tetris (int width_);

	//ACCESSORS
	int get_width();
	int get_max_height() const;
	int count_squares();

	//MEMBER FUNCTIONS
	void print() const;
	void add_piece(char piece, int rotation, int position);
	//returns the number of rows removed, removes full rows from arrays
	int remove_full_rows();
	void remove_left_column();
	void remove_right_column();
	void add_left_column();
	void add_right_column();

	//DESTRUCTOR
	//The destroy Tetris member function cleans up all dynamically
	void destroy();


private:
	int width;
	int* heights;
	char** data;



};
#endif