/* Sample code for speed control using PWM. */
#include <stdio.h>
#include <c8051_SDCC.h>
#include <i2c.h>
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void SMB_Init(void);
void ADC_Init(void);
void Steering_Servo();
void Change_Heading();
void Drive_Motor(void);
unsigned int Read_Compass(void);
unsigned int ReadRanger(void);
unsigned char read_AD(void);
unsigned char read_AD_input(unsigned char pin_number);
void UI(void);
void pause(void);
void wait(void);
void pause_3(void);
void all_neutral(void);
//-----------------------------------------------------------------------------
// sbit variables
//-----------------------------------------------------------------------------
__sbit __at 0xB7 SS;
__sbit __at 0xA5 BILED1;
__sbit __at 0xA7 BILED2;
//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
#define PW_MIN 2027
#define PW_MAX 3502
#define PW_NEUT 2724
unsigned int r_count = 0;
unsigned int new_range = 1;
unsigned int range;
unsigned char Data_m[2];
unsigned char addr;
unsigned int MOTOR_PW;
unsigned char k_m = 1;

unsigned int h_count = 0;
unsigned int new_heading = 1;
unsigned int heading;
unsigned char Data_c[2];
unsigned char addr;
#define PW_CENTER 2765
#define PW_LEFT 1700
#define PW_RIGHT 3500
signed int SERVO_PW; 
signed int error;
signed int k_c;
unsigned int desired_heading;

unsigned char voltage;
signed int direction;
unsigned char AD_value;
unsigned int count;
unsigned int time_count;
unsigned int input;
//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init();
	SMB_Init();
	ADC_Init();
	//print beginning message
	printf("\r\nSee LCD Display\r\n");
	MOTOR_PW = PW_NEUT;
	PCA0CPL2 = 0xFFFF - MOTOR_PW;
	PCA0CPH2 = (0xFFFF - MOTOR_PW) >> 8;
	
	//add code to set the servo motor in neutral for one second
	while(1)
	{
		printf("Start at the top");
		
		UI();
		voltage = read_AD();
		printf("Desired Heading: %u\r\n",desired_heading);
		printf("Steering gain: %d\r\n",k_c);
		printf(k_m);
		lcd_clear();
		SERVO_PW = PW_CENTER;
		MOTOR_PW = PW_NEUT;

		while(SS)//wait for slide switch to be on
				//Center wheels
		{
			all_neutral();
		}
		direction = 1;
		if (!SS)
		{
			time_count = 0;
			Drive_Motor();
			if (new_heading)
			{
				heading = Read_Compass();
				Change_Heading();
				new_heading = 0;
			}
			BILED1 = 1;
			BILED2 = 0;
			pause_3();

		}
		while (!SS)
		{

			if(new_range)
			{
				range = ReadRanger();
				new_range = 0;
			}

			if(new_heading)
			{
				heading = Read_Compass();
				Change_Heading();
				new_heading = 0;
				printf("heading = %u  error = %d   SERVO_PW = %u   MOTOR_PW = %u  Distance = %u\r\n",heading,error,SERVO_PW,MOTOR_PW,range);
			}

			if( range <= 20)
			{
				//printf("\r\nTime Count: %d\r\n",time_count);
				time_count = 0;
				if (direction == 1)
				{
					direction = -1;
					Drive_Motor();
					BILED1 = 0;
					BILED2 = 1;
					if (new_heading)
					{
						heading = Read_Compass();
						Change_Heading();
						new_heading = 0;
					}
					
				}
				else if(direction == -1)
				{
					direction = 1;
					Drive_Motor();
					BILED1 = 1;
					BILED2 = 0;
					if (new_heading)
					{
						heading = Read_Compass();
						Change_Heading();
						new_heading = 0;
					}
				}
				pause_3();
			}

		}

		all_neutral();
		BILED1 = 1;
		BILED2 =1;
		//printf("End time: %d\r\n",time_count);
		time_count = 0;
	}
}

void all_neutral(void)
{
	SERVO_PW = PW_CENTER;
	PCA0CPL0 = (0xFFFF - SERVO_PW);
	PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;

	//Neutral speed
	MOTOR_PW = PW_NEUT;
	PCA0CPL2 = 0xFFFF - MOTOR_PW;
	PCA0CPH2 = (0xFFFF - MOTOR_PW) >> 8;

}
//-----------------------------------------------------------------------------
// Drive_Motor
//-----------------------------------------------------------------------------
//
// Vary the pulsewidth based on the ultrasonic range to change the speed
// of the drive motor.
//
void Drive_Motor()
{
	
	MOTOR_PW = (direction * k_m*voltage) + PW_NEUT;
	if (MOTOR_PW > PW_MAX)
	{
		MOTOR_PW = PW_MAX;
	}
	else if(MOTOR_PW < PW_MIN)
	{
		MOTOR_PW = PW_MIN;
	}
	printf("\r\n Motor Pulse Width: %u\r\n",MOTOR_PW);

	PCA0CPL2 = 0xFFFF - MOTOR_PW;
	PCA0CPH2 = (0xFFFF - MOTOR_PW) >> 8;
}
//-----------------------------------------------------------------------------
// Function to Read Ranger
//-----------------------------------------------------------------------------
unsigned int ReadRanger(void)
{
	range =0;
	addr=0xE0; // the address of the ranger is 0xE0
	i2c_read_data(addr,0x02, Data_m, 2); // read two bytes, starting at reg 2
	range = (((unsigned int)Data_m[0] << 8) | Data_m[1]);
	Data_m[0] = 0x51; // write 0x51 to reg 0 of the ranger:
	i2c_write_data(addr,0x00, Data_m, 1); // write one byte of data to reg 0 at addr
	//printf("\r\nRange: %d\r\n", range);
	return range; 
}
//-----------------------------------------------------------------------------
// Function to Read Compass
//-----------------------------------------------------------------------------
unsigned int Read_Compass()
{
	addr=0xC0; // the address of the compass
	i2c_read_data(addr, 0x02, Data_c, 2); // read two bytes, starting at reg 2
	heading = (((unsigned int)Data_c[0] << 8) | Data_c[1]);
	//printf("\r\nHeading: %u\r\n", heading);
	return heading; //return heading in tenths a degree from 0 - 3599
}
//-----------------------------------------------------------------------------
// Function to change heading
//-----------------------------------------------------------------------------
void Change_Heading()
{
	error = (signed int)(desired_heading - heading);
	if(error > 1800)
	{
		error = error - 3600;
	}
	else if(error < -1800)
	{
		error = error + 3600;
	}
	else
	{
		error = error;
	}
	//printf("\r\nCompass Error: %d\r\n",error);
	SERVO_PW = (signed int)((direction*k_c*error) + PW_CENTER);
	if (SERVO_PW > PW_RIGHT)
	{
		SERVO_PW = PW_RIGHT;
	}
	else if(SERVO_PW < PW_LEFT)
	{
		SERVO_PW = PW_LEFT;
	}
	//printf("\r\n Steering Pulse Width: %u\r\n",SERVO_PW);
	PCA0CPL0 = (0xFFFF - SERVO_PW);
	PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;
}
//-----------------------------------------------------------------------------
// Reads AD value from potentiometer
//-----------------------------------------------------------------------------
unsigned char read_AD(void)
{	
	AD_value = read_AD_input(4);
	//value = AD_value*71.25;
	printf("\r\n AD Value: %u\r\n",AD_value);
	return AD_value;
}
//-----------------------------------------------------------------------------
// Reads AD value from potentiometer
//-----------------------------------------------------------------------------
unsigned char read_AD_input(unsigned char pin_number)
{
	AMX1SL = pin_number;
	ADC1CN = ADC1CN & ~0x20; /* Clear the �Conversion Completed� flag */
 	ADC1CN = ADC1CN | 0x10; /* Initiate A/D conversion */
 	while ((ADC1CN & 0x20) == 0x00); /* Wait for conversion to complete */
	return ADC1;
}
//-----------------------------------------------------------------------------
// Pause for 150 clock cycle
//-----------------------------------------------------------------------------
void pause_3(void)
{
    count = 0;
    while (count < 150)		// 50 counts -> 150 x 20ms = 3000ms
	{
		if(new_range)
		{
			range = ReadRanger();
			new_range = 0;

		}
		if(new_heading)
		{
			heading = Read_Compass();
			Change_Heading();
			new_heading = 0;
		}
	}
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P1MDIN &= 0XEF;
	P1MDOUT &= 0XEF;
	P1MDOUT |= 0X27 ;//set output pin for CEX0,CEX2 in push-pull mode
	P1 |= ~0XEF;
	P3MDOUT &= 0x7F;
	P3 |= 0x7F;
	P2MDOUT |= 0XA0;
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
	
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init()
{
	XBR0 = 0x1F;		//configure crossbar with UART, SPI, SMBus, and CEX channels as
						// in worksheet
}
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 - Pulse Width Modulation implemented using the PCA (Programmable Counter Array, p. 50 in Lab Manual.
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM0 = 0xC2;
	PCA0CPM2 = 0xC2; // CCM2. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR ( void ) __interrupt 9
{
	//see lab instructions online to ocunt
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672;
		time_count++;
		count++;
		h_count++;
		r_count++;
		if(h_count>=3) //recommended to wait 3 overflows instead of 2
		{
			new_heading = 1; 
			h_count = 0;
		}
		if(r_count>=4)
		{
			new_range = 1; // 4 overflows is about 80 ms
			r_count = 0;
		}
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
//-----------------------------------------------------------------------------
// SMBus Initialization
//-----------------------------------------------------------------------------
void SMB_Init(void)
{
	SMB0CR = 0X93; //set SCL to 100kHz*/
	ENSMB = 1; //bit 6 of SMB0CN, enable the SMBus
}
//-----------------------------------------------------------------------------
// ADC Initialization
//-----------------------------------------------------------------------------
void ADC_Init(void)
{
    REF0CN = 0x03; //Vref = 2.4V
    ADC1CN = 0x80; //enable A/D coversion
    ADC1CF |= 0x01;

}
//-----------------------------------------------------------------------------
// User Interface on LCD
//-----------------------------------------------------------------------------
void UI()
{
	lcd_clear();

	lcd_print("\nSteering control value: \n");
	input = kpd_input(1);
	k_c = input;
	lcd_clear();

	lcd_print("\nSpeed control value: \n");
	input = kpd_input(1);
	k_m = (float)input;
	lcd_clear();

	lcd_print("\nDesired direction\n");
	input = kpd_input(0);
	lcd_clear();
	desired_heading = input;
}