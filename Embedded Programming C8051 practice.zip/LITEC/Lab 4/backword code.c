/*	Names: Ben Lane, Mike Medica, Matt Schomer, Andy Whitworth
	Lab 4
	Section: 03
*/
#include <c8051_SDCC.h>
#include <stdio.h>
#include <stdlib.h>
#include <i2c.h>

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------

//---Initializing Functions
void initializeAll(void);							//Call all initialization
void Port_Init(void);								//Initialize ports
void PCA_Init (void);								//Initialize Programmable Counter Array
void XBR0_Init(void);								//Initialize the crossbar
void SMB_Init(void);								//Initialize the SM Bus
void ADC_Init(void);								//Initialize Analog to Digital conversion
void Ranger_Init(void);								//Tell ranger to send a ping

//---Prep/Helper Functions
void PCA_ISR (void) interrupt 9;					//Interupt Service Register for PCA
float readVoltage(void);					//Read value from analog to digital conversion
void calibrate(void);								//Allow user to calibrate steering servo
unsigned int calibrateServo(char calType[]);		//Work function for calibrate
void steeringServoPulse(void);						//Adjust steering pulse width
void speedServoPulse(void);							//Adjust speed pulse width
void pause(void);									//Pause 20 ms
void wait(void);									//Wait 1 second

//---Primary Functions
void readRanger(void);								//Reads range from electronic ranger
void readHeading(void);								//Reads heading from electronic compass
void adjustHeading(void);							//Adjusts steering servo based on heading
void adjustSpeed(void);								//Adjusts speed servo based on distance

//---Keypad Functions
char readKeypad();									//Reads from keypad, with appropriate pauses
unsigned int readKeypadNumber(int numDigits);		//Read a milti-digit number from keypad
void keypadDisplay(float batteryLevel, unsigned int currentHeading, unsigned int currentAltitude);
void menu();




//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
//---Pulse width variables
//speed
unsigned int speedPW = 2765;			//Speed pulse width starts at neutral
unsigned int speedNeutral = 2765;		//Pulse width for neutral speed
//steer
unsigned int steerPW = 2765;			//Steering pulse width starts at center
unsigned int steerCenter = 2705;		//Pulse width for steering center point
unsigned int steerMaxLeft = 2095;		//Pulse width for steering max left
unsigned int steerMaxRight = 3265;		//Pulse width for steering max right

//---Other variables
unsigned int count = 0;					//global counter, increments every 20ms
unsigned int heading;					//Heading compass point to in degrees (0 - 3599)
unsigned int desiredHeading = 1800;		//Where we want to head
unsigned int distance;					//Current distance in centimeters
unsigned int desiredDistance = 45;		//Distance wanted in centimeters
unsigned char inputCount = 0;			//PCA counter, increments every 20ms, used for compass and ranger
float proportionalGain;
float batteryLevel;
bit newRange = 0;
bit newHeading = 0;

//--sbits
sbit at 0xB7 slideSwitch;


//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	initializeAll();	// initialize board
	proportionalGain = ((float)steerMaxRight - (float)steerMaxLeft) / 1800; //set gain
	lcd_clear();

	while(1){
		//If the slideSwitch is off
		if(slideSwitch)
		{
			//Center wheels
			steerPW = steerCenter;
			steeringServoPulse();
			//Set speed to neutral
			speedPW = speedNeutral;
			speedServoPulse();
			//Wait while the slideSwitch is turned off
			lcd_clear();
			lcd_print("Paused\n");

			while(slideSwitch);
		}

		if(newRange)
		{
			readRanger();
			adjustSpeed();
			newRange = 0; //clear newRange
		}
		if(newHeading)
		{
			readHeading();
			adjustHeading();
			newHeading = 0; //clear newHeading
		}
		batteryLevel = readVoltage();
		keypadDisplay(batteryLevel, heading, distance);
		if(read_keypad() == '0'){
			pause();
			while(read_keypad() != -1) pause(); //Wait for unpress
			steerPW = steerCenter;
			steeringServoPulse();
			speedPW= speedNeutral;
			speedServoPulse();
			menu();
			newRange = 1;
			newHeading = 1;
		}
		else pause(); //Delay for read_keypad()

	}
}
//-----------------------------------------------------------------------------
// initializeAll
//-----------------------------------------------------------------------------
//
//  Call all initialize functions
//
void initializeAll(void)
{
	Sys_Init();
	putchar(' ');
	Port_Init();
	XBR0_Init();
	PCA_Init();
	SMB_Init();
	ADC_Init();
	Ranger_Init();

	//Center wheels
	steeringServoPulse();
	//Set speed to neutral
	speedPW = speedNeutral;
	speedServoPulse();

	wait(); //Wait 1 second for LCD and speed servo to initialize
}

//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init(void)
{
	P1MDOUT |= 0x09;	 	//set output pins for CEX0 and CEX3 in push-pull mode
	P1MDOUT &= ~0x10;		//Set 1.4 to input for ADC
	P1MDIN &= ~0x10;		//Set 1.4 to analog in
	P1 |= 0x10;				//Set 1.4 to high impedance
	P3MDOUT &= 0xEF;		//Set P3.7 to input mode
	P3 |= ~0xEF;			//Set P3.7 to high impedance state
}

//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init(void)
{
	XBR0 = 0x27; 	//configure crossbar as directed in the laboratory
	//XBR2 = 0x40;

}
 
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	PCA0CPM0 = 0xC2;	//CCM0 in 16 bit compare mode
	PCA0CPM3 = 0xC2;	//CCM3 in 16-bit compare mode
	PCA0MD = 0x81;		//Suspend while controller is idle, SYSCLK/12, Enable CF iterrupts
	PCA0CN = 0x40;		//Enable PCA counter
	EIE1 |= 0x08;		//Enable PCA interrupt
	EA = 1;				//Enable global interrupts
}

//-----------------------------------------------------------------------------
// SMB_Init
//-----------------------------------------------------------------------------
//
// Set up System Bus
//
void SMB_Init(void)
{
	SMB0CR=0x93; 	// set SCL to 100 kHz
	ENSMB=1;		//Enable System Bus
}

//-----------------------------------------------------------------------------
// ADC_Init
//-----------------------------------------------------------------------------
//
// Set up Analog to Digital Converstion
//
void ADC_Init(void)
{
	REF0CN = 0x03;		//Set Vref to use internal reference voltage (2.4 V)
	ADC1CN = 0x80;		//Enable A/D converter (ADC1)
	ADC1CF |= 0x01;		//Set A/D converter gain to 1
}

//-----------------------------------------------------------------------------
// Ranger_Init
//-----------------------------------------------------------------------------
//
// Tell the sonic ranger to send a ping
//
void Ranger_Init(void)
{
	char addr = 0xE0; 	//Ultrasonic ranger address
	unsigned char buffer[2];	//Ranger Buffer
	char reg = 0x00;	//Command register for ranger
	buffer[0] = 0x51;	//Tell the ranger to start pinging with a range in centimeters
	i2c_write_data(addr, reg, buffer, 1);
}

//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR(void) interrupt 9
{
	if (CF) {
		CF = 0;				//Clear overflow flag
		count++;
		inputCount++;
		if(!(inputCount%2))
		{
		 	//Check for a new heading every 40ms
			newHeading = 1;
		}
		if(!(inputCount%4)) 	//Check for a new range every 80ms
		{
			newRange = 1;
		}
		PCA0L = 28671;		//low byte of start count
		PCA0H = 28671 >> 8;	//high byte of start count
	}
	PCA0CN &= 0xC0;			//Handle other PCA interrupt sources
}

//-----------------------------------------------------------------------------
// readVoltage
//-----------------------------------------------------------------------------
//
//	Read value from analog to digital conversion
//	Convert to voltage of car -> Vin = 0 - 2.4, 2.344 corresponds to 13v
//
float readVoltage(void)
{
	float voltage;
	AMX1SL = 4;							//Set P1.4 as the analog input for ADC1
	ADC1CN &= ~0x20;					//Clear the completion flag
	ADC1CN |= 0x10;						//Initialize A/D conversion
	
	while((ADC1CN & 0x20) == 0x00);		//Wait for conversion
	voltage = 0.0521925134 * ((float)ADC1);
	return voltage;
}


//-----------------------------------------------------------------------------
// steeringServoPulse
// speedServoPulse
//-----------------------------------------------------------------------------
//
//	Adjust pulse width of steering server PCA
//	Adjust pulse width of speed server PCA
//
void steeringServoPulse(void)
{
	PCA0CPL0 = (0xFFFF - steerPW);
	PCA0CPH0 = (0xFFFF - steerPW) >> 8;
}
void speedServoPulse(void)
{
	PCA0CPL3 = 0xFFFF - speedPW;
	PCA0CPH3 = (0xFFFF - speedPW) >> 8;
}

//-----------------------------------------------------------------------------
// pause
// wait
//-----------------------------------------------------------------------------
//
//	Pause 1 clock cycle (20 ms)
//	Wait 50 clock cycles (1 s)
//
void pause(void)
{
    count = 0;
    while (count < 1);		// 1 count -> 20 ms
}
void wait(void)
{
    count = 0;
    while (count < 50);    // 50 counts -> 50 x 20ms = 1000ms
}

//-----------------------------------------------------------------------------
// readHeading
// readRanger
//-----------------------------------------------------------------------------
//
//	Reads heading from electronic compass
//	Reads heading from sonic ranger
//
void readHeading()
{
	unsigned char compassAddress = 0xC0;		//Address of Electronic Compass
	unsigned char compassData[2];				//Array to store data from Compass
	//Read data drom electronic compass
	i2c_read_data(compassAddress, 0x02, compassData, 2);
	//Store data in heading variable
	heading = (( (unsigned int)compassData[0] << 8) | (unsigned int)compassData[1]);
}
void readRanger( void )
{
	char addr = 0xE0; 							//Ultrasonic ranger address
	unsigned char buffer[2];					//Ranger Buffer
	char reg = 0x02;							//Range register
	i2c_read_data(addr, reg, buffer, 2);		//Read range from ranger
	distance = (((unsigned int)buffer[0] << 8) | buffer[1]);
	Ranger_Init(); 								//Send a new ping
}
//-----------------------------------------------------------------------------
// adjustHeading
// adjustSpeed
//-----------------------------------------------------------------------------
//
//	Changes heading from new compass reading
//	Changes speed from new speed reading
//
void adjustHeading(void)
{
	//Error is difference in desired heading and current heading
	int error = (unsigned int) desiredHeading - (unsigned int) heading;
	int bounds =((float)steerMaxRight - (float)steerMaxLeft) / (2 * proportionalGain);
	//To account for properties of circle, heading changes greater than 1800 will have 3600 subtracted
	if(error > 1800){	
		error -= 3600;
	}
	//and heading changes less that -1800 will have 3600 added
	if(error < -1800){
		error += 3600;
	}

	if (error > bounds){
		steerPW = steerMaxRight;
	} else if(error < -bounds){
		steerPW = steerMaxLeft;
	} else{
		steerPW = steerCenter + ((float)error * proportionalGain);
	}
	steeringServoPulse();
}
void adjustSpeed(void)
{
	int Error = 0;
	Error = desiredDistance - distance;
	speedPW = speedNeutral + (19 * (Error));			//Set new speed pulse width
	speedServoPulse();							//Send new pulse width to speed servo
}


//-----------------------------------------------------------------------------
// Keypad/LCD
//-----------------------------------------------------------------------------
//
//	Accepts LCD keyboard input to set variables
//
// Reads from keypad, with appropriate pauses
char readKeypad(){
	char input;
	char keypadInput;
	//Reads from keypad
	input = read_keypad();
	pause();
	//Waits until a read input is not the null value
	while(input == -1){
		input = read_keypad();
		pause();
	}
	//Sets up value to return
	keypadInput = input;
	input = read_keypad();
	pause();
	//waits while the value is not null value (while button is pressed)
	while(input != -1){
		input = read_keypad();
		pause();
	}
	return keypadInput;
}

//Reads a multidigit number from keypad
unsigned int readKeypadNumber(int numDigits){
	//iterration values;
	char i;
	char j;
	int place;			//Place of the input digit
	char keypadInput;	//Variable for input
	int numValue;		//Number value of char
	int result = 0;		//Value to return
	//Loop once for each digit, starting with most significant
	for(i= numDigits; i > 0; i--){
		place = 1;
		keypadInput = readKeypad();	//read from keypad
		lcd_print("%c", keypadInput);
		numValue = keypadInput - '0';	//convert char to int of number
		//Plae for the digit
		for(j = 0; j < i - 1; j++){
			place *= 10;
		}
		//Adds all digits together
		result = result + (place * numValue);
	}
	return result;
}

//Displays Barrery Level, Heading, and Altitude
void keypadDisplay(float batteryLevel, unsigned int currentHeading, unsigned int currentAltitude){
	unsigned char batteryInt = (unsigned char) batteryLevel;
	unsigned char batteryDec = (unsigned char)((batteryLevel - (float) batteryInt) * 10);
	lcd_clear();
	lcd_print("Battery:   %u.%u\n", batteryInt, batteryDec);
	lcd_print("Heading:   %u\n", currentHeading);
	lcd_print("Altitude:  %u\n", currentAltitude);
	lcd_print("For menu, press '0'");
}

//Menu for LCD Display
void menu(){
	char keypadInput;
	char i;	//Used whenever an itterator is neccessary
	lcd_clear();
	lcd_print("--Menu Options--\n");
	lcd_print("Change Heading: '0'\n");
	lcd_print("Change Gain:    '*'\n");
	lcd_print("CalibrateWheels:'#'");
	
	//First Level input
	keypadInput = readKeypad();
	switch(keypadInput){
		//Change Heading
		case '0':
			lcd_clear();
			lcd_print("--Change Heading--\n");
			lcd_print("Select From List: *\n");
			lcd_print("Enter Value:     #\n");
			keypadInput = readKeypad();
			switch(keypadInput){
				//Select From List
				case '*':
					lcd_clear();
					lcd_print("North: '2'\n");
					lcd_print("East:  '6'\n");
					lcd_print("South: '8'\n");
					lcd_print("West:  '4'\n");
					keypadInput = readKeypad();
					switch(keypadInput){
						//Norh
						case '2':
							desiredHeading = 0;
							break;
						//East
						case '6':
							desiredHeading = 900;
							break;
						//South
						case '8':
							desiredHeading = 1800;
							break;
						//West
						case '4':
							desiredHeading = 2700;
							break;
					}
					break;
				//Enter Value
				case '#':
					lcd_clear();
					lcd_print("--Input Desired--\n");
					lcd_print("-----Heading-----\n");
					//Grabs 4 digit heading from keypad
					desiredHeading = readKeypadNumber(4);
					//Adjust heading based on new desiredHeading
					lcd_print("Set\n");
					break;
			}
			adjustHeading();
			break;
		//Change proportional Gain
		case '*':
			//0.6 to 4.0
			lcd_clear();
			lcd_print("-Proportional Gain-\n");
			lcd_print("Enter a number\n");
			lcd_print("between 06 and 40\n");
			lcd_print("(gain = input / 10)");
			//Grabs 2 digit number from keypad
			lcd_clear();
			proportionalGain = (float) readKeypadNumber(2) / 10.0;
			//If invalid input, set default value
			if(proportionalGain > 4.0 || proportionalGain < 0.6){
				proportionalGain = ((float)steerMaxRight - (float)steerMaxLeft) / 1800;
			}
			break;
		//Calibrate Wheels
		case '#':
			lcd_clear();
			lcd_print("-Wheel Calibration-\n");
			lcd_print("Default:     '*'\n");
			lcd_print("Calibrate: '#'\n");
			keypadInput = readKeypad();
			switch(keypadInput){
				//Deafault calibration
				case '*':
					lcd_clear();
					steerCenter = 2685;
					steerMaxLeft = 2095;
					steerMaxRight = 3265;
					lcd_print("Set\n");
					break;
				//Manual Calibration
				case '#':
					lcd_clear();
					lcd_print("--CALIBRATION--\n");
					lcd_print("Shift Left:  '*'\n");
					lcd_print("Shift Right: '#'\n");
					lcd_print("Start/Done:  '0'");

					//Receive input until it is start value
					keypadInput = readKeypad();
					while(keypadInput != '0'){
						keypadInput = readKeypad();
					}
					lcd_clear();
					lcd_print("Center, Left, Right\n");
					//Loop for left, right, and center
					for(i = 0; i < 3; i++){
						bit flag = 1;
						while(flag){
							//Receive single letter commands from user (l,r,d)
							keypadInput = readKeypad();
							//If input is 0, return current value of pulseWidth
							switch(keypadInput)
							{
							case '0':
								if(i == 0){
									lcd_print("Center Set\n");
									steerCenter = steerPW;
								} else if(i == 1){
									lcd_print("Left Set\n");
									steerMaxLeft = steerPW;
								} else if(i == 2){
									lcd_print("Right Set");
									steerMaxRight = steerPW;
								}
								flag = 0;
								break;
							//Othwise, adjust puslseWidth based on steeringServo function
							//Left
							case '1':
								steerPW -= 100;
								break;
							case '4':
								steerPW -= 50;
								break;
							case '7':
								steerPW -= 30;
								break;
							case '*':
								steerPW -= 10;
								break;
							//Right
							case '3':
								steerPW += 100;
								break;
							case '6':
								steerPW += 50;
								break;
							case '9':
								steerPW += 30;
								break;
							case '#':
								steerPW += 10;
								break;
							}
							steeringServoPulse();
						}
					}
			}
			break;
	}
}
