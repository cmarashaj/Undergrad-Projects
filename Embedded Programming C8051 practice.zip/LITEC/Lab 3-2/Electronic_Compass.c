/* Code for Electronic Compass in Lab 3-2 */
#include <stdio.h>
#include <c8051_SDCC.h>
#include <i2c.h>
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void SMB_Init(void);
unsigned int ReadCompass(void);
//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
unsigned int h_count = 0;
unsigned int new_heading = 1;
unsigned int heading;
unsigned char Data[2];
unsigned char addr;

//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init();
	SMB_Init();
	//print beginning message
	printf("\r\nEmbedded Control Electronic Compass\r\n");

	while(1)
	{
		if(new_heading)
		{
			heading = ReadCompass();
			new_heading = 0;
			printf("\r\nHeading: %d\r\n",heading);
		}
	}
}
//-----------------------------------------------------------------------------
// Function to Read Electronic Compass 
//-----------------------------------------------------------------------------
unsigned int ReadCompass(void)
{
	addr=0xC0; // the address of the compass
	i2c_read_data(addr, 0x02, Data, 2); // read two bytes, starting at reg 2
	heading = (((unsigned int)Data[0] << 8) | Data[1]);
	return heading; //return heading in tenths a degree from 0 - 3599
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P1MDOUT |= 0X27 ;//set output pin for CEX2 in push-pull mode
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
	
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init()
{
	XBR0 = 0x27;		//configure crossbar with UART, SPI, SMBus, and CEX channels as
						// in worksheet
}
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM2 = 0xC2; // CCM2. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR ( void ) __interrupt 9
{
	//see lab instructions online to ocunt
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672;
		h_count++;
		if(h_count>=3) //recommended to wait 3 overflows instead of 2
		{
			new_heading=1; 
			h_count = 0;
		}
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
//-----------------------------------------------------------------------------
// SMBus Initialization
//-----------------------------------------------------------------------------
void SMB_Init(void)
{
	SMB0CR = 0X93; //set SCL to 100kHz
	ENSMB = 1; //enable the SMBus
}