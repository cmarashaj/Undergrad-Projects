'''
this program is a game surrounding pikachu and the user's movements

author: alex david
date: 6 oct 2018
'''

#this function moves the pokemon
def move_pokemon(position, direction, steps):
    row = position[0]
    column = position[1]
    if direction == "N" or direction == "n":
        row = row - steps
    elif direction == "S" or direction == "s":
        row = row + steps
    elif direction == "E" or direction == "e":
        column = column + steps
    elif direction == "W" or direction == "w":
        column = column - steps
    else:
        row = row
        column = column
    if row < 0:
        row = 0
    if column < 0:
        column = 0
    if row > 150:
        row = 150
    if column > 150:
        column = 150
    return (row, column)

#this gets parameters for the game set up
turns = int(input("How many turns? => "))
print(turns)
name = input("What is the name of your pikachu? => ")
print(name)
often = int(input("How often do we see a Pokemon (turns)? => "))
print(often)
print("")
record = [] #win/loss record
turn = 0
encounter_counter = 0 #how many turns before encountering a pokemon
position = (75,75) #position[0] = row, position[1] = column

print("Starting simulation, turn 1", name, "at (75, 75)")
while turn < turns: #the game, turn is current turn/turns is total turns
    direction = str(input("What direction does " + name + " walk? => "))
    print(direction)
    position = move_pokemon(position, direction, 5)
    turn += 1
    encounter_counter += 1
    if encounter_counter == often:
        print("Turn ", turn, ", ", name, " at ", position, sep="")
        poke_type = str(input("What type of pokemon do you meet (W)ater, (G)round? => "))
        print(poke_type)
        if poke_type == "W" or poke_type == "w":
            position = move_pokemon(position, direction, 1)
            record.append("Win")
            print(name, "wins and moves to", position)            
        elif poke_type == "G" or poke_type == "g":
            position = move_pokemon(position, direction, -10)
            record.append("Lose")
            print(name, "runs away to", position)
        else:
            record.append("No Pokemon")
        encounter_counter = 0
        
print(name, " ends up at ", position, ", Record: ", record, sep="") #finishes the game
