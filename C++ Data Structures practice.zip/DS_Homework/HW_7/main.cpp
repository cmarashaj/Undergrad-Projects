//maybe put a better random in here
//for generate, create a bunch of sentences, store them
//check if they're grammtically correct
//only output grammatically correct sentenc3ecxxz 



// -----------------------------------------------------------------
// HOMEWORK 7 WORD FREQUENCY MAPS
//
// You may use all of, some of, or none of the provided code below.
// You may edit it as you like (provided you follow the homework
// instructions).
// -----------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <cassert>
#include <vector>
#include <string>
#include <list>
#include <map>


// ASSIGNMENT: FILL IN YOUR OWN MAP STRUCTURE
typedef std::map<std::string, std::map<std::string, int> >  MY_MAP;
typedef std::map<std::string, std::map<std::string, std::map<std::string, int> > > MY_MAP2;



// Custom helper function that reads the input stream looking for
// double quotes (a special case delimiter needed below), and white
// space.  Contiguous blocks of alphabetic characters are lowercased &
// packed into the word.
bool ReadNextWord(std::istream &istr, std::string &word) {
  char c;
  word.clear();
  while (istr) {
    // just "peek" at the next character in the stream
    c = istr.peek();
    if (isspace(c)) {
      // skip whitespace before a word starts
      istr.get(c);
      if (word != "") {
	// break words at whitespace
	return true;
      }
    } else if (c == '"') {
      // double quotes are a delimiter and a special "word"
      if (word == "") {
	istr.get(c);
	word.push_back(c);
      }
      return true;
    } else if (isalpha(c)) {
      // this a an alphabetic word character
      istr.get(c);
      word.push_back(tolower(c));
    } else {
      // ignore this character (probably punctuation)
      istr.get(c);
    }
  }
  return false;
}


// Custom helper function that reads the input stream looking a
// sequence of words inside a pair of double quotes.  The words are
// separated by white space, but the double quotes might not have
// space between them and the neighboring word.  Punctuation is
// ignored and words are lowercased.
std::vector<std::string> ReadQuotedWords(std::istream &istr) {
  // returns a vector of strings of the different words
  std::vector<std::string> answer;
  std::string word;
  bool open_quote = false;
  while (ReadNextWord(istr,word)) {
    if (word == "\"") {
      if (open_quote == false) { open_quote=true; }
      else { break; }
    } else {
      // add each word to the vector
      answer.push_back(word);
    }
  }
  return answer;
}



// Loads the sample text from the file, storing it in the map data
// structure Window specifies the width of the context (>= 2) of the
// sequencing stored in the map.  parse_method is a placeholder for
// optional extra credit extensions that use punctuation.
void LoadSampleText(MY_MAP &data, MY_MAP2 &data2, std::map<std::string, int> &count_map,
  const std::string &filename, int window, const std::string &parse_method) {
  // open the file stream
  std::ifstream istr(filename.c_str());
  if (!istr) { 
    std::cerr << "ERROR cannot open file: 2" << filename << std::endl; 
    exit(1);
  } 
  if (window < 2) {
    std::cerr << "ERROR window size must be >= 2:" << window << std::endl;
  }
  bool ignore_punctuation = false;
  if (parse_method == "ignore_punctuation") {
    ignore_punctuation = true;
  } else {
    std::cerr << "ERROR unknown parse method: " << parse_method << std::endl;
    exit(1);
  }
  //initialize string variables
  std::string word;
  std::string p_word;
  std::string pp_word;

  while (ReadNextWord(istr,word)) {
    if (word == "\"") continue;
    //increment one dimensional counter for word
    count_map[word]++;
    //increment 2-D counter for word and previous word
    data[p_word][word]++;
    //increment 3-D counter for word, previous word, and pp_word
    data2[pp_word][p_word][word]++;
    
    //move pp_word and p_word to the right when done
    pp_word = p_word;
    p_word = word;
  }
}

int main () {

  //initialize 1-D map(count_map), 2-D map(data), and 3-D map(data2)
  MY_MAP data;
  MY_MAP2 data2;
  std::map<std::string, int> count_map;

  // Parse each command
  std::string filename;
  std::string command;   
  int window; 
  while (std::cin >> command) {

    if (command == "load") {
      
      std::string parse_method;
      std::cin >> filename >> window >> parse_method;      

      LoadSampleText(data, data2, count_map, filename, window, parse_method);
      //print confirmation that the file has been loaded
      std::cout << "Loaded " << filename << " with window = " <<
      window << " and parse method = " << parse_method << std::endl; std::cout<<std::endl;
    } 

    else if (command == "print") {
      std::vector<std::string> sentence = ReadQuotedWords(std::cin);

      if (sentence.size() == 1) {

        //initialize 2-D map iterator
        MY_MAP::iterator it = data.find(sentence[0]);
        //print total number of occurrences of the word
        std::cout << sentence[0] << " (" << count_map[sentence[0]] << ")" << std::endl;
        //initialize iterator for the inside map
        std::map<std::string, int>::iterator n_it;
        
        //loop through the inside map
        for (n_it = it->second.begin(); n_it != it->second.end(); ++n_it) {
          std::string word2 = n_it->first;
          //print next word and its corresponding second value
          std::cout << sentence[0] << " " << word2 << " (" << data[sentence[0]][word2] << ")" << std::endl;
        } std::cout << std::endl;
      }
      else if (sentence.size() == 2) {

        //initialize outside and inside map iterators and next word string variable
        MY_MAP2::iterator it = data2.find(sentence[0]);
        MY_MAP::iterator n_it = it->second.find(sentence[1]);
        std::string word2 = n_it->first;
        //print how many times the phrase occurs
        std::cout << sentence[0] << " " << word2 << " (" << data[sentence[0]][word2] << ")" << std::endl;
        
        //loop through inside map and print how many times each third word occurs after the given phrase
        std::map<std::string, int>::iterator pp_it;
        for (pp_it = n_it->second.begin(); pp_it != n_it->second.end(); ++pp_it) {
          std::string word3 = pp_it->first;
          std::cout << sentence[0] << " " << word2 << " " << word3 << " (" << pp_it->second << ")" << std::endl;
        }
        std::cout << std::endl;
      }


    }

    else if (command == "generate") {
      std::vector<std::string> sentence = ReadQuotedWords(std::cin);
      int length;
      std::cin >> length;
      std::string selection_method;
      std::cin >> selection_method;
      bool random_flag;
      if (selection_method == "random") {
	     random_flag = true;
      } else {
      	assert (selection_method == "most_common");
      	random_flag = false;
      }

      if (random_flag) {
        if (window == 2) {          

          //initialize vector to hold each word a proportionate number of times to 
          //how often they appear
          std::vector<std::string> selector_vector;
          for (int i = 0; i < length; i++) {

            //initialize outside map iterator, count variable, and inside map iterator
            MY_MAP::iterator it = data.find(sentence[i]);
            int appearances = count_map[sentence.back()];
            std::map<std::string, int>::iterator n_it;            

            //loop through inside map and push back every word the same number of times
            // it appears
            for (n_it = it->second.begin(); n_it != it->second.end(); ++n_it) {
              for (int j = 0; j < n_it->second; j++) {
                selector_vector.push_back(n_it->first);
              }
            }
            
            //choose a random number out of the total number of word appearances
            int selection = std::rand() % appearances;
            
            //select a word correlating to the random number and add it onto sentence
            sentence.push_back(selector_vector[selection]);
            
            //clear for next iteration
            selector_vector.clear();
          }

          //print each word in the new sentence
          std::cout << sentence[0];
          for (int i = 1; i < sentence.size(); i++) {
            std::cout << " " << sentence[i];
          }
          std::cout << "\n\n";
        }

        else if (window == 3) {


          if (sentence.size() == 1) {

            //run code from window == 2 for the first word, then use the new sentence
            // as a phrase and continue with the window == 3 code

            //initialize vector to hold each word a proportionate number of times to 
            //how often they appear
            std::vector<std::string> selector_vector;
            //initialize outside map iterator, count variable, and inside map iterator
            MY_MAP::iterator it = data.find(sentence[0]);
            int appearances = count_map[sentence.back()];
            std::map<std::string, int>::iterator n_it;            

            //loop through inside map and push back every word the same number of times
            // it appears
            for (n_it = it->second.begin(); n_it != it->second.end(); ++n_it) {
              for (int j = 0; j < n_it->second; j++) {
                selector_vector.push_back(n_it->first);
              }
            }            
            //choose a random number out of the total number of word appearances
            int selection = std::rand() % appearances;            
            //select a word correlating to the random number and add it onto sentence
            sentence.push_back(selector_vector[selection]);            
            //clear for next iteration
            selector_vector.clear();            
          }

          //loop through length
          for (int i = 0; i < length; i++) {
            //remember how many times each word appears in scope of window = 3
            int appearances = data[sentence[i]][sentence[i+1]];

            //initialize iterators for outside, middle, and inside maps
            MY_MAP2::iterator o_it = data2.find(sentence[i]);
            MY_MAP::iterator m_it = o_it->second.find(sentence[i+1]);
            std::map<std::string, int>::iterator i_it;

            //initialize vector to hold each word a proportionate number of times to 
            //how often they appear
            std::vector<std::string> selector_vector;

            //loop through inside map and add each word the same number of times it 
            // appears in scope of window = 3
            for (i_it = m_it->second.begin(); i_it != m_it->second.end(); ++i_it) {
              for (int i = 0; i < i_it->second; i++) {
                selector_vector.push_back(i_it->first);
              }
            }

            //select random number out of the number of times the word appears
            int selection = std::rand() % appearances;
            //push back corresponding vector index to sentence
            sentence.push_back(selector_vector[selection]);
            //clear vector for next iteration
            selector_vector.clear();
          }

          //print sentence with appropriate formatting
          std::cout << sentence[0];
          for (int i = 1; i < sentence.size(); i++) {
            std::cout << " " << sentence[i];
          }
          std::cout << "\n\n";
        }

      }

      else if (!random_flag) {        

        if (window == 2) {
          
          //loop through length
          for (int i = 0; i < length; i++) {

            //initialize iterators for outside and inside maps, and one to hold
            // most common map value
            MY_MAP::iterator it = data.find(sentence.back());
            std::map<std::string, int>::iterator n_it;
            std::map<std::string, int>::iterator most_common = it->second.begin();

            //loop through inside map
            for (n_it = it->second.begin(); n_it != it->second.end(); ++n_it) {
              //if given word occurs more than the current "most common", 
              // reassign it to the given word
              if (n_it->second > most_common->second) {
                most_common = n_it;
              }
            }
            //push back most common word
            sentence.push_back(most_common->first);
          }

          //print sentence with appropriate formatting
          std::cout << sentence[0];
          for (int i = 1; i < sentence.size(); i++) {
            std::cout << " " << sentence[i];
          } std::cout << "\n\n";
        }

        else if (window == 3) {

          if (sentence.size() == 1) {

            //use window = 2 code for first iteration, then use new sentence 
            // as a phrase to generate with scope window = 3

            //initialize iterators for outsided map, inside map, "most common"
            // placeholder
            MY_MAP::iterator it = data.find(sentence.back());
            std::map<std::string, int>::iterator n_it;
            std::map<std::string, int>::iterator most_common = it->second.begin();

            //loop through inside map, if any given word occurs more than current
            // most common word, reassign most common to be the given word
            for (n_it = it->second.begin(); n_it != it->second.end(); ++n_it) {
              if (n_it->second > most_common->second) {
                most_common = n_it;
              }
            }
            //push back most common word onto sentence
            sentence.push_back(most_common->first);
            //decrease length so the loop doesn't append an extra word since
            // first iteration is now done
            length--;        
          }

          //loop through length
          for (int i = 0; i < length; i++) {
            //initialize iterators for outside, middle, inside maps, and "most common"
            // placeholder
            MY_MAP2::iterator o_it = data2.find(sentence[i]);
            MY_MAP::iterator m_it = o_it->second.find(sentence[i+1]);
            std::map<std::string, int>::iterator i_it;
            std::map<std::string, int>::iterator most_common = m_it->second.begin();

            //loop through inside map, if given word occurs more than currect "most common",
            // reassign most_common to be the given word
            for (i_it = m_it->second.begin(); i_it != m_it->second.end(); ++i_it) {
              if (i_it->second > most_common->second) {
                most_common = i_it;
              }
            }
            //push back most common word onto sentence
            sentence.push_back(most_common->first);
          }

          //print sentence with appropriate formatting
          std::cout << sentence[0];
          for (int i = 1; i < sentence.size(); i++) {
            std::cout << " " << sentence[i];
          } std::cout << "\n\n";
        }
      }
    } else if (command == "quit") {
      break;
    } else {
      std::cout << "WARNING: Unknown command: " << command << std::endl;
    }
  }
}