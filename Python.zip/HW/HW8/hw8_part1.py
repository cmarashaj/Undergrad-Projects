from Bear import Bear
from BerryField import BerryField
from Tourist import Tourist
import json

#input, formatting
f = input('Enter the json file name for the simulation => ').strip()
print(f)
print()
f = open(f)
data = json.loads(f.read())

#load in data from json file
raw_berry_field = data["berry_field"]
raw_active_bears = data["active_bears"]
raw_reserve_bears = data["reserve_bears"]
raw_active_tourists = data["active_tourists"]
raw_reserve_tourists = data["reserve_tourists"]
#convert to respective objects
active_bears = []
for bear in raw_active_bears:
    #create a bear object
    bear_ob = Bear(bear,'active')
    active_bears.append(bear_ob)
reserve_bears = []
for bear in raw_reserve_bears:
    bear_ob = Bear(bear,'reserve')
    reserve_bears.append(bear_ob)
active_tourists = []
for tourist in raw_active_tourists:
    t_ob = Tourist(tourist,'active')
    active_tourists.append(t_ob)
reserve_tourists = []
for tourist in raw_reserve_tourists:
    t_ob = Tourist(tourist,'reserve')
    reserve_tourists.append(t_ob)
#create berryfield object
field_object = BerryField(raw_berry_field,active_bears,active_tourists)
#print initial status
print("Field has {} berries.".format(field_object.berries))
print(field_object)
print("Active Bears:")
for bear in active_bears: print(bear)
print('\nActive Tourists:')
for t in active_tourists: 
    print(t)