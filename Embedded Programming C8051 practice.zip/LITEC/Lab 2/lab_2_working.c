/*  Names: Niyanthri, Megan, Caila 
    Section: 1
    Date: 06/04/2019
    File name: Lab 2
    Description:
*/
/*
  This program runs all three modes for Lab 2
*/

#include <c8051_SDCC.h>// include files. This file is available online
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------
void Port_Init(void);
void Interrupt_Init(void);
void Timer_Init(void);
void ADC_Init(void);
void Timer0_ISR(void) __interrupt 1;
unsigned char read_AD_input(unsigned char pin_number);
unsigned char calculate_voltage(void);
unsigned char calculate_voltage(void);
void set_sequence(int n);
bool check_button(int n);
void count_presses(int n,unsigned char overflows);
void mode_1(void);
void mode_2(void);
void mode_3(void);
void turn_off_LED(void);
void rotation(void);



//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
__sbit __at 0xA6 LED2;
__sbit __at 0xA7 LED3;
__sbit __at 0xA4 LED0;
__sbit __at 0xA5 LED1;
__sbit __at 0xA2 BILED1;
__sbit __at 0xA3 BILED0;
__sbit __at 0xB2 PB0;
__sbit __at 0xB3 PB1;
__sbit __at 0xB4 PB2;
__sbit __at 0xB5 PB3;
__sbit __at 0xB6 SS0;
__sbit __at 0xB7 SS1;

unsigned int counts;
unsigned char AD_value;
unsigned char value;
unsigned int player1_score;
unsigned int player2_score;
unsigned int other_counts;
bool player1_penalty = 0;
bool player2_penalty = 0;

unsigned int LED_num;
bool turn;
bool turn_done;
unsigned int round_num;
unsigned int on_time;
unsigned int debounce_counts;
unsigned int p1_score;
unsigned int p2_score;
unsigned int overflows;

//***************
void main(void)
{
    Sys_Init();      // System Initialization
    Port_Init();      
    Interrupt_Init();
    Timer_Init();    
    ADC_Init();
    putchar(' ');    
    
	printf("\r\nStart\r\n");
    while (1) //start infinite while loop
    {
		while(PB0);
		if(!SS0 && !SS1)
		{
			printf("\r\nMode 3\r\n");
			TR0 = 1; 
			mode_3();
			TR0 = 0;
		}
		else if(SS0 && SS1)
		{
			turn_off_LED();
			printf("\r\n No Mode Selected\r\n");
		}

		else if(!SS0 && SS1)
		{
			printf("\r\nMode 1\r\n");
			TR0 = 1;
			mode_1();
			TR0 = 0;
		}

		else if(SS0 && !SS1)
		{
			printf("\r\nMode 2\r\n");
			TR0 = 1;
			mode_2();
			TR0 = 0;
		}
        
    }
}

void mode_1(void)
{
	turn_off_LED();
	BILED0 = 1;
	BILED1 = 1;

	set_sequence(1);
	set_sequence(2);
	set_sequence(3);

	turn_off_LED(); //Remove before check off

}
void mode_2(void)
{
	player1_score = 0;
	player2_score = 0;
	player1_penalty = 0;
	player2_penalty = 0;

	round_num = 0;

	while((round_num < 3)&&!SS1)
	{
		overflows = calculate_voltage();
		count_presses(3,overflows);
		count_presses(1,overflows);
		
	
		round_num++;

	}

	printf("\r\nPlayer 1 score: %d\r\n",player1_score);
	printf("\r\nPlayer 2 score: %d\r\n",player2_score);

	if (player1_penalty & player2_penalty)
	{
		BILED0 = 1;
		BILED1 = 1;
		printf("Both lost\r\n");
	}
	//else if ((player1_score > player2_score) && !player1_penalty)
	else if(((player1_score > player2_score) & !player1_penalty)||player2_penalty)
	{
		BILED1 = 0;
		BILED0 = 1;
		printf("Winner:Player 1\r\n");
	}

	else if (((player1_score < player2_score) & !player2_penalty)||player1_penalty)
	{
		BILED0 = 0;
		BILED1 = 1;
		printf("Winner:Player 2\r\n");
	}

	else if (player1_score == player2_score)
	{
		
		BILED0 = 1;
		BILED1 = 1;
		printf("TIE\r\n");
	}

}
void mode_3(void)
{
	turn_off_LED();
	round_num = 0;
	player1_score = 0;
	player2_score = 0;
	turn = false;
	while (round_num < 5) {
		printf("\r\nround %d", round_num);
		printf("\r\nplayer 1 score = %d", player1_score);
		printf("\r\nplayer 2 score = %d", player2_score);
		rotation();
		turn = !turn;
		rotation();
		turn = !turn;
		round_num++;
	}
	if (player1_score < player2_score) {
		printf("\r\nPlayer 1 wins");
		BILED1 = 0;
		BILED0 = 1;
	}
	else if (player1_score > player2_score) {
		printf("\r\nPlayer 2 wins");
		BILED1 = 1;
		BILED0 = 0;
	}
	else {
		printf("\r\nTIE");
	}
}
unsigned char calculate_voltage(void)
{
	AD_value = read_AD_input(1);
	value = AD_value * 71.25;

	return value;
}

void turn_LED_on(int n)
{
	if(n == 0)
	{
		LED0 = 0;
		LED1 = 1;
		LED2 = 1;
		LED3 = 1;
	}
	
	if(n == 1)
	{
		LED0 = 1;
		LED1 = 0;
		LED2 = 1;
		LED3 = 1;
	}

	if(n == 2)
	{
		LED0 = 1;
		LED1 = 1;
		LED2 = 0;
		LED3 = 1;
	}

	if(n == 3)
	{
		LED0 = 1;
		LED1 = 1;
		LED2 = 1;
		LED3 = 0;
	}
}
	
void set_sequence(int n)
{
	if(n == 1)
	{
		overflows = calculate_voltage();

		printf("LED0 is on");
		turn_LED_on(0);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(1);
		counts = 0;
		while(counts < overflows);
		

		turn_LED_on(2);
		counts = 0;
		while(counts < overflows);


		turn_LED_on(3);
		counts = 0;
		while(counts < overflows);
	
		turn_LED_on(0);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(3);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(2);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(1);
		counts = 0;
		while(counts < overflows);
	}

	if(n == 2)
	{
		overflows = calculate_voltage();
	
		turn_LED_on(0);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(2);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(3);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(1);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(3);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(2);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(0);
		counts = 0;
		while(counts < overflows);
	}

	if(n == 3)
	{
		overflows = calculate_voltage();
	
		turn_LED_on(3);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(1);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(3);
		counts = 0;
		while(counts < overflows);

		turn_LED_on(1);
		counts = 0;
		while(counts < overflows);
	}
}

//Checks if the correct button is pushed
bool check_button(int n)
{
	return (n==3 & !PB3) || (n==1 & !PB1);
}

void count_presses(int n,unsigned char overflows)
{
	turn_LED_on(n);
	counts = 0;
	while(counts < overflows)
	{
		//Checks if the other player accidently pushed the button when its not their turn
		if(n==3 & !PB1)
		{
			player2_penalty = 1;
		}
	
		if(n==1 & !PB3)
		{
			player1_penalty = 1;
		}

		//If the player pushes the correct button
		if(check_button(n))
		{
			other_counts = 0;
			while(other_counts < 7);
			
			if(check_button(n))
			{
				if(n == 3)
				{
					while(!PB3);
				}

				if(n == 1)
				{
					while(!PB1);
				}

				if((n == 3) && (counts < overflows))
				{
					player1_score++;
				}
				
				if((n == 1) && (counts < overflows))
				{
					player2_score++;
				}

				other_counts = 0;
				while(other_counts < 7);
			}
		}
	
	}
}
void turn_off_LED(void)
{
	LED0 = 1;
	LED1 = 1;
	LED2 = 1;
	LED3 = 1;
}

//mode 3
void rotation(void) 
{
	on_time = calculate_voltage();
	turn_done = false;

	LED_num = rand()%3; //determine starting LED
	//light starting LED

	
	while (turn_done == false) {
		//printf("\r\n turn not done");
		turn_off_LED();
		
		if (turn == false) { //player 1's turn
			player1_score++;
		}
		else { //player 2's score
			player2_score++;
		}		

		if (LED_num == 0) {
			//check button 0
			counts = 0;
			while (counts < on_time) {
				LED0 = 0; //light LED0
				//if button is pushed, turn done = true;
				if (!PB0) {
					debounce_counts = counts;
					while (counts < (debounce_counts + 7)); //wait 20ms
					if (!PB0) {
						while (!PB0);
						turn_done = true;						
					}
					debounce_counts = counts;
					while (counts < (debounce_counts + 7)) {}
				}

			}
			//LED0 = 1;		

		}
		else if (LED_num == 1) {
			//check button 1
			counts = 0;
			while (counts < on_time) {
				LED1 = 0;
				//if button is pushed, turn done = true;
				if (!PB1) {
					debounce_counts = counts;
					while (counts < (debounce_counts + 41)); //wait 20ms
					if (!PB1) {
						while(!PB1);
						turn_done = true;
					}
					debounce_counts = counts;
					while (counts < (debounce_counts + 7));
				}

			}
			//LED1 = 1;

		}
		else if (LED_num == 2) {
			//check button 2
			counts = 0;
			while (counts < on_time) {
				LED2 = 0;
				//if button is pushed, turn done = true;
				if (!PB2) {
					debounce_counts = counts;
					while (counts < (debounce_counts + 41)); //wait 20ms
					if (!PB2) {
						while (!PB2);
						turn_done = true;
					}
					debounce_counts = counts;
					while (counts < (debounce_counts + 7));
				}

			}
			//LED2 = 1;
		}
		else if (LED_num == 3) {
			//possibly might want to turn on LED here instead
			//check button 3
			counts = 0;
			while (counts < on_time) {
				LED3 = 0;
				//if button is pushed, turn done = true;
				if (!PB3) {
					debounce_counts = counts;
					while (counts < (debounce_counts + 41)); //wait 20ms
					if (!PB3) {
						while (!PB3);
						turn_done = true;
					}
					debounce_counts = counts;
					while (counts < (debounce_counts + 7));
				}

			}
			//LED3 = 1;
		}



		//determine next LED		
		if (turn == false) { //player 1's turn
			if ((LED_num == 0) || (LED_num == 1) || (LED_num == 2)) {
				LED_num++;
			}
			else { //LED_num == 3
				LED_num = 0;
			}
		}
		else { //player 2's turn
			if ((LED_num == 1) || (LED_num == 2) || (LED_num == 3)) {
				LED_num--;
			}
			else { //LED_num == 0
				LED_num = 3;
			}
		}


	}
	

}
//***************
void Port_Init(void)
{
	P1MDOUT |= 0xFD;
	P1MDIN &= 0xFD;
	P1 |= 0x02;
	P2MDOUT |= 0xF8;
	P3MDOUT &= ~0xFC;
	P3 |= 0xFC;
}

void Interrupt_Init(void)
{
    IE |= 0x82;      // enable Timer0 Interrupt request (by masking)
    EA = 1;       // enable global interrupts (by sbit)
}
//***************
void Timer_Init(void)
{

    CKCON |= 0x08;  // Timer0 uses SYSCLK as source
    TMOD &= 0xF0;   // clear the 4 least significant bits
    TMOD |= 0x01;   // Timer0 in mode 1
    TR0 = 0;           // Stop Timer0
    TL0 = 0;
    TMR0 = 0;           // Clear high & low byte of T0

}

void ADC_Init(void)
{
    REF0CN = 0x03; //Vref = 2.4V
    ADC1CN = 0x80; //enable A/D coversion
    ADC1CF &= ~0x02;
    ADC1CF |= 0x01;
}


//***************
void Timer0_ISR(void) __interrupt 1
{
 	counts++;
	other_counts++;   
}

unsigned char read_AD_input(unsigned char pin_number)
{
	AMX1SL = pin_number;
	ADC1CN = ADC1CN & ~0x20; /* Clear the �Conversion Completed� flag */
 	ADC1CN = ADC1CN | 0x10; /* Initiate A/D conversion */
 	while ((ADC1CN & 0x20) == 0x00); /* Wait for conversion to complete */
	return ADC1;
}