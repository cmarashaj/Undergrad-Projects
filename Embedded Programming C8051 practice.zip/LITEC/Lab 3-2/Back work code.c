/*	Names: Ben Lane & Mike Medica
	Section: 03
	Date: 18OCT2011
	File Name: lab3.2.c
	Program Description: Controls Read/Write of Electric Compass
*/

#include <c8051_SDCC.h>
#include <stdio.h>
#include <i2c.h>

// Function Prototypes
void initialize();
void initXBR0();
void initPCA0();
void initPCA0Interrupt();
void PCA_ISR() interrupt 9;
void initSMB();
unsigned int readHeading();

//Global Variables
unsigned int PCA0Start = 28671;
unsigned short int headingCount = 0;
unsigned short int newHeading = 1;

int main(){
	unsigned int heading;				//Heading compass point to in degrees (0 - 3599)
	initialize();
	while(1){
		if(newHeading){
			heading = readHeading();	//Sets heading to value returned by copass
			printf("Heading: %u\n\r", heading);
			newHeading = 0;
		}
	}
	return 0;
}

void initialize(){
	Sys_Init();
	putchar(' ');
	initXBR0();
	initPCA0();
	initPCA0Interrupt();
	initSMB();
}

void initXBR0(){
	XBR0 = 0x27;			//Register CEX0, CEX1, CEX2, CEX3 URART0, SPI0, and SMB0
}

void initPCA0(){
	PCA0MD = 0x81;			//Suspend while controller is idle, SYSCLK/12, Enable CF iterrupts
	PCA0CPM0 = 0xC2;		//16 bit counter, enable comparator function
	PCA0CN = 0x40;			//Enable PCA
}

void initPCA0Interrupt(){
	IE |= 0x80;				//Enable all interrups
	EIE1 |= 0x08;			//Enable PCA0 interrupts
}

void PCA_ISR() interrupt 9{
	headingCount++;			//Increment headingCount
	PCA0L = PCA0Start;		//Low byte of start count
	PCA0H = PCA0Start >> 8;	//High byte of start cout
	CF = 0;					//Clear interrupt flag
	//If 20 ms has passed, show that new heading is needed
	if(headingCount > 2){
		newHeading = 1;
		headingCount = 0;	//Reset headingCount
	}
}

void initSMB(){
	SMB0CR = 0x93;			//SCL set to 100kHz
	ENSMB = 1;				//Enable SMBus
}

unsigned int readHeading(){
	unsigned char compassAddress = 0xC0;		//Address of Electronic Compass
	unsigned char compassData[2];				//Array to store data from Compass
	unsigned int heading;						//Heading returned in degrees (0 - 3599)
	//Read data drom electronic compass
	i2c_read_data(compassAddress, 0x02, compassData, 2);
	//Store data in heading variable
	heading = (( (unsigned int)compassData[0] << 8) | (unsigned int)compassData[1]);
	return heading;
}
