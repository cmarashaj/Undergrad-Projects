HOMEWORK 4: PREFERENCE LISTS


NAME:  < Caila Marashaj >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Lauren McAlarney, Chelsea Bovell, Ta Tim, ALAC drop in tutoring, Mentor Matt >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 25 >



ORDER NOTATION:
Give the order notation for each function below assuming
m schools, s slots per school, r rankings of students by each school,
n students, and p preferences of schools by each student.
Write one or two sentences justifying each answer.


add_school
O(np)
un-nested for loop is the highest order operation in the function
uses studetns and preferences


insert_student_into_school_preference_list
O(m)
un-nested for loop is the highest order operation


print_school_preferences
O(mp)
un-nested for loop is the highest order operation


add_student
O(mp)
un-nested for loop is the highest order operation
uses schools and preferences


remove_school_from_student_preference_list
O(m)
un-nested for loop is the highest order operation


print_student_preferences
O(np)
un-nested


perform_matching
O(nlog(n))
uses gale shapley  algorithm

print_school_enrollments
O(s)

print_student_decisions
O(ms)



OPTIONAL EXTRA CREDIT:
Describe the two different iterative loops that you selected to
rewrite using recursion.  



MISC. COMMENTS TO GRADER:  
Optional, please be concise!


