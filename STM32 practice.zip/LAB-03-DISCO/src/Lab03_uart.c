//------------------------------------
// Lab 3 - Part 1: UART - Lab03_uart.c
//------------------------------------
//

#include "init.h"

// Main Execution Loop
int main(void) {
	//Initialize the system
	Sys_Init();

	printf("Your code here!\r\n");

	// Lost? Check out uart.c!

}
