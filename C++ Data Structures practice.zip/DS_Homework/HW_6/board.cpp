#include <iostream>
#include <iomanip>
#include <cmath>
#include <cassert>

#include "board.h"


// ============================================================================
// CONSTRUCTOR
Board::Board(const std::string& filename, bool inverse) {

  // open up the file
  std::ifstream istr(filename);
  assert (istr.good());
  
  // Regular mode: Find the path that matches the input cell labels
  if (!inverse) {
    std::string s;
    int row = 0;
    // read each row
    while (istr >> s) {
      board.push_back(std::vector<int>());
      // read each cell/column
      for (int i = 0; i < s.size(); i++) {
        if (s[i] == '.') {
          // we represent unlabeled cells with -1
          board[row].push_back(-1);
        } else {
          int foo = atoi(std::string(1,s[i]).c_str());
          assert (foo >= 0 && foo <= 4);
          board[row].push_back(foo);
        }
      }
      assert (board[row].size() == board[0].size());
      row++;
    }
    // all of the edges are currently unknown, which we represent with -1
    horizontal = std::vector<std::vector<int> >(board.size()+1,std::vector<int>(board[0].size(),-1));
    vertical   = std::vector<std::vector<int> >(board.size(),std::vector<int>(board[0].size()+1,-1));
    visited_h = std::vector<std::vector<bool> >(board.size()+1,std::vector<bool>(board[0].size(), false));
    visited_v = std::vector<std::vector<bool> >(board.size(),std::vector<bool>(board[0].size()+1, false));
  }

  // Inverse mode: Find a cell labeling whose solution is the input path
  else {
    // read the horizontal edge data
    char str[1000];
    int row = 0;
    std::string s;
    while (1) {
      // note: we use getline here because we want to handle the
      // blank line between horizontal and vertical edge data
      istr.getline(str,1000);
      s = str;
      if (s == "") break;
      horizontal.push_back(std::vector<int>());
      for (int i = 0; i < s.size(); i++) {
        if (s[i] == '.') {
          // no edge is represented with the value zero
          horizontal[row].push_back(0);
        } else {
          // edge is represented with the value 1
          assert (s[i] == '-');
          horizontal[row].push_back(1);
        }
      }
      assert (horizontal[row].size() == horizontal[0].size());
      row++;
    }
    assert (horizontal.size() >= 2);
    // read the vertical edge data
    row = 0;
    while (istr >> s) {
      vertical.push_back(std::vector<int>());
      for (int i = 0; i < s.size(); i++) {
        if (s[i] == '.') {
          // no edge is represented with the value zero
          vertical[row].push_back(0);
        } else {
          // edge is represented with the value 1
          assert (s[i] == '|');
          vertical[row].push_back(1);
        }
      }
      assert (vertical[row].size() == horizontal[0].size()+1);
      row++;
    }
    assert (vertical.size() +1 == horizontal.size());
    // note that the cell data dimensions are slightly different than
    // the horizontal and vertical edge data.  The vertical data has
    // an extra column, and the horizontal data has an extra row.
    board = std::vector<std::vector<int> >(horizontal.size()-1,std::vector<int>(horizontal[0].size(),-1));
  }
}


// ============================================================================
// SMALL HELPER ROUTINES FOR ASCII ART PRINTING CHARACTERS
char vChar(int i)  {
  if (i == -1) return '?';
  if (i == 0) return ' ';
  assert (i == 1); return '|';
}
char hChar(int i) {
  if (i == -1) return '?';
  if (i == 0) return ' ';
  assert (i == 1); return '-';
}
char valueChar(int i) {
  if (i == -1) return ' ';
  if (i == 0) return '0';
  if (i == 1) return '1';
  if (i == 2) return '2';
  if (i == 3) return '3';
  assert (i == 4); return '4';
}


// ============================================================================
// PRINT AN ASCII ART REPRESENTATION OF THE CURRENT BOARD
// Note: Yes, this function exceeds normal line width.  
void Board::print() const {
  // loop over each row of the board
  for (int j = 0; j < board.size(); j++) {
    assert (board[0].size() == board[j].size());
    // what is the rightmost vertical edge for this row?
    char right = vChar(vertical[j][board[j].size()]);
    // print the horizontal edges above the current row
    for (int i=0; i<board[j].size(); i++) { char top =hChar(horizontal[j][i]); std::cout<<"+" + std::string(5,top);                 } std::cout<<"+"<<std::endl; 
    // loop over the cells in the row
    for (int i=0; i<board[j].size(); i++) { char left=vChar(vertical[j][i]);   std::cout<<left<<"     ";                            } std::cout<<right<<std::endl;
    for (int i=0; i<board[j].size(); i++) { char left=vChar(vertical[j][i]);   std::cout<<left<<"  "<<valueChar(board[j][i])<<"  "; } std::cout<<right<<std::endl;
    for (int i=0; i<board[j].size(); i++) { char left=vChar(vertical[j][i]);   std::cout<<left<<"     ";                            } std::cout<<right<<std::endl;
  }
  // print the horizontal edges below the bottom row
  for   (int i=0; i<board[0].size(); i++) { char top =hChar(horizontal[board.size()][i]); std::cout<<"+" + std::string(5,top);      } std::cout<<"+"<<std::endl;
}


// print the non-ascii art version of the cell count data
// (can be used as input for the regular Slitherlink puzzle solver)
void Board::printPuzzle() const {
  for (int j = 0; j < board.size(); j++) {
    for (int i = 0; i < board[j].size(); i++) {
      if (board[j][i] == -1) {
        // unlabeled cells represented with .
        std::cout << ".";
      } else {
        std::cout << board[j][i];
      }
    }
    std::cout << std::endl;
  }
}


// print the non-ascii art version of the path data
// (can be used as input for the inverse Slitherlink puzzle generator)
void Board::printInverse() const {
  for (int j = 0; j < horizontal.size(); j++) {
    for (int i = 0; i < horizontal[j].size(); i++) {
      // it's an error to print a path with unknown edges
      assert (horizontal[j][i] != -1);
      if (horizontal[j][i] == 0) {
        // 'no edge' represented with .
        std::cout << ".";
      } else {
        assert (horizontal[j][i] == 1);
        // 'edge present' represented with -
        std::cout << "-";
      }
    }
    std::cout << std::endl;
  }
  // blank line between the data
  std::cout << std::endl;
  for (int j = 0; j < vertical.size(); j++) {
    for (int i = 0; i < vertical[j].size(); i++) {
      assert (vertical[j][i] != -1);
      if (vertical[j][i] == 0) {
        // 'no edge' represented with .
        std::cout << ".";
      } else {
        assert (vertical[j][i] == 1);
        // 'edge present' represented with |
        std::cout << "|";
      }
    }
    std::cout << std::endl;
  }
}


// ============================================================================
// NAIVE SOLVER METHODS

void Board::zeroEdges() {
  for (int j = 0; j < board.size(); j++) {
    for (int i = 0; i < board[j].size(); i++) {
      // cells labeled with 0 should have all edges set to 0 (no edge)
      if (board[j][i] == 0) {
        horizontal[j][i] = 0;
        horizontal[j+1][i] = 0;
        vertical[j][i] = 0;
        vertical[j][i+1] = 0;
      }
    }
  }
}

bool Board::solver(int j, int i, char orientation, int e_count, std::vector<Board> &solutions) {
  
  //i perform my optimization and ruling out before I run my recursion to save time
  // by killing paths that are definitely not solutions before I run any operations on themS

  //optimization: rule out board if there's too many edges for a given cell
  for (int n = 0; n < board.size(); n++) {
    for (int m = 0; m < board[n].size(); m++) {
      if (board[n][m] != -1) {
        int edges = 0;
        int empty = 0;
        int unknown = -1;

        //check top line
        if (horizontal[n][m] == 1) {edges++;}
        else if (horizontal[n][m] == 0) {empty++;}
        else if (horizontal[n][m] == -1) {unknown++;}
        
        //check left line
        if (vertical[n][m] == 1) {edges++;}
        else if (vertical[n][m] == 0) {empty++;}
        else if (vertical[n][m] == -1) {unknown++;}
        
        //check bottom line
        if (horizontal[n+1][m] == 1) {edges++;}
        else if (horizontal[n+1][m] == 0) {empty++;}
        else if (horizontal[n+1][m] == -1) {unknown++;}
        
        //check right line
        if (vertical[n][m+1] == 1) {edges++;}
        else if (vertical[n][m+1] == 0) {empty++;}
        else if (vertical[n][m+1] == -1) {unknown++;}

        

        if (edges > board[n][m]) {
          return false;
        }
        if ((4-empty) == board[n][m]) {
          if (horizontal[n][m] != 0) {
            horizontal[n][m] = 1;
          }
          if (vertical[n][m] != 0) {
            vertical[n][m] = 1;
          }
          if (horizontal[n+1][m] != 0) {
            horizontal[n+1][m] = 1;
          }
          if (vertical[n][m+1] != 0) {
            vertical[n][m+1] = 1;
          }
        }
      }
    }
  }

  //check if surrounding edges on either side of an edge are 0
  //if it happens on at least one side, board is no good

  // optimization: rule out dead ends

  //optimization: rule out        |       ----+----
  //                          ----+----       |

  for (int n = 0; n < horizontal.size(); n++) {
    for (int m = 0; m < horizontal[n].size(); m++) {
      //connected to the left
      if (horizontal[n][m] == 1 && m > 0 && horizontal[n][m-1] == 1) {
        //check above vertical
        if (n>0 && vertical[n-1][m] == 1) {return false;}
        //check below vertical
        if (n<vertical.size() && vertical[n][m] == 1) {return false;}
      }
      //connected to the right
      if (horizontal[n][m] == 1 && m < horizontal[n].size()-1 && horizontal[n][m+1] == 1) {
        //check above vertical
        if (n>0 && vertical[n-1][m+1] == 1) {return false;}
        //check below vertical
        if (n<vertical.size() && vertical[n][m+1] == 1) {return false;}
      }



      if (horizontal[n][m] == 1) {
        //left edges
        bool left_up = true;
        bool left_down = true;
        bool left = true;
        //left up
        if (n>0) {
          if (vertical[n-1][m] == 0) {left_up = false;}
        } else {left_up = false;}

        //left down
        if (n < board.size()) {
          if (vertical[n][m] == 0) {left_down = false;}
        } else {left_down = false;}
        
        //left
        if (m > 0) {
          if (horizontal[n][m-1] == 0) {left = false;}
        } else {left = false;}


        //if no edges are connected return false
        if (!left_up && !left_down && !left) {
          return false;
        }

        //right edges
        bool right = true;
        bool right_up = true;
        bool right_down = true;
        //right up
        if (n > 0) {
          if (vertical[n-1][m+1] == 0) {right_up = false;}
        } else {right_up = false;}

        //right down
        if (n < board.size()) {
          if (vertical[n][m+1] == 0) {right_down = false;}
        } else {right_down = false;}

        //right
        if (m < board[0].size()) {
          if (horizontal[n][m+1] == 0) {right = false;}
        } else {right = false;}

        //if no edges are connected return false
        if (!right && !right_up && !right_down) {
          return false;          
        }
      }
    }
  }


  //optimization: rule out dead ends and |__    __|
  //                                     |        |
  for (int n = 0; n < vertical.size(); n++) {
    for (int m = 0; m < vertical[n].size(); m++) {
      //connected upwards       bottom segment
      if (vertical[n][m] == 1 && n>0 && vertical[n-1][m] == 1) {
        //check right egde
        if (m<(vertical[n].size()-1) && horizontal[n][m] == 1) {return false;}
        //check left edge
        if (m>0 && horizontal[n][m-1] == 1) {return false;}
      }
      //connected downwards     top segment
      if (vertical[n][m] == 1 && n<(vertical.size()-1 && vertical[n+1][m] == 1)) {
        //check right edge
        if (m<(vertical[n].size()-1) && horizontal[n+1][m] == 1) {return false;}
        //check left edge
        if (m>0 && horizontal[n+1][m-1] == 1) {return false;}
      }


      if (vertical[n][m] == 1) {

        //up edges
        bool up = true;
        bool up_left = true;
        bool up_right = true;

        // up
        if (n > 0) {
          if (vertical[n-1][m] == 0) {up = false;}
        } else {up = false;}
        //up right
        if (m < board[0].size()) {
          if (horizontal[n][m] == 0) {up_right = false;}
        } else {up_right = false;}
        //up left
        if (m > 0) {
          if (horizontal[n][m-1] == 0) {up_left = false;}
        } else {up_left = false;}
        
        if (!up && !up_left && !up_right) {
          return false;
        }


        //down edges
        bool down = true;
        bool down_left = true;
        bool down_right = true;

        //down left
        if (n < board.size()-1) {
          if (vertical[n+1][m] == 0) {down = false;}
        } else {down = false;}
        //down right
        if (m < board[0].size()) {
          if (horizontal[n+1][m] == 0) {down_right = false;}
        } else {down_right = false;}
        //down left
        if (m > 0) {
          if (horizontal[n+1][m-1] == 0) {down_left = false;}
        } else {down_left = false;}

        //if no edges are connected return false
        if (!down && !down_right && !down_left) {
          return false;
        }
      } 
    }
  }

  //check if current 1's form a correct solution
 bool satisfies_values = true;
 for (int n = 0; n < board.size(); n++) {
    for (int m = 0; m < board[n].size(); m++) {
      if (board[n][m] != -1) {
        int edges = 0;

        //count the edges surrounding a cell and make sure they're equal 
        // to the board value

        if (horizontal[n][m] == 1) {
          edges++;
        }
        if (vertical[n][m] == 1) {
         edges++;
        }
        if (horizontal[n+1][m] == 1) {
         edges++;
        }
        if (vertical[n][m+1] == 1) {
          edges++;
        }

        // return false if the board is not true to every value
        if (edges != board[n][m]) {
          satisfies_values = false;
        }
      }
    }
  }




  if (satisfies_values) {
    //before I send off a board to solutions vector, make sure that it's a closed loop

    //check horizontal lines
    for (int n = 0; n < horizontal.size(); n++) {
      for (int m = 0; m < horizontal[n].size(); m++) {
        if (horizontal[n][m] == 1) {
          int left_e = 0;

          //check left up
          if (n>0) {
            if (vertical[n-1][m] == 1) {left_e++;}
          }
          //check left down
          if (n < board.size()) {
            if (vertical[n][m] == 1) {left_e++;}
          }      
          //check left  
          if (m > 0) {
            if (horizontal[n][m-1] == 1) {left_e++;}
          }

          if (left_e != 1) {
            return false;
          }


          int right_e = 0;

          //check right up
          if (n > 0) {
            if (vertical[n-1][m+1] == 1) {right_e++;}
          }
          //check right down
          if (n < board.size()) {
            if (vertical[n][m+1] == 1) {right_e++;}
          }
          //check right
          if (m < board[0].size()) {
            if (horizontal[n][m+1] == 1) {right_e++;}
          }

          if (right_e != 1) {
            return false;          
          }
        }
      }
    }



    //check vertical lines
    for (int n = 0; n < vertical.size(); n++) {
      for (int m = 0; m < vertical[n].size(); m++) {
         if (vertical[n][m] == 1) {

          //up edges
          int up_e = 0;

          //check up
          if (n > 0) {
            if (vertical[n-1][m] == 1) {up_e++;}
          }
          //check up right
          if (m < board[0].size()) {
            if (horizontal[n][m] == 1) {up_e++;}
          }
          //check up left
          if (m > 0) {
            if (horizontal[n][m-1] == 1) {up_e++;}
          }
          
          if (up_e != 1) {
            return false;
          }

          //check down edges
          int down_e = 0;

          //check down
          if (n < board.size()-1) {
            if (vertical[n+1][m] == 1) {down_e++;}
          }
          //check down right
          if (m < board[0].size()) {
            if (horizontal[n+1][m] == 1) {down_e++;}
          }
          //check down left
          if (m > 0) {
            if (horizontal[n+1][m-1] == 1) {down_e++;}
          }

          if (down_e != 1) {
            return false;
          }
        } 
      }
    }
    //set remaining unknowns to 0, and push back to solutions
    for (int n = 0; n < board.size(); n++) {
     for (int m = 0; m < board[n].size(); m++) {
       if (board[n][m] != -1) {
          //top edge
          if (horizontal[n][m] == -1) {
            horizontal[n][m] = 0;
          }
          //left edge
          if (vertical[n][m] == -1) {
            vertical[n][m] = 0;
          }
          //botton edge
          if (horizontal[n+1][m] == -1) {
            horizontal[n+1][m] = 0;
          }
          //right edge
          if (vertical[n][m+1] == -1) {
            vertical[n][m+1] = 0;
          }
        }
      }
    }
    solutions.push_back(*this);
    return true;
  }


  if (orientation == 'h') {

    //if current index has already been visited in its current path, it's not 
    //  a possible solution
    if (visited_h[j][i] == true) {
      return false;
    }

    visited_h[j][i] = true;

    //if current index is already set, skip over and recurse to surrounding
    // edges without making any changes
    if (horizontal[j][i] == 1 || horizontal[j][i] == 0) {
      if (i < horizontal[j].size()-1) {
      //right
        if (solver(j, i+1, 'h', e_count+1, solutions)) {return true;}
      }
      if (i > 0) {
        //left
        if (solver(j, i-1, 'h', e_count+1, solutions)) {return true;}
      }
      if (j > 0) {
        //left up
        if (solver(j-1, i, 'v', e_count+1, solutions)) {return true;}
        //right up
        if (solver(j-1, i+1, 'v', e_count+1, solutions)) {return true;}
      }
      if (j < horizontal.size()-1) {
        //left down
        if (solver(j, i, 'v', e_count+1, solutions)) {return true;}
        //right down 
        if (solver(j, i+1, 'v', e_count+1, solutions)) {return true;}
      }
    }
    else {
      
      //program will try setting the edge to 0, recurse on surrounding edges, then
      // try setting edge 1 to 1 and repeating the recursions, then set itself back to -1
      // and unviisted so different paths can later visit it in case the current one doens't
      // work

      //set edge to present
      horizontal[j][i] = 1;
      //recurse on surrounding edges
      if (i < horizontal[j].size()-1) {
        //right
        if (solver(j, i+1, 'h', e_count+1, solutions)) {return true;}
      }
      if (i > 0) {
        //left
        if (solver(j, i-1, 'h', e_count+1, solutions)) {return true;}
      }
      if (j > 0) {
        //left up
        if (solver(j-1, i, 'v', e_count+1, solutions)) {return true;}
        //right up
        if (solver(j-1, i+1, 'v', e_count+1, solutions)) {return true;}
      }
      if (j < horizontal.size()-1) {
        //left down
        if (solver(j, i, 'v', e_count+1, solutions)) {return true;}
        //right down 
        if (solver(j, i+1, 'v', e_count+1, solutions)) {return true;}
      }
      

      //set edge to not present
      horizontal[j][i] = 0;
      //recurse on surrounding edges
      if (i < (horizontal[j].size()-1)) {
        //right
        if (solver(j, i+1, 'h', e_count+1, solutions)) {return true;}
      }
      if (i > 0) {
        //left
        if (solver(j, i-1, 'h', e_count+1, solutions)) {return true;}
      }
      if (j > 0) {
        //left up
        if (solver(j-1, i, 'v', e_count+1, solutions)) {return true;}
        //right up
        if (solver(j-1, i+1, 'v', e_count+1, solutions)) {return true;}
      }
      if (j < (horizontal.size()-1)) {
        //left down
        if (solver(j, i, 'v', e_count+1, solutions)) {return true;}
        //right down 
        if (solver(j, i+1, 'v', e_count+1, solutions)) {return true;}
      }
    }
    //set back to -1 and unvisited
    horizontal[j][i] = -1;
    visited_h[j][i] = false;  
  }

  
  else if (orientation == 'v') {

    
    //if edge already visited in current path, exit the function
    if (visited_v[j][i] == true) {
      return false;
    }

    //set to true after the check
    visited_v[j][i] = true;

    //if edge is already set, recurse without making any changes
    if (vertical[j][i] == 1 || vertical[j][i] == 0) {
      if (j > 0) {
        //up
        if (solver(j-1, i, 'v', e_count+1, solutions)) {return true;}
      }
      if (j < (vertical.size()-1)) {
        //down
        if (solver(j+1, i, 'v', e_count+1, solutions)) {return true;}
      }
      if (i > 0) {
        //up left
        if (solver(j, i-1, 'h', e_count+1, solutions)) {return true;}
        //down left
        if (solver(j+1, i-1, 'h', e_count+1, solutions)) {return true;}
      }
      if (i < (vertical[j].size()-1)) {
        //up right
        if (solver(j, i, 'h', e_count+1, solutions)) {return true;}
        //down right
        if (solver(j+1, i, 'h', e_count+1, solutions)) {return true;}
      }
    }
    //set edge to present
    vertical[j][i] = 1;

    //recurse on surrounding edges
    if (j > 0) {
      //up
      if (solver(j-1, i, 'v', e_count+1, solutions)) {return true;}
    }
    if (j < (vertical.size()-1)) {
      //down
      if (solver(j+1, i, 'v', e_count+1, solutions)) {return true;}
    }
    if (i > 0) {
      //up left
      if (solver(j, i-1, 'h', e_count+1, solutions)) {return true;}
      //down left
      if (solver(j+1, i-1, 'h', e_count+1, solutions)) {return true;}    
    }
    if (i < (vertical[j].size()-1)) {
      //up right
      if (solver(j, i, 'h', e_count+1, solutions)) {return true;}
      //down right
      if (solver(j+1, i, 'h', e_count+1, solutions)) {return true;}
    }


    //set edge to not present
    vertical[j][i] = 0;

    //recurse on surrounding edges
    if (j > 0) {
      //up
      if (solver(j-1, i, 'v', e_count+1, solutions)) {return true;}
    }
    if (j < (vertical.size()-1)) {
      //down
      if (solver(j+1, i, 'v', e_count+1, solutions)) {return true;}  
    }
    if (i > 0) {
      //up left
      if (solver(j, i-1, 'h', e_count+1, solutions)) {return true;}
      //down left
      if (solver(j+1, i-1, 'h', e_count+1, solutions)) {return true;}    
    }
    if (i < (vertical[j].size()-1)) {
      //up right
      if (solver(j, i, 'h', e_count+1, solutions)) {return true;}
      //down right
      if (solver(j+1, i, 'h', e_count+1, solutions)) {return true;}
    }
 
    //set edge to -1 and unvisited
    vertical[j][i] = -1;
    visited_v[j][i] = false;
  }
  else {std::cout << "invalid argument" << std::endl; return false;}
  return false;
}

void Board::fourEdges() {
  for (int j = 0; j < board.size(); j++) {
    for (int i = 0; i < board[j].size(); i++) {
      // cells labeled with 4 should have all edges set to 1 (edge present)
      if (board[j][i] == 4) {
        horizontal[j][i] = 1;
        horizontal[j+1][i] = 1;
        vertical[j][i] = 1;
        vertical[j][i+1] = 1;
      }
    }
  }
}


// ============================================================================
// NAIVE GENERATOR METHODS

void Board::labelAllCells() {
  for (int j = 0; j < board.size(); j++) {
    for (int i = 0; i < board[0].size(); i++) {
      // simply label all cells to match their edge count (not very interesting)
      board[j][i] = countEdges(j,i);
    }
  }
}


// helper function for naive generator method
//for inverse
int Board::countEdges(int j, int i) {
  int answer = 0;
  if (horizontal[j][i]   ==  1) answer++;
  if (horizontal[j+1][i] ==  1) answer++;
  if (vertical[j][i]   ==  1) answer++;
  if (vertical[j][i+1] ==  1) answer++;
  return answer;
}
