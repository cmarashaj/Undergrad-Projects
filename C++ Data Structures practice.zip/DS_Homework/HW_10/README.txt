HOMEWORK 9: DISTANCE FIELDS & FAST MARCHING METHOD


NAME:  < Caila Marashaj >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Lauren McAlarney, Kevin Cruz >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 25 >



NAIVE ALGORITHM:

Order Notation:

O(w^2 * h^2)

the program runs through w*h for each iteration in the outer nested loop, therefore w*h occurs w*h times

Timing Experiment Data:

real    0m0.022s
user    0m0.000s
sys     0m0.000s

Discussion:
This method is inefficient, because of the sheer magnitude of nesting loops that occur within the function. As the images passed into the program get larger, the run time becomes longer at a much faster rate than the other methods



IMPROVED ALGORITHM:

Order Notation:

l = length of list of black pixels

O(w*h + w*h*l)

The function runs two separate w*h loops, and inside the second one loops through every index in the list of black pixels


Timing Experiment Data:

real    0m0.014s
user    0m0.000s
sys     0m0.016s

Discussion:
This method is more efficient, as there are still two loops but they are no longer inside each other and don't cause exponential growth of the runtime as input increases. It still can be improved, however, because the length of the list of black pixels, if large enough, can still slow the algorithm down



FAST MARCHING METHOD (with a map):


Order Notation:

might be O(n)

where n is the number of elements that have been inserted into the priority queue

Timing Experiment Data:

Discussion:
This method is even faster, as at any time it only considers the pixels that should be in the distance field that is currently being looked at, which are already sorted by distance to a black pixel in the priority queue



DISTANCE FIELD VISUALIZATIONS FOR EXTRA CREDIT:




FAST MARCHING METHOD (with a hash table) FOR EXTRA CREDIT:

Order Notation:

Timing Experiment Data:

Discussion:



MISC. COMMENTS TO GRADER:  
Optional, please be concise!






