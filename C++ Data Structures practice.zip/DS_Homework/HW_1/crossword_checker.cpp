#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>

using namespace std;

// check words in proposed solution using Ubuntu Linux American English Dictionary
int main(int argc, char** argv) {

//make sure that the correct number of arguments are given; if they are not, end program
if (argc > 4 || argc < 3){
	std::cerr<<"Incorrect number of arguments"<<std::endl;
}

//access puzzle.txt
std::ifstream puzzle_file(argv[1]);

//access linux dictionary
std::ifstream linux_file(argv[2]);

//ensure that arguments are valid files; if they are not, end program
if (!puzzle_file.good()) {
	std::cerr<<"Can't open " << argv[1] << std::endl;
	exit(1);
}

if (!linux_file.good()) {
	std::cerr<<"Can't open"<<argv[2]<<std::endl;
	exit(1);
}

//parse Linux English dictionary
std::string linux_dict_str;
std::vector <std::string> linux_vec;

while (linux_file >> linux_dict_str) {
	linux_vec.push_back(linux_dict_str);

}

//create a vector to represent the board by rows; each element is 1 row
std::vector <std::string> row_vec;
std::string puzzle_words;

while(puzzle_file>>puzzle_words) {
	row_vec.push_back(puzzle_words);
}


//initialize values to represent the size of the board
int row_num = row_vec.size();

int column_num = row_vec[0].size();


//create vector to represent each column; each element is 1 column
std::vector <std::string> column_vec;
for (int i = 0; i < column_num; i++) {
	std::string column_str;
	for (int j = 0; j < row_num; j++) {
		column_str.push_back(row_vec[j][i]);
	}
	column_vec.push_back(column_str);
}

//finding ACROSS words


//create vector to put every word, non-sorted in linux dictionary, into
std::vector <std::string> across_words_rough;

//this vector takes in rough words, both ACROSS and DOWN
std::vector <std::string> potential_words;


//create vectors to put information regarding position of every word, not yet sorted, into
std::vector <std::string> vert_coordinates;
std::vector <std::string> hor_coordinates;

//initialize values to represent word position/coordinates
int x;
int y;
//go through each position in each row, decide if each character is starting character, build unsorted words as such
for (int i = 0; i < row_num; i++ ) {
	//create "rough word" to send to vector to be sorted
	std::string rough_word = "";
	for (int j = 0; j < column_num; j++) {
		//if character is not starting letter and not "#", add to existing "rough word"
		if (row_vec[i][j] != '#' and (j+1 != column_num)) {
			rough_word += row_vec[i][j];

		}

		else if (row_vec[i][j] == '#') {
			// if we reach a "#", send current "rough word" to be sorted, then create new, empty "rough word"
			if (rough_word.size() > 1) {
				potential_words.push_back(rough_word);
				across_words_rough.push_back(rough_word);
				//keep track of coordinates for later use
				x = i;
				y = j - rough_word.size();
				//add location information to vector to use later
				hor_coordinates.push_back("(" + to_string(x) + "," + to_string(y) + ") ");

			}
			rough_word = "";
		}

		//if we reach the end of a row, add the last letter to "rough word", send "rough word" to be sorted, then create new, empty "rough word"
		else if (j+1 == column_num) {
			rough_word += row_vec[i][j];
			if (rough_word.size() > 1) {
				potential_words.push_back(rough_word);
				across_words_rough.push_back(rough_word);
				x = i;
				y = j - rough_word.size() + 1;
				//add location information to vector to use later
				hor_coordinates.push_back("(" + to_string(x) + "," + to_string(y) + ") ");
			}
			rough_word = "";
		}
	}
}


//finding DOWN words

//create vector for "rough words" to be filtered
std::vector <std::string> down_words_rough;


//go through each vertical position in each column, determine if a character is a starting letter 
for (int i = 0; i < column_num; i++ ) {
	std::string rough_word = "";
	for (int j = 0; j < row_num; j++) {
		//if character is a letter, but not a starting letter, add to current "rough word"
		if (column_vec[i][j] != '#' and (j+1 != row_num)) {
			rough_word += column_vec[i][j];

		}

		//if we reach a hashtag, send current "rough word" to be filtered, track location
		else if (column_vec[i][j] == '#') {
			if (rough_word.size() > 1) {
				potential_words.push_back(rough_word);
				down_words_rough.push_back(rough_word);
				y = i;
				x = j - rough_word.size();
				vert_coordinates.push_back("(" + to_string(x) + "," + to_string(y) + ") ");
			}
			rough_word = "";
		}

		//if we reach end of column, add last letter to "rough word", sedn to be filtered, wipe "rough word" clean, keep track of location 
		else if (j+1 == row_num) {
			rough_word += column_vec[i][j];
			if (rough_word.size() > 1) {
				potential_words.push_back(rough_word);
				down_words_rough.push_back(rough_word);
				y = i;
				x = j - rough_word.size() + 1;
				vert_coordinates.push_back("(" + to_string(x) + "," + to_string(y) + ") ");
			}
			rough_word = "";
		}
	}
}


//create vectors for "rough words" to be filtered into
std::vector <string> good_words;
std::vector <string> bad_words;
std::vector <std::string> across_words; 

bool a_found;
//check every rough word in linux dictionary, if it is found, send location information to good_words and across_words
for (int i = 0; i < across_words_rough.size(); i++) {
	a_found = false;
	for (int j = 0; j < linux_vec.size(); j++) {
		if (linux_vec[j] == across_words_rough[i]) {
			good_words.push_back(hor_coordinates[i] + "ACROSS " + across_words_rough[i]);
			across_words.push_back(across_words_rough[i]);
			a_found = true;

			break;
		}
	}
	//if word not in linux dictionary, send it to bad_words
	if (!a_found) {
		bad_words.push_back(across_words_rough[i]);
	}
}

//same operation, but for DOWN words
//check every word with linux dictionary, keep track of whether or not it is found
std::vector <string> down_words;
bool d_found;
for (int i = 0; i < down_words_rough.size(); i++) {
	d_found = false;
	for (int j = 0; j < linux_vec.size(); j++) {
		//if word is in linux dictionary, send to good_words and down_words along with information regarding word
		if (linux_vec[j] == down_words_rough[i]) {
			good_words.push_back(vert_coordinates[i] + "DOWN " + down_words_rough[i]);
			down_words.push_back(down_words_rough[i]);
			d_found = true;
		}
	}
	
	if (!d_found) {
		bad_words.push_back(down_words_rough[i]);
	}
}



std::sort(bad_words.begin(), bad_words.end());




if (bad_words.size() != 0){
	for (int i = 0; i < good_words.size(); i++) {
		std::cout << "'" << good_words[i] << "' is a word" << std::endl;
	}

	for (int i = 0; i < bad_words.size(); i++) {
		std::cout << "'" << bad_words[i] << "' is not a word" << std::endl;
	}
}
if (bad_words.size() == 0 and argc < 4) {
	std::cout << "valid crossword puzzle" << std::endl;
}

if (argc == 4) {
	//std::cout << "4 arguments" << std::endl;
	if (strcmp(argv[3], "--print") == 0) {
		// row 1
		std::cout << "+----+";
		for (int i = 0; i < column_num-1; i++) {
			std::cout << "----+";
		}
		std::vector<int> hash_indices;
		for (int i = 0; i < column_num; i++) {
			if (row_vec[0][i] == '#') {
				hash_indices.push_back(i);
			}
		}
		std::cout << std::endl;
		for (int i = 0; i < 2; i++) {
			std::cout << "|";
			for (int j = 0; j < column_num; j++) {
				bool pound_found = false;
				for (int k = 0; k < hash_indices.size(); k++) {
					if (hash_indices[k] == j) {
						pound_found = true;
					}
				}
				if (pound_found == true) {
					std::cout << "####|";
				}
				else {
					std::cout << "    |";
				}
			}
		std::cout << std::endl;
		}
	std::cout << "+----+";
	for (int i = 0; i < column_num-1; i++) {
		std::cout << "----+";
	}
	std::cout << std::endl;
	//following rows
	for (int i = 1; i < row_num; i++) {
		std::vector<int> hash_indices;
		for (int j = 0; j < column_num; j++) {
			if (row_vec[i][j] == '#') {
				hash_indices.push_back(j);
			}
		}
		for (int i = 0; i < 2; i++) {
			std::cout << "|";
			for (int j = 0; j < column_num; j++) {
				bool pound_found = false;
				for (int k = 0; k < hash_indices.size(); k++) {
					if (hash_indices[k] == j) {
						pound_found = true;
					}
				}
				if (pound_found == true) {
					std::cout << "####|";
				}
				else {
					std::cout << "    |";
				}
			}
		std::cout << std::endl;
		}
	std::cout << "+----+";
	for (int i = 0; i < column_num-1; i++) {
		std::cout << "----+";
	}
	std::cout << std::endl;

//	}
	}
	return 0;
	}

	else if (strcmp(argv[3], "--print_coordinates") == 0) {
		//std::cout << "yes" << std::endl;
		// row 1
		//std::cout << "print coordinates" << std::endl;
		std::cout << "+----+";
		for (int i = 0; i < column_num-1; i++) {
			std::cout << "----+";
		}
		std::vector<int> hash_indices;
		for (int i = 0; i < column_num; i++) {
			if (row_vec[0][i] == '#') {
				//std::cout << "hash at row 1 column " << i << std::endl;
				hash_indices.push_back(i);
			}
		}
		std::cout << std::endl;
		for (int i = 0; i < 2; i++) {
			std::cout << "|";
			for (int j = 0; j < column_num; j++) {
				bool pound_found = false;
				for (int k = 0; k < hash_indices.size(); k++) {
					if (hash_indices[k] == j) {
						pound_found = true;
					}
				}
				if (pound_found == true) {
					std::cout << "####|";
				}
				else {
					std::cout << "    |";
				}
			}
		std::cout << std::endl;
		}
	std::cout << "+----+";
	for (int i = 0; i < column_num-1; i++) {
		std::cout << "----+";
	}
	std::cout << std::endl;
	//following rows
	for (int i = 1; i < row_num; i++) {
		std::vector<int> hash_indices;
		for (int j = 0; j < column_num; j++) {
			if (row_vec[i][j] == '#') {
				//std::cout << "hash at row 1 column " << i << std::endl;
				hash_indices.push_back(j);
			}
		}
		for (int i = 0; i < 2; i++) {
			std::cout << "|";
			for (int j = 0; j < column_num; j++) {
				bool pound_found = false;
				for (int k = 0; k < hash_indices.size(); k++) {
					if (hash_indices[k] == j) {
						pound_found = true;
					}
				}
				if (pound_found == true) {
					std::cout << "####|";
				}
				else {
					std::cout << "    |";
				}
			}
		std::cout << std::endl;
		}
	std::cout << "+----+";
	for (int i = 0; i < column_num-1; i++) {
		std::cout << "----+";
	}
	std::cout << std::endl;
	}
	}
	
	std::cout << "" << std::endl;
	sort(good_words.begin(), good_words.end());
	for (int i = 0; i < good_words.size(); i++) {
	cout << good_words[i] << endl;
}


	/*std::cout << "" << std::endl;
	for (int i = 0; i < down_words.size(); i++) {
		std::cout << "DOWN " << down_words[i] << std::endl;
	}

	for (int i = 0; i < across_words.size(); i++) {
		std::cout << "ACROSS " << across_words[i] <<  std::endl;
	}*/

	/*for (int i = 0; i < across_words.size(); i++) {
		bool word_found = true;
		int row_coordinate = 0;
		for (int l = 0; l < across_words[i].size(); l++) {
			bool letter_found = false;
			for (int k = 0; k < row_vec.size(); k++) {
				for (int m = 0; m < row_vec[k].size(); m++) {
					if (row_vec[k][m] == across_words[i][l]) {
						letter_found = true;
						//std::cout << "found word " << across_words[i] << " in row " << k << std::endl;
						row_coordinate = k;
					}
				}
			}
		if (letter_found != true) {
			word_found = false;
		}*/
	//std::cout << across_words[i] << std::endl;
	/*if (word_found == true) {
		std::cout << "found word " << across_words[i] << " in row " << row_coordinate << std::endl;
	}
	else {
		std::cout << "couldn't find word " << across_words[i] << std::endl;
	}*/
	//}

}




//vertical words

//ignore all hash symbols
/*CASES FOR STARTING LETTER:
	HORIZONTAL (GOING TO THE RIGHT):
		-no character is to the left of character x
		-hash symbol is to the left of character x

	VERTICAL (GOING DOWN):
		-no character is above character x
		-hash symbol is above character x
*/

//if letter is a starting letter, check word going down, 
//	and word going to the right with linux_words vector

return 0;

}