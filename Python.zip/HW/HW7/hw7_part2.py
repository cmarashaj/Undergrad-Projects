''' 
Author: Caila Marashaj

This program takes in a list of IMDB and twitter ratings of movies, 
with corresponding id numbers as dictionary indices. It then 
asks the user for a range of years and a desired genre, and
prints the calculated best and worst movies according to these
parameters. 

'''

import json


if __name__ == "__main__":
    #read JSON data
    movies = json.loads(open("movies.json").read())
    ratings = json.loads(open("ratings.json").read())
    #movies comes from IMDB
    #ratings comes from twitter
    
    #get input
    min_year = input('Min year => ').strip()
    print(min_year)
    min_year = int(min_year)
    max_year = input('Max year => ').strip()
    print(max_year)
    max_year = int(max_year)
    imdb_weight = input('Weight for IMDB => ').strip()
    print(imdb_weight)
    imdb_weight = float(imdb_weight)
    twitter_weight = input('Weight for Twitter => ').strip()
    print(twitter_weight)
    twitter_weight = float(twitter_weight)
    
    #find all movies btwn given years and which are rated on twitter
    movie_scores = dict()
    genres = set()
    #go through IMDB dictionary
    for movie_id in movies.keys():
        for element in movies[movie_id]['genre']:
            #create a set of all genres for comparison
            genres.add(element.lower())
        #if it has less than 3 twitter ratings, move on
        if movie_id not in ratings or len(ratings[movie_id]) < 3:
            continue
        #if it is outside the given time range, move on
        year = movies[movie_id]['movie_year']
        if year < min_year or year > max_year: continue
        #get avg twitter rating
        twitter_rating = sum(ratings[movie_id])/len(ratings[movie_id])
        #get imdb rating
        imdb_rating = float(movies[movie_id]['rating'])
        #combined rating, as given
        combined_rating = (imdb_weight * imdb_rating + twitter_weight * twitter_rating) \
            / (imdb_weight + twitter_weight)
        #add to dictionary
        movie_scores[movie_id] = combined_rating
        
    exit = False
    #keep looping until user gives stop as input
    while exit == False:
        print()
        #get genre
        desired_genre = input('What genre do you want to see? ').strip()
        print(desired_genre.strip('\n'))
        desired_genre = desired_genre.lower()
        #stop condition
        if desired_genre == 'stop': 
            exit = True
            break
        print()
        #formatting, since capitalize() doesn't work for 'Sci-Fi'
        if desired_genre == 'sci-fi': 
            format_genre = 'Sci-Fi'
        else: format_genre = desired_genre.capitalize()
        #if there are no movies of given genre within time range
        if desired_genre not in genres:
            print("No {0} movie found in {1} through {2}".format(format_genre, min_year,max_year))
        else:
            #get
            selected = []
            #create list of tuples using movies within the year range
            for movie_id in movie_scores.keys():
                movie_genre = []
                #get movies with desired genre
                for genre in movies[movie_id]['genre']:
                    movie_genre.append(genre.lower())
                if desired_genre in movie_genre:
                    selected.append((movie_scores[movie_id],movie_id))
            if len(selected) == 0:
                print("No {0} movie found in {1} through {2}".format(format_genre,min_year,max_year))
                continue
            #sort according to rating
            selected.sort()
            best = selected[-1]
            worst = selected[0]
            #output
            print("Best:\n"+' '*8+'Released in {0}, {1} has a rating of {2:.2f}'.format(movies[best[1]]['movie_year'],movies[best[1]]['name'],movie_scores[best[1]]),end='\n\n')
            print("Worst:\n"+' '*8+'Released in {0}, {1} has a rating of {2:.2f}'.format(movies[worst[1]]['movie_year'],movies[worst[1]]['name'],movie_scores[worst[1]]))
