''' 
Author: Caila Marashaj

This program determines the overall sentiment of a 
given sentence using 6 keywords for happy and sad each, and 
outputs data about the calculated sentiment
'''

def number_happy(sentence):
    #account for capitalization
    sentence = sentence.lower()
    #count the occurences of each word
    laugh = sentence.count('laugh')
    happiness = sentence.count('happiness')
    love = sentence.count('love')
    excellent = sentence.count('excellent')
    good = sentence.count('good')
    smile = sentence.count('smile')
    #return the total
    return laugh + happiness + love + excellent + good + smile

def number_sad(sentence):
    #account for capitalization
    sentence = sentence.lower()
    #count occurences of each word
    bad = sentence.count('bad')
    sad = sentence.count('sad')
    terrible = sentence.count('terrible')
    horrible = sentence.count('horrible')
    problem = sentence.count('problem')
    hate = sentence.count('hate')
    #return the total
    return bad + sad + terrible + horrible + problem + hate

#take input sentence
sentence = input("Enter a sentence => ")
print(sentence)

#output
print("Sentiment: {}{}".format('+'*number_happy(sentence),'-'*number_sad(sentence)))
if number_happy(sentence) > number_sad(sentence): print("This is a happy sentence.")
elif number_happy(sentence) < number_sad(sentence): print("This is a sad sentence.")
elif number_happy(sentence) == number_sad(sentence): print("This is a neutral sentence.")