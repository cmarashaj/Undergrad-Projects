/* Code for Electronic Compass in Lab 3-3 */
#include <stdio.h>
#include <c8051_SDCC.h>
#include <i2c.h>
//-----------------------------------------------------------------------------
// Funciton Prototypes
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void SMB_Init(void);
unsigned int Read_Compass();
void Steering_Servo();
void Change_Heading();
//-----------------------------------------------------------------------------
// sbit Variables
//-----------------------------------------------------------------------------
__sbit __at 0xB7 SS;
//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
unsigned int h_count = 0;
unsigned int new_heading = 1;
unsigned int heading;
unsigned char Data[2];
unsigned char addr;
unsigned int PW_CENTER = 276;
unsigned int PW_LEFT = 1700;
unsigned int PW_RIGHT = 3800;
unsigned int SERVO_PW;
unsigned char input; 
signed int error;
signed int k;
unsigned int gain;
unsigned int desired_heading = 900; //according to lab manual can be changed
//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init();
	SMB_Init();

	//Center car wheels
	SERVO_PW = PW_CENTER;

	//print beginning message
	printf("\r\nEmbedded Control Electronic Compass\r\n");
	printf("\r\nMove the Slide Switch to Begin\r\n");

	while(1)
	{
		if(new_heading && !SS)
		{
			heading = Read_Compass();
			new_heading = 0;
			Change_Heading();
			Steering_Servo();
			printf("\r\nHeading: %d\r\n",heading);
		}
		else if (SS)
		{
			SERVO_PW = PW_CENTER;
			PCA0CPL0 = (0xFFFF - SERVO_PW);
			PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;
		}
	}
}
//-----------------------------------------------------------------------------
// Functions to read compass heading and adjust car
//-----------------------------------------------------------------------------
unsigned int Read_Compass()
{
	addr=0xC0; // the address of the compass
	i2c_read_data(addr, 0x02, Data, 2); // read two bytes, starting at reg 2
	heading = (((unsigned int)Data[0] << 8) | Data[1]);
	return heading; //return heading in tenths a degree from 0 - 3599
}

void Steering_Servo()
{
	//wait for a key to be pressed
	printf("\r\n Enter 'r' to steer right or 'l' to steer left\r\n");
	input = getchar();
	if(input == 'r') //if 'r' is pressed by the user
	{
		if(SERVO_PW < PW_RIGHT)
			SERVO_PW = SERVO_PW + 10; //increase the steering pulsewidth by 10
	}
	else if(input == 'l') //if 'l' is pressed by the user
	{
		if(SERVO_PW > PW_LEFT)
			SERVO_PW = SERVO_PW - 10; //decrease the steering pulsewidth by 10
	}
	printf("\r\nSERVO_PW: %u\r\n", SERVO_PW);
	PCA0CPL0 = 0xFFFF - SERVO_PW;
	PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;
}

void Change_Heading()
{
	error = desired_heading - heading;
	k = (PW_RIGHT - PW_CENTER)/(SERVO_PW - desired_heading);
	//gain function

	if(error > 1800)
	{
		error = error - 3600;
	}
	else if(error < -1800)
	{
		error = error + 3600;
	}
	else
	{
		error = error;
	}
	SERVO_PW = k*error + PW_CENTER;
	PCA0CPL0 = (0xFFFF - SERVO_PW);
	PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init(void)
{
	P1MDOUT |= 0X27;//set output pin for CEX2 in push-pull mode
	P3MDOUT &= 0x7F; //sets input for slide switch
	P3 |= ~0x7F;
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
void Interrupt_Init(void)
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
	
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init(void)
{
	XBR0 = 0x27;		//configure crossbar with UART, SPI, SMBus, and CCMs
}
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM2 = 0xC2; // CCM2. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR (void) __interrupt 9
{
	//see lab instructions online to ocunt
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672;
		h_count++;
		if(h_count>=3) //recommended to wait 3 overflows instead of 2
		{
			new_heading = 1; 
			h_count = 0;
			//printf("\r\nCounting\r\n");
		}
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
//-----------------------------------------------------------------------------
// SMBus Initialization
//-----------------------------------------------------------------------------
void SMB_Init(void)
{
	SMB0CR = 0X93; //set SCL to 100kHz
	ENSMB = 1; //enable the SMBus
}