
'''
This program finds the optimal amount of gumballs to stock in a machine, as well as other information

author: alex david
date: 29 sep 2018
'''

from math import pi,ceil

def find_volume_sphere(r):
    v = (4/3)*pi*r**3
    return v

def find_volume_cube(s):
    v = s**3
    return v

gumball_r = (input("Enter the gum ball radius (in.) => "))
print(gumball_r)
gumball_r = float(gumball_r)
sales = int(input("Enter the weekly sales => "))
print(sales)
print("")

gumball_d = gumball_r * 2 #diameter of gumballs
stock_gumball = ceil(1.25 * float(sales)) #how many gumballs are in the machine
side = (stock_gumball)**(1/3)
gumball_edge = ceil(side) #finds how many gumballs make up each side of the machine

target_gumballs = ceil(find_volume_cube(side)) #finds how many gumballs are in the machine
gumball_v = find_volume_sphere(gumball_r) #volume of each gumball
edge_length = gumball_d * gumball_edge #finds the length of the machine's sides
machine_v = find_volume_cube(edge_length) #total volume of the machine
total_gumballs = gumball_edge ** 3 #finds total gumballs that could fit in the machine

extra_space = machine_v - (target_gumballs * gumball_v) #finds how much unused space is in the machine
gumball_extra = total_gumballs - target_gumballs #how many more gumballs can fit in the machine
extra_filled = extra_space - (gumball_extra * gumball_v) #how much space can be used if gumballs are filled

#prints all necessary outputs
print("The machine needs to hold", gumball_edge, "gum balls along each edge.")
print("Total edge length is {0:.2f} inches.".format(edge_length))
print("Target sales were ", target_gumballs, ", but the machine will hold ", gumball_extra, " extra gum balls.", sep = "")
print("Wasted space is {0:.2f} cubic inches with the target number of gum balls,\nor {1:.2f} cubic inches if you fill up the machine.".format(extra_space, extra_filled))
