/*  Names: Niyanthri, Megan, Caila 
    Section: 1
    Date: 06/04/2019
    File name: Lab 2
    Description:
*/
/*
  This program runs all three modes for Lab 2
*/

#include <c8051_SDCC.h>// include files. This file is available online
#include <stdio.h>
#include <stdlib.h>

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------
void Port_Init(void);
void Interrupt_Init(void);
void Timer_Init(void);
void ADC_Init(void);
void Timer0_ISR(void) __interrupt 1;
unsigned char read_AD_input(unsigned char pin_number);



//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
__sbit __at 0xA6 LED2;
__sbit __at 0xA7 LED3;
__sbit __at 0xA4 LED0;
__sbit __at 0xA5 LED1;
__sbit __at 0xA2 BILED1;
__sbit __at 0xA3 BILED0;
__sbit __at 0xB2 PB0;
__sbit __at 0xB3 PB1;
__sbit __at 0xB4 PB2;
__sbit __at 0xB5 PB3;
__sbit __at 0xB6 SS0;
__sbit __at 0xB7 SS1;

unsigned int counts;



//***************
void main(void)
{
    Sys_Init();      // System Initialization
    Port_Init();      
    Interrupt_Init();
    Timer_Init();    
    ADC_Init();
    putchar(' ');    
    
/* 
this code turns on the LED corresponding to the activated pushbutton and prints messages displaying which push buttons, slide switches, LEDs, and BILEDs are activated
-if PB 0 and 1 are pushed, BILED lights up red
-if PB 2 and 3 are pushed, BILED lights up green

*/


    while (1) //start infinite while loop
    {
		printf("enter key to read inputs\r\n");
		input = getchar();

		// add code necessary to complete the homework
		AD_value = read_AD_input(5);	//read AD value on P1.5
		voltage = ((AD_value*2.4) / 255);
		
		//turn of LEDs and BILED
		LED0 = 1;
		LED1 = 1;
		LED2 = 1;
		LED3 = 1;
		BILED0 = 1;
		BILED1 = 1;

		if (!PB0 && PB1 && PB2 && PB3) { 
			printf("Push Button 0 is pushed\r\n"); 
			LED0 = 0;
			LED1 = 1;
			LED2 = 1;
			LED3 = 1;
		} LED0 = 1;
		
		if (!PB1 && PB0 && PB2 && PB3) { 
			printf("Push Button 1 is pushed\r\n");
			LED0 = 1;
			LED1 = 0;
			LED2 = 1;
			LED3 = 1; 
		} LED1 = 1;
		if (!PB2 && PB0 && PB1 && PB3) { 
			printf("Push Button 2 is pushed\r\n");
		 	LED0 = 1;
			LED1 = 1;
			LED2 = 0;
			LED3 = 1;
		} LED2 = 1;
		if (!PB3 && PB0 && PB1 && PB2) { 
			printf("Push Button 3 is pushed\r\n"); 
			LED0 = 1;
			LED1 = 1;
			LED2 = 1;
			LED3 = 0;
		} LED3 = 1;
		
		if (!SS0) { printf("Slide Switch 0 is activated\r\n"); }
		if (!SS1) { printf("Slide Switch 1 is activated\r\n"); }

		if (!PB0 && !PB1 && PB2 && PB3) {
			printf("Push Buttons 0 and 1 activated, BILED1(red) is activated\r\n");
			BILED1 = 0;
			BILED0 = 1;
		} BILED1 = 1;

		if (PB0 && PB1 && !PB2 && !PB3) {
			printf("Push Buttons 2 and 3 activated, BILED0(green) is activated\r\n");
			BILED1 = 1;
			BILED0 = 0;
		} BILED0 = 1;



		printf("AD value = %d\r\n", AD_value);	// print statement as required by homework
		printf("Potentiometer voltage = %d\r\n", voltage);	// print statement as required by homework
        
    }
}

//***************
void Port_Init(void)
{
	P1MDOUT |= 0xFD;
	P1MDIN &= 0xFD;
	P1 |= 0x02;
	P2MDOUT |= 0xFC;
	P3MDOUT &= ~0xFC;
	P3 |= 0xFC;
}

void Interrupt_Init(void)
{
    IE |= 0x82;      // enable Timer0 Interrupt request (by masking)
    EA = 1;       // enable global interrupts (by sbit)
}
//***************
void Timer_Init(void)
{

    CKCON |= 0x08;  // Timer0 uses SYSCLK as source
    TMOD &= 0xF1;   // clear the 4 least significant bits
    TMOD |= 0x01;   // Timer0 in mode 1
    TR0 = 0;           // Stop Timer0
    TL0 = 0;
    TMR0 = 0;           // Clear high & low byte of T0

}

void ADC_Init(void)
{
    REF0CN = 0x03; //Vref = 2.4V
    ADC1CN = 0x80; //enable A/D coversion
    ADC1CF &= ~0x02;
    ADC1CF |= 0x01;
}


//***************
void Timer0_ISR(void) __interrupt 1
{
 	counts++;   
}

unsigned char read_AD_input(unsigned char pin_number)
{
	AMX1SL = pin_number;
	ADC1CN = ADC1CN & ~0x20; /* Clear the �Conversion Completed� flag */
 	ADC1CN = ADC1CN | 0x10; /* Initiate A/D conversion */
 	while ((ADC1CN & 0x20) == 0x00); /* Wait for conversion to complete */
	return ADC1;
}