/* Sample code for speed control using PWM. */
#include <stdio.h>
#include <c8051_SDCC.h>
#include <i2c.h>
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void SMB_Init(void);
void ADC_Init(void);
void Steering_Servo();
void Change_Heading();
void Drive_Motor(void);
void Accel_Init_C(void);
unsigned int Read_Compass(void);
unsigned int ReadRanger(void);
unsigned char read_AD(void);
unsigned char read_AD_input(unsigned char pin_number);
void read_Accel(void);
void UI(void);
void all_neutral(void);
void wait_20(void);
//-----------------------------------------------------------------------------
// sbit variables
//-----------------------------------------------------------------------------
__sbit __at 0xB6 SS1;
__sbit __at 0xB7 SS2;
__sbit __at 0xA5 BILED1;
__sbit __at 0xA7 BILED2;
//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
#define PW_MIN 2027
#define PW_MAX 3502
#define PW_NEUT 2724
unsigned int MOTOR_PW;
signed int k_dx = 1;
signed int k_dy = 1;

#define PW_CENTER 2765
#define PW_LEFT 1700
#define PW_RIGHT 3500
signed int SERVO_PW; 
signed int error;
signed int k_s;
unsigned int desired_heading;

signed int avg_gx;
signed int avg_gy;
signed int gx;
signed int gy;
signed int calibrate_x;
signed int calibrate_y;
signed int error_x;
signed int error_y;
signed int direction;
unsigned int it;
unsigned int new_accel;
unsigned int a_count;
unsigned char Data[4];

unsigned char voltage;
signed int direction;
unsigned char AD_value;
unsigned int input;
unsigned int count;

//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init();
	SMB_Init();
	ADC_Init();
	Accel_Init_C();
	//print beginning message
	MOTOR_PW = PW_NEUT;
	PCA0CPL2 = 0xFFFF - MOTOR_PW;
	PCA0CPH2 = (0xFFFF - MOTOR_PW) >> 8;
	printf("\r\nSee LCD Display\r\n");
	
	read_Accel();
	calibrate_x = (signed int)gx;
	calibrate_y = (signed int)gy;
	read_Accel();
	calibrate_x += (signed int)gx;
	calibrate_y += (signed int)gy;
	calibrate_x /= 2;
	calibrate_y /= 2;
	
	printf("Calibration x:%d y:%d\r\n",calibrate_x,calibrate_y);
	while(1)
	{
		UI();
		voltage = read_AD();
		while(SS2);
		if(!SS2) //run
		{
			if(new_accel)
			{
				read_Accel();
			}
			if(!SS1) //forward
			{
				direction = 1;
				//printf("Forward/Reverse switch on");
				if(gx > 0)
				{
					SERVO_PW = PW_RIGHT;
				}
				else if (gx < 0)
				{
					SERVO_PW = PW_LEFT;
				}

			}
			else if(SS1)
			{
				direction = -1;
				if(gx > 0)
				{
					SERVO_PW = PW_LEFT;
				}
				else if (gx < 0)
				{
					SERVO_PW = PW_RIGHT;
				}
			}
			PCA0CPL0 = (0xFFFF - SERVO_PW);
			PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;

		}
		while(!SS2)
		{
			if(new_accel)
			{
				read_Accel();
				Drive_Motor();
				Change_Heading();
				printf("gx:%d gy:%d avg_gx:%d avg_gy:%d\r\n",gx,gy,avg_gx,avg_gy);
				new_accel = 0;
				printf("Error x:%d Error y:%d\r\n",error_x,error_y);
				if((abs(error_x) < 20) & (abs(error_y) < 20))
				{
					BILED1 = 0;
					BILED2 = 1;
					break;
				}
				else
				{
					BILED1 = 1;
					BILED2 = 0;
				}

			}
			
		}
		all_neutral();
	}
}

void all_neutral(void)
{
	SERVO_PW = PW_CENTER;
	PCA0CPL0 = (0xFFFF - SERVO_PW);
	PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;

	//Neutral speed
	MOTOR_PW = PW_NEUT;
	PCA0CPL2 = 0xFFFF - MOTOR_PW;
	PCA0CPH2 = (0xFFFF - MOTOR_PW) >> 8;

}
//-----------------------------------------------------------------------------
// Accelerometer
//-----------------------------------------------------------------------------
void read_Accel(void)
{
	wait_20();	
	avg_gx = 0;
	avg_gy = 0;
	it = 0;
	while (it < 16) 
	{
		if (new_accel)
		{
			new_accel = 0;
		`	do
			{
				it++;
				i2c_read_data(0x3A,0x27,Data,1); //read status_reg_a into 0x27
			}while((Data[0] & 0x03) != 0x03) ;

		
			//read 4 registers
			i2c_read_data(0x3A, 0x28|0x80, Data, 4);
			//discard low byte and extend hi byte for 16-bit acc.
			avg_gx += ((Data[1] << 8) >> 4);
			avg_gy += ((Data[3] << 8) >> 4);
			//printf("Data[1] = %u Data[3] = %u \r\n",Data[0],Data[2]);
		}
	}
	avg_gx = avg_gx/16;
	avg_gy = avg_gy/16;

	gx = avg_gx;
	gy = avg_gy;
	printf("gx:%d gy:%d \r\n",gx,gy);
}

void wait_20(void)
{
	count = 0;
	while(count < 1);
}
//-----------------------------------------------------------------------------
// Drive_Motor
//-----------------------------------------------------------------------------
void Drive_Motor()
{
	error_x = calibrate_x - gx;
	error_y = calibrate_y - gy;
	MOTOR_PW = PW_NEUT + (k_dy*error_y*direction);
	//MOTOR_PW = PW_NEUT + (k_dy * gy) ;
	MOTOR_PW += direction*k_dx * abs(error_x);
	if (MOTOR_PW > PW_MAX)
	{
		MOTOR_PW = PW_MAX;
	}
	else if(MOTOR_PW < PW_MIN)
	{
		MOTOR_PW = PW_MIN;
	}
	printf("Motor Pulsewidth:%u", MOTOR_PW);
	PCA0CPL2 = 0xFFFF - MOTOR_PW;
	PCA0CPH2 = (0xFFFF - MOTOR_PW) >> 8;
}
//-----------------------------------------------------------------------------
// Function to change heading
//-----------------------------------------------------------------------------
void Change_Heading()
{
	error_x = calibrate_x - gx;
	SERVO_PW = PW_CENTER - (direction*k_s * error_x) ;
	if (SERVO_PW > PW_RIGHT)
	{
		SERVO_PW = PW_RIGHT;
	}
	else if(SERVO_PW < PW_LEFT)
	{
		SERVO_PW = PW_LEFT;
	}
	printf("\r\n Steering Pulse Width: %u\r\n",SERVO_PW);
	PCA0CPL0 = (0xFFFF - SERVO_PW);
	PCA0CPH0 = (0xFFFF - SERVO_PW) >> 8;
}

//-----------------------------------------------------------------------------
// Reads AD value from potentiometer
//-----------------------------------------------------------------------------
unsigned char read_AD(void)
{	
	AD_value = read_AD_input(4);
	//value = AD_value*71.25;
	printf("\r\n AD Value: %u\r\n",AD_value);
	return AD_value;
}
//-----------------------------------------------------------------------------
// Reads AD value from potentiometer
//-----------------------------------------------------------------------------
unsigned char read_AD_input(unsigned char pin_number)
{
	AMX1SL = pin_number;
	ADC1CN = ADC1CN & ~0x20; /* Clear the �Conversion Completed� flag */
 	ADC1CN = ADC1CN | 0x10; /* Initiate A/D conversion */
 	while ((ADC1CN & 0x20) == 0x00); /* Wait for conversion to complete */
	return ADC1;
}

//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P1MDIN &= 0XEF;
	P1MDOUT &= 0XEF;
	P1MDOUT |= 0X05 ;//set output pin for CEX0,CEX2 in push-pull mode
	P1 |= ~0XEF;
	P3MDOUT &= 0x3F;
	P3 |= 0x3F;
	P2MDOUT |= 0XA0;
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
	
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init()
{
	XBR0 = 0x1F;		//configure crossbar with UART, SPI, SMBus, and CEX channels as
						// in worksheet
}
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 - Pulse Width Modulation implemented using the PCA (Programmable Counter Array, p. 50 in Lab Manual.
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM0 = 0xC2;
	PCA0CPM2 = 0xC2; // CCM2. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR ( void ) __interrupt 9
{
	//see lab instructions online to ocunt
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672;
		a_count++;
		count++;
		if(a_count>=1) //recommended to wait 1 overflow
		{
			new_accel = 1; 
			a_count = 0;
		}
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
//-----------------------------------------------------------------------------
// SMBus Initialization
//-----------------------------------------------------------------------------
void SMB_Init(void)
{
	SMB0CR = 0X93; //set SCL to 100kHz*/
	ENSMB = 1; //bit 6 of SMB0CN, enable the SMBus
}
//-----------------------------------------------------------------------------
// ADC Initialization
//-----------------------------------------------------------------------------
void ADC_Init(void)
{
    REF0CN = 0x03; //Vref = 2.4V
    ADC1CN = 0x80; //enable A/D coversion
    ADC1CF |= 0x01;

}
//-----------------------------------------------------------------------------
// User Interface on LCD
//-----------------------------------------------------------------------------
void UI()
{
	
	lcd_clear();

	lcd_print("\nk_s: \n");
	input = kpd_input(1);
	k_s = input;
	lcd_clear();

	lcd_print("\nk_dx: \n");
	input = kpd_input(1);
	k_dx = (float)input;
	lcd_clear();

	lcd_print("\nk_dy: \n");
	input = kpd_input(1);
	k_dy = (float)input;
	lcd_clear();
}