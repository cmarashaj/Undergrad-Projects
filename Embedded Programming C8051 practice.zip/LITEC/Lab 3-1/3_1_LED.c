/* Sample code for Lab 3.1. This program can be used to test the LED Pulsewidth*/
#include <c8051_SDCC.h>
#include <stdio.h>
#include <stdlib.h>
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init();
void PCA_ISR ( void ) __interrupt 9;
void Interrupt_Init(void);
void Set_Pulsewidth(void);
unsigned int PW_CENTER = 2764;
unsigned int PW_MAX = 3870;
unsigned int PW_MIN = 1658;
unsigned int PW;
unsigned char input;

//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	putchar(' '); //the quotes in this line may not format correctly
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init();
	//print beginning message
	printf("Embedded Control LED Calibration\n");
	//set initial value for steering (set to center)
	PW = PW_CENTER;
	printf("\r\nUse '+' or '-' to change the LED pulsewidth");

	

	while(1)
	{
		input = getchar();
		printf("input = %u before \r\n",input);
		Set_Pulsewidth();
		
	}
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P1MDOUT |= 0X08 ;//set output pin for LED in push-pull mode
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//


void XBR0_Init()
{
	XBR0 = 0X27; //configure crossbar with UART, SPI, SMBus, and CEX channels as	
						// in worksheet
}

//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 -Pulse Width Modulation implemented using
	//the PCA (Programmable Counter Array), p. 50 in Lab Manual.
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM3 = 0xC2; // CCM0. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR (void) __interrupt 9
{
	// reference to the sample code in Example 4.5 -Pulse Width Modulation implemented using
	//the PCA (Programmable Counter Array), p. 50 in Lab Manual.
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672; 
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
void Set_Pulsewidth(void)
{
    //char input;
    //wait for a key to be pressed
    //input = getchar();
	printf("input = %u value \r\n",input);
    if(input == '+')  // single character input to increase the pulsewidth
    {
		PW += 200;
		if(PW > PW_MAX) {  // check if greater than pulsewidth maximum
        	PW = PW_MAX; }   // set PW to the maximum value
    }
    else if(input == '-')  // single character input to decrease the pulsewidth
    {
		PW -= 200;
        if(PW > PW_MIN) { // check if less than pulsewidth minimum
        	PW = PW_MIN; }    // set PW to the minimum value
    }
    printf("\r\nPW: %u\r\n", PW);
    PCA0CPL3 = 0xFFFF - PW;
	PCA0CPH3 = (0xFFFF - PW) >> 8;
}