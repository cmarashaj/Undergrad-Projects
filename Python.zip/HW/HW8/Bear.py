class Bear(object):
    #initializer
    def __init__(self,stats,status_,berries_eaten_=0):
        self.x = stats[0]
        self.y = stats[1]
        self.direction = stats[2]
        self.status = status_
        self.sleeping = 0
        self.berries_eaten = berries_eaten_
        self.inside = True
        
    #print formatting
    def __str__(self):
        output = "Bear at ({0},{1}) moving {2}".format(self.x,self.y,self.direction)
        #only print sleep status if bear is asleep
        if self.sleeping > 0: output += ' - Asleep for {} more turns'.format(self.sleeping)
        return output
    #for sorting list 
    def __lt__(self,other):
        if self.x < other.x: return True
        elif self.x == other.x and self.y < other.y: return True
        else: return False
    #bear kills a person
    def maul(self): self.sleeping = 3
    #bear eats berries
    def eat(self,num_berries): 
        self.berries_eaten += num_berries
    
    def next_(self): #returns where the bear would go
        output = [self.x,self.y]
        if self.direction == 'N': output[0] = self.x-1
        elif self.direction == 'S': output[0] = self.x+1
        elif self.direction == 'E': output[1] = self.y+1
        elif self.direction == 'W': output[1] = self.y-1
        elif self.direction == 'NE':
            output[0] = self.x-1
            output[1] = self.y+1
        elif self.direction == 'NW':
            output[0] = self.x-1
            output[1] = self.y-1
        elif self.direction == 'SE':
            output[0] = self.x+1
            output[1] = self.y+1
        elif self.direction == 'SW': 
            output[0] = self.x+1
            output[1] = self.y-1 
        return output
    def move(self): #move bear based on direction, update grid
        if self.direction == 'N': self.x-=1
        elif self.direction == 'S': self.x+=1
        elif self.direction == 'E': self.y+=1
        elif self.direction == 'W': self.y-=1
        elif self.direction == 'NE':
            self.x-=1
            self.y+=1
        elif self.direction == 'NW':
            self.x-=1
            self.y-=1
        elif self.direction == 'SE':
            self.x+=1
            self.y+=1
        elif self.direction == 'SW': 
            self.x+=1
            self.y-=1
    