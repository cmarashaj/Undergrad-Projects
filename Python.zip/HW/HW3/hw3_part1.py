"""
Author: Caila Marashaj

This program analyzes an input sentence and prints statistics and readability data about it
"""

import syllables as s

text = input("Enter a paragraph => ")
print(text)

"""  
Hard words:
words of three or more syllables that do not contain a hyphen (-) and 
three-syllable words that do not end with 'es' or ed.
"""
#get a list of words instead of one long string
text = text.split(' ')
hard_words = []
sentence_lengths = []
total_syl = 0
length = 0
for word in text:
    #get rid of escape commands
    word = word.strip('\r')
    word = word.strip('\t')
    word = word.strip('\n')
    length += 1
    #keep track of total syllables
    total_syl += s.find_num_syllables(word)
    if word[-1] == '.': #detecting the end of a sentence
        sentence_lengths.append(length)
        length = 0
    #find hard words
    if s.find_num_syllables(word) >= 3 and word.split('-')[0] == word:
        if (word[-2:] != 'es') and (word[-2:] != 'ed'):
            hard_words.append(word)
         
#calculate statistics   
asl = sum(sentence_lengths)/len(sentence_lengths)
phw = len(hard_words) / len(text) * 100
asyl = total_syl / len(text)
gfri = 0.4*(asl + phw)
fkri = 206.835-1.015*asl-86.4*asyl

#output
print("Here are the hard words in this paragraph:")
print(hard_words)
print("Statistics: ASL:{0:.2f} PHW:{1:.2f}% ASYL:{2:.2f}".format(asl,phw,asyl))
print("Readability index (GFRI): {0:.2f}".format(gfri))
print("Readability index (FKRI): {0:.2f}".format(fkri))