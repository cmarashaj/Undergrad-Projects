#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>

//this class keeps track of the statistics for each team within a 
// given football game
class Football_Game {
public:
	Football_Game(std::vector <std::string>& date_vec, 
		std::string team1_str, std::vector <int>& team1scores_vec, 
		std::string team2_str, std::vector <int>& team2scores_vec);


	//ACCESSORS
	std::string getWKDay() const; 
	std::string getMonth() const;
	std::string getDateNum() const;
	std::string getYear() const;
	std::string getTeam1() const;
	std::string getTeam2() const;

	
	//member functions
	std::string winning_team() const;
	std::string losing_team() const;
	int differential() const;
	int TotalPoints() const;
	int Team1Final() const;
	int Team2Final() const;

private:
	std::vector <std::string> date;
	std::string team1;
	std::vector<int> team1_scores;
	std::string team2;
	std::vector<int> team2_scores;
};