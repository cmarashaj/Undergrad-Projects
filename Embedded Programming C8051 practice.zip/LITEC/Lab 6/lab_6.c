/* Sample code for speed control using PWM. */
#include <stdio.h>
#include <c8051_SDCC.h>
#include <i2c.h>
#include <stdbool.h>
//-----------------------------------------------------------------------------
// 8051 Initialization Functions
//-----------------------------------------------------------------------------
void Port_Init(void);
void PCA_Init (void);
void XBR0_Init(void);
void Interrupt_Init(void);
void SMB_Init(void);
void ADC_Init(void);
void Set_Angle();
//void Drive_Motor_Rudder(void);
void Drive_Motor(void);
void Rudder_Neutral(void);
void Side_Neutral(void);
void wait_20s(void);
void wait_1s(void);
unsigned int Read_Compass(void);
unsigned int ReadRanger(void);
unsigned char read_AD(void);
unsigned char read_AD_input(unsigned char pin_number);
void UI(void);

//-----------------------------------------------------------------------------
// sbit variables
//-----------------------------------------------------------------------------
__sbit __at 0xB7 SS;
//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------
#define PW_MIN 2027
#define PW_MAX 3502
#define PW_NEUT 2724
unsigned char r_count = 0;
bool new_range = 1;
unsigned int range;

unsigned char h_count = 0;
bool new_heading = 1;
unsigned int heading;
#define PW_CENTER 2765
#define PW_LEFT 3502
#define PW_RIGHT 2028

signed int error;
signed int previous_error;
__xdata unsigned char kp;
__xdata unsigned char kd;
signed int desired_heading;

char set_angle, count;
unsigned int adj, previous_adj, angle;
unsigned int motor_pw1;
unsigned int motor_pw2;
unsigned int input;
unsigned int time_count;
long tmp_pw;
long tmp_pw2;
bool NEUT_R;
bool NEUT_S;
bool stage_2_heading;
//-----------------------------------------------------------------------------
// Main Function
//-----------------------------------------------------------------------------
void main(void)
{
	// initialize board
	Sys_Init();
	Port_Init();
	XBR0_Init();
	PCA_Init();
	Interrupt_Init();
	SMB_Init();
	ADC_Init();
	//print beginning message
	printf("\r\nSee LCD Display\r\n");

	Rudder_Neutral();
	Side_Neutral();
	wait_1s();
	
	//add code to set the servo motor in neutral for one second
	while(1)
	{
		printf("START !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\r\n");
		UI();

		//Stage 1
		
		Set_Angle();
		if(new_heading)
		{
			printf("Stage 1\r\n");
			new_heading = 0;
			NEUT_R = 0;
			NEUT_S = 0;
			Read_Compass();
			Drive_Motor();
		}
		
		time_count = 0;
		while(time_count < 1000)
		{
			if(new_heading)
			{
				new_heading = 0;
				Read_Compass();
				Drive_Motor();
			}

		}


		//Stage 2
		printf("Stage 2\r\n");
		if(SS)
		{
			desired_heading += 1200;
			stage_2_heading = 1;
			printf("Desired heading incremented \r\n");
		}

		else if(!SS)
		{
			desired_heading -= 1200;
			stage_2_heading = 0;
			printf("Desired heading decremented \r\n");
		}

		if(desired_heading < 0)
		{
			desired_heading += 3600;
		}

		while(!new_heading);

		new_heading = 0;
		NEUT_R = 1;
		NEUT_S = 0;
		Read_Compass();
		Drive_Motor();
		Rudder_Neutral();

		time_count = 0;
		while(time_count < 1000)
		{
			if(new_heading)
			{
				new_heading = 0;
				Read_Compass();
				Drive_Motor();
			}

		}


		//Stage 3
		printf("Stage 3\r\n");	

		if(stage_2_heading)
		{
			desired_heading += 1200;
			printf("Desired heading incremented \r\n");
		}

		else if(!stage_2_heading)
		{
			desired_heading -= 1200;
			printf("Desired heading decremented \r\n");
		}

		if(desired_heading < 0)
		{
			desired_heading += 3600;
		}

		while(!new_heading);
		new_heading = 0;
		NEUT_R = 0;
		NEUT_S = 1;
		Read_Compass();
		Drive_Motor();
		Side_Neutral();

		time_count = 0;
		while(time_count < 1000)
		{
			if(new_heading)
			{
				new_heading = 0;
				Read_Compass();
				Drive_Motor();
			}

		}
		Rudder_Neutral();
		Side_Neutral();
	}
}

void wait_20s(void)
{
	time_count = 0;
	while(time_count < 1000);
}
void wait_1s(void)
{
	time_count = 0;
	while(time_count < 50);
}
//Function to use ranger to adjust the thruster fan angle
//holding a fixed range value for ~5 seconds locks in the corresponding angle.
void Set_Angle(void)
{
    PCA0CP1 = 0xFFFF - 1925;                   //CEX1 is thrust fan servo

}



void Rudder_Neutral()
{
	printf("Rudder NEUTRAL\r\n");
	NEUT_R = 1;
	PCA0CPL0 = 0xFFFF - PW_CENTER;
	PCA0CPH0 = (0xFFFF - PW_CENTER) >> 8;
}
//-----------------------------------------------------------------------------
// Drive_Motor
//-----------------------------------------------------------------------------
//
// Vary the pulsewidth based on the ultrasonic range to change the speed
// of the drive motor.
//
void Drive_Motor()
{
	error = desired_heading - heading;
	//printf("Error:%d\r\n",error);
	
	//printf("Heading:%d\r\n",heading);

		
	tmp_pw = (long)kp*error+(long)kd*(error-previous_error)+PW_CENTER;
	if (tmp_pw > (long)PW_LEFT) tmp_pw = PW_LEFT;
	else if (tmp_pw < (long)PW_RIGHT) tmp_pw = PW_RIGHT;
	motor_pw1 = (unsigned int)tmp_pw;
	
	tmp_pw2 = (-(signed long)kp*error)-((signed long)kd*(error-previous_error))+PW_CENTER;
	if (tmp_pw2 > (long)PW_LEFT) tmp_pw2 = PW_LEFT;
	else if (tmp_pw2 < (long)PW_RIGHT) tmp_pw2 = PW_RIGHT;
	motor_pw2 = (unsigned int)tmp_pw2;

	
	if(!NEUT_R)
	{
		PCA0CPL0 = 0xFFFF - motor_pw1;
		PCA0CPH0 = (0xFFFF - motor_pw1) >> 8;
	}

	if(!NEUT_S)
	{
		PCA0CPL2 = 0xFFFF - motor_pw1;
		PCA0CPH2 =(0xFFFF - motor_pw1) >> 8;
		PCA0CPL3 = 0xFFFF - motor_pw2;
		PCA0CPH3 = (0xFFFF - motor_pw2) >> 8;
	}

	previous_error = error;

	//printf("Motor Pulsewidth 1:%u\r\n",motor_pw1);
	//printf("Motor Pulsewidth 2:%u\r\n",motor_pw2);

	printf("Desired Heading:%d	Heading:%d	Motor Pulsewidth 1:%u	Motor Pulsewidth 2:%u\r\n",desired_heading,heading,motor_pw1,motor_pw2);


}
void Side_Neutral()
{
	printf("SIDE NEUTRAL\r\n");
	NEUT_S = 1;
	PCA0CPL2 = PCA0CPL3 = 0xFFFF - PW_CENTER;
	PCA0CPH2 = PCA0CPH3 = (0xFFFF - PW_CENTER) >> 8;
}
//-----------------------------------------------------------------------------
// Function to Read Ranger
//-----------------------------------------------------------------------------
unsigned int ReadRanger(void)
{
	unsigned char Data[2];
    i2c_read_data(0xE0, 2, Data, 2);
    range = (Data[0] << 8) + Data[1];
    Data[0] = 0x51;
    i2c_write_data(0xE0, 0, Data, 1);   // ping for next read range
    return range; 
}
//-----------------------------------------------------------------------------
// Function to Read Compass
//-----------------------------------------------------------------------------
unsigned int Read_Compass()
{
	unsigned char Data[2];
	i2c_read_data(0xC0, 0x02, Data, 2); // read two bytes, starting at reg 2
	heading = (((unsigned int)Data[0] << 8) | Data[1]);
	//printf("\r\nHeading: %u\r\n", heading);
	return heading; //return heading in tenths a degree from 0 - 3599
}
//-----------------------------------------------------------------------------
// Function to change heading
//-----------------------------------------------------------------------------
void Change_Heading()
{
	count = 0;
    previous_adj = 0;
    set_angle = 1;

    while(set_angle)
    {
        while(!new_range);                          //new_range is global 80ms flag
		new_range = 0;
        adj = ReadRanger();
        angle = 2765 + (adj - 40)*10;               //May change: 40 nominal height
             	                                    //            10 gain on rotation
        if (angle < PW_MIN) angle = PW_MIN;
        else if (angle > PW_MAX) angle = PW_MAX;
        PCA0CP1 = 0xFFFF - angle;                   //CEX1 is thrust fan servo

        if(abs(previous_adj - adj) < 8) count++;    //Adjust depending on how noisy data is
		else count = 0;
        if(count > 62) set_angle = 0;               //Assuming ranger reads every 80ms
		previous_adj = adj;                         //
		//printf("\r Range = %u   ", adj);
    }
}
//-----------------------------------------------------------------------------
// Reads AD value from potentiometer
//-----------------------------------------------------------------------------
/*unsigned char read_AD(void)
{	
	AD_value = read_AD_input(3);
	//value = AD_value*71.25;
	printf("\r\n AD Value: %u\r\n",AD_value);
	return AD_value;
}*/
//-----------------------------------------------------------------------------
// Reads AD value from potentiometer
//-----------------------------------------------------------------------------
unsigned char read_AD_input(unsigned char pin_number)
{
	AMX1SL = pin_number;
	ADC1CN = ADC1CN & ~0x20; /* Clear the �Conversion Completed� flag */
 	ADC1CN = ADC1CN | 0x10; /* Initiate A/D conversion */
 	while ((ADC1CN & 0x20) == 0x00); /* Wait for conversion to complete */
	return ADC1;
}
//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Set up ports for input and output
//
void Port_Init()
{
	P0MDOUT &= 0X0F;
	P1MDIN &= 0XF7;
	P1MDOUT &= 0XF7;
	P1 |= ~0XF7;
	P3MDOUT &= 0X7F;
	P3 |= ~0X7F;
}
//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
void Interrupt_Init()
{
	// IE and EIE1
	EIE1 |= 0x08;    // enable PCA interrupts
    EA = 1;          // enable all interrupts
	
}
//-----------------------------------------------------------------------------
// XBR0_Init
//-----------------------------------------------------------------------------
//
// Set up the crossbar
//
void XBR0_Init()
{
	XBR0 = 0x25;		//configure crossbar with UART, SPI, SMBus, and CEX channels as
						// in worksheet
}
//-----------------------------------------------------------------------------
// PCA_Init
//-----------------------------------------------------------------------------
//
// Set up Programmable Counter Array
//
void PCA_Init(void)
{
	// reference to the sample code in Example 4.5 - Pulse Width Modulation implemented using the PCA (Programmable Counter Array, p. 50 in Lab Manual.
	// Use a 16 bit counter with SYSCLK/12
	PCA0MD = 0x81; // Enable CF interrupt & SYSCLK/12
 	PCA0CPM0 = PCA0CPM1 = PCA0CPM2 = PCA0CPM3 =0xC2;// CCM0,CCM1,CCM2 AND CCM3. in 16-bit compare mode
 	PCA0CN = 0x40; // Enable PCA counter
 	EIE1 |= 0x08; // Enable PCA interrupt
 	EA = 1; // Enable global interrupts
}
//-----------------------------------------------------------------------------
// PCA_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for Programmable Counter Array Overflow Interrupt
//
void PCA_ISR ( void ) __interrupt 9
{
	//see lab instructions online to ocunt
	if (CF)
 	{
 		CF = 0; // Clear overflow flag
 		PCA0 = 28672;
		time_count++;
		h_count++;
		r_count++;
		if(h_count>=3) //recommended to wait 3 overflows instead of 2
		{
			new_heading = 1; 
			h_count = 0;
		}
		if(r_count>=4)
		{
			new_range = 1; // 4 overflows is about 80 ms
			r_count = 0;
		}
	}
 	PCA0CN &= 0x40; // Handle other PCA interrupt sources
}
//-----------------------------------------------------------------------------
// SMBus Initialization
//-----------------------------------------------------------------------------
void SMB_Init(void)
{
	SMB0CR = 0X93; //set SCL to 100kHz*/
	ENSMB = 1; //bit 6 of SMB0CN, enable the SMBus
}
//-----------------------------------------------------------------------------
// ADC Initialization
//-----------------------------------------------------------------------------
void ADC_Init(void)
{
    REF0CN = 0x03; //Vref = 2.4V
    ADC1CN = 0x80; //enable A/D coversion
    ADC1CF |= 0x01;

}
//-----------------------------------------------------------------------------
// User Interface on LCD
//-----------------------------------------------------------------------------
void UI()
{
	lcd_clear();

	lcd_print("\nkp: \n");
	input = kpd_input(1);
	kp = input;
	lcd_clear();

	lcd_print("\nkd: \n");
	input = kpd_input(1);
	kd = input;
	lcd_clear();

	lcd_print("\nDesired direction\n");
	input = kpd_input(1);
	lcd_clear();
	desired_heading = input;
}