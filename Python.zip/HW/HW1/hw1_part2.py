import math

#input
input_mins = (input("Minutes ==> "))
print(input_mins)
input_sec = (input("Seconds ==> "))
print(input_sec)
miles = (input("Miles ==> "))
print(miles)
target = (input("Target Miles ==> "))
print(target)

#convert to usable variables for math
input_mins = int(input_mins)
input_sec = int(input_sec)
miles = float(miles)
target = float(target)

#find pace
input_frac = (input_sec/60) #include seconds as a fraction
pace_float = (input_mins+input_frac)/miles
pace_sec = int((pace_float-math.floor(pace_float))*60) #extract seconds after
#find speed
hours_frac = (input_mins+input_frac)/60
speed = miles/hours_frac
#find projeced time
proj_time_float = pace_float*target
proj_sec = int((proj_time_float-math.floor(proj_time_float))*60) #extracting seconds

#print pace, using floor() to grab the integer number of minutes
print("\nPace is",math.floor(pace_float),"minutes and",pace_sec,"seconds per mile.")
#print speed as a float rounded to 2 decimal places
print("Speed is {0:.2f} miles per hour.".format(speed))
#print target distance as float, and projected time in minutes and seconds 
print("Time to run the target distance of {0:.2f} miles is".format(target),math.floor(proj_time_float),"minutes and",proj_sec,"seconds.")