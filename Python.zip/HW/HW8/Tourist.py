class Tourist(object):
    #initializer
    def __init__(self,location,status_):
        self.x = location[0]
        self.y = location[1]
        self.status = status_
        #number of turns since bear sighting
        self.turns_since = 0
     #print formatting  
    def __str__(self):
        return "Tourist at ({0},{1}), {2} turns without seeing a bear.".\
               format(self.x,self.y,self.turns_since)
    def leave(self): self.status = 'reserve'
    #increment turns since bear sighting
    def increment(self): self.turns_since += 1
    #case of bear sighting
    def sighting(self): self.turns_since = 0